(function(g) {
    var window = this;
    'use strict';
    var qjb = function(a) {
            return a
        },
        rjb = function(a) {
            return a
        },
        sjb = function(a, b, c) {
            g.Vf(a);
            var d = g.cg(a, c);
            b = g.pg(g.nda(d, b, !0));
            d !== b && g.dg(a, c, b);
            return b
        },
        tjb = function(a, b) {
            this.u = a >>> 0;
            this.j = b >>> 0
        },
        vjb = function(a) {
            if (!a) return ujb || (ujb = new tjb(0, 0));
            if (!/^\d+$/.test(a)) return null;
            g.Kda(a);
            return new tjb(g.Kg, g.Lg)
        },
        wjb = function(a, b, c) {
            null != c && ("string" === typeof c && vjb(c), g.dh(a, b, 1), "number" === typeof c ? (a = a.j, b = c >>> 0, c = Math.floor((c - b) / 4294967296) >>> 0, g.Kg = b, g.Lg = c, g.bh(a, g.Kg), g.bh(a, g.Lg)) : (c = vjb(c), a = a.j, b = c.j, g.bh(a, c.u), g.bh(a, b)))
        },
        xjb = function(a, b, c) {
            b = g.rda(b, c);
            null != b && (g.dh(a, c, 0), a.j.j.push(b ? 1 : 0))
        },
        yjb = function(a, b, c, d, e) {
            b = g.qg(b, d, c);
            null != b && (c = g.Yda(a, c), e(b, a), g.Zda(a, c))
        },
        zjb = function(a) {
            g.J.call(this, a)
        },
        Bjb = function(a) {
            g.J.call(this, a, -1, Ajb)
        },
        Cjb = function(a) {
            g.J.call(this, a)
        },
        Djb = function(a) {
            g.J.call(this, a)
        },
        Ejb = function(a) {
            g.J.call(this, a)
        },
        Z7 = function(a) {
            g.Bj(a, "zx", Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ g.Qa()).toString(36));
            return a
        },
        $7 = function(a, b, c) {
            Array.isArray(c) || (c = [String(c)]);
            g.Kga(a.u, b, c)
        },
        Fjb = function(a) {
            if (a instanceof g.rm) return a;
            if ("function" == typeof a.hk) return a.hk(!1);
            if (g.Ia(a)) {
                var b = 0,
                    c = new g.rm;
                c.next = function() {
                    for (;;) {
                        if (b >= a.length) return g.L2;
                        if (b in a) return g.sm(a[b++]);
                        b++
                    }
                };
                return c
            }
            throw Error("Not implemented");
        },
        Gjb = function(a, b, c) {
            if (g.Ia(a)) g.Fb(a, b, c);
            else
                for (a = Fjb(a);;) {
                    var d = a.next();
                    if (d.done) break;
                    b.call(c, d.value, void 0, a)
                }
        },
        Hjb = function(a, b) {
            var c = [];
            Gjb(b, function(d) {
                try {
                    var e = g.To.prototype.u.call(this, d, !0)
                } catch (f) {
                    if ("Storage: Invalid value was encountered" == f) return;
                    throw f;
                }
                void 0 === e ? c.push(d) : g.sla(e) && c.push(d)
            }, a);
            return c
        },
        Ijb = function(a, b) {
            Hjb(a, b).forEach(function(c) {
                g.To.prototype.remove.call(this, c)
            }, a)
        },
        Jjb = function(a) {
            if (a.oa) {
                if (a.oa.locationOverrideToken) return {
                    locationOverrideToken: a.oa.locationOverrideToken
                };
                if (null != a.oa.latitudeE7 && null != a.oa.longitudeE7) return {
                    latitudeE7: a.oa.latitudeE7,
                    longitudeE7: a.oa.longitudeE7
                }
            }
            return null
        },
        Kjb = function(a, b) {
            g.kb(a, b) || a.push(b)
        },
        Ljb = function(a) {
            var b = 0,
                c;
            for (c in a) b++;
            return b
        },
        Mjb = function(a, b) {
            return g.Lc(a, b)
        },
        Njb = function(a) {
            try {
                return g.Ea.JSON.parse(a)
            } catch (b) {}
            a = String(a);
            if (/^\s*$/.test(a) ? 0 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))) try {
                return eval("(" + a + ")")
            } catch (b) {}
            throw Error("Invalid JSON string: " + a);
        },
        a8 = function(a) {
            if (g.Ea.JSON) try {
                return g.Ea.JSON.parse(a)
            } catch (b) {}
            return Njb(a)
        },
        Ojb = function(a, b, c, d) {
            var e = new g.tj(null);
            a && g.uj(e, a);
            b && g.vj(e, b);
            c && g.wj(e, c);
            d && (e.B = d);
            return e
        },
        b8 = function(a, b) {
            g.Iz[a] = !0;
            var c = g.Gz();
            c && c.publish.apply(c, arguments);
            g.Iz[a] = !1
        },
        c8 = function(a) {
            this.name = this.id = "";
            this.clientName = "UNKNOWN_INTERFACE";
            this.app = "";
            this.type = "REMOTE_CONTROL";
            this.obfuscatedGaiaId = this.avatar = this.username = "";
            this.capabilities = new Set;
            this.compatibleSenderThemes = new Set;
            this.experiments = new Set;
            this.theme = "u";
            new g.vo;
            this.model = this.brand = "";
            this.year = 0;
            this.chipset = this.osVersion = this.os = "";
            this.mdxDialServerType = "MDX_DIAL_SERVER_TYPE_UNKNOWN";
            a && (this.id = a.id || a.name, this.name = a.name, this.clientName = a.clientName ? a.clientName.toUpperCase() : "UNKNOWN_INTERFACE", this.app = a.app, this.type =
                a.type || "REMOTE_CONTROL", this.username = a.user || "", this.avatar = a.userAvatarUri || "", this.obfuscatedGaiaId = a.obfuscatedGaiaId || "", this.theme = a.theme || "u", Pjb(this, a.capabilities || ""), Qjb(this, a.compatibleSenderThemes || ""), Rjb(this, a.experiments || ""), this.brand = a.brand || "", this.model = a.model || "", this.year = a.year || 0, this.os = a.os || "", this.osVersion = a.osVersion || "", this.chipset = a.chipset || "", this.mdxDialServerType = a.mdxDialServerType || "MDX_DIAL_SERVER_TYPE_UNKNOWN", a = a.deviceInfo) && (a = JSON.parse(a), this.brand =
                a.brand || "", this.model = a.model || "", this.year = a.year || 0, this.os = a.os || "", this.osVersion = a.osVersion || "", this.chipset = a.chipset || "", this.clientName = a.clientName ? a.clientName.toUpperCase() : "UNKNOWN_INTERFACE", this.mdxDialServerType = a.mdxDialServerType || "MDX_DIAL_SERVER_TYPE_UNKNOWN")
        },
        Pjb = function(a, b) {
            a.capabilities.clear();
            g.wm(b.split(","), g.Pa(Mjb, Sjb)).forEach(function(c) {
                a.capabilities.add(c)
            })
        },
        Qjb = function(a, b) {
            a.compatibleSenderThemes.clear();
            g.wm(b.split(","), g.Pa(Mjb, Tjb)).forEach(function(c) {
                a.compatibleSenderThemes.add(c)
            })
        },
        Rjb = function(a, b) {
            a.experiments.clear();
            b.split(",").forEach(function(c) {
                a.experiments.add(c)
            })
        },
        d8 = function(a) {
            a = a || {};
            this.name = a.name || "";
            this.id = a.id || a.screenId || "";
            this.token = a.token || a.loungeToken || "";
            this.uuid = a.uuid || a.dialId || "";
            this.idType = a.screenIdType || "normal"
        },
        e8 = function(a, b) {
            return !!b && (a.id == b || a.uuid == b)
        },
        Ujb = function(a) {
            return {
                name: a.name,
                screenId: a.id,
                loungeToken: a.token,
                dialId: a.uuid,
                screenIdType: a.idType
            }
        },
        Vjb = function(a) {
            return new d8(a)
        },
        Wjb = function(a) {
            return Array.isArray(a) ? g.Fg(a, Vjb) : []
        },
        f8 = function(a) {
            return a ? '{name:"' + a.name + '",id:' + a.id.substr(0, 6) + "..,token:" + ((a.token ? ".." + a.token.slice(-6) : "-") + ",uuid:" + (a.uuid ? ".." + a.uuid.slice(-6) : "-") + ",idType:" + a.idType + "}") : "null"
        },
        Xjb = function(a) {
            return Array.isArray(a) ? "[" + g.Fg(a, f8).join(",") + "]" : "null"
        },
        Yjb = function() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,
                function(a) {
                    var b = 16 * Math.random() | 0;
                    return ("x" == a ? b : b & 3 | 8).toString(16)
                })
        },
        Zjb = function(a) {
            return g.Fg(a, function(b) {
                return {
                    key: b.id,
                    name: b.name
                }
            })
        },
        $jb = function(a, b) {
            return g.ib(a, function(c) {
                return c || b ? !c != !b ? !1 : c.id == b.id : !0
            })
        },
        g8 = function(a, b) {
            return g.ib(a, function(c) {
                return e8(c, b)
            })
        },
        akb = function() {
            var a = (0, g.IA)();
            a && Ijb(a, a.j.hk(!0))
        },
        h8 = function() {
            var a = g.LA("yt-remote-connected-devices") || [];
            g.Cb(a);
            return a
        },
        bkb = function(a) {
            if (g.lb(a)) return [];
            var b = a[0].indexOf("#"),
                c = -1 == b ? a[0] : a[0].substring(0, b);
            return g.Fg(a, function(d, e) {
                return 0 == e ? d : d.substring(c.length)
            })
        },
        ckb = function(a) {
            g.KA("yt-remote-connected-devices", a, 86400)
        },
        i8 = function() {
            if (dkb) return dkb;
            var a = g.LA("yt-remote-device-id");
            a || (a = Yjb(), g.KA("yt-remote-device-id", a, 31536E3));
            for (var b = h8(), c = 1, d = a; g.kb(b, d);) c++, d = a + "#" + c;
            return dkb = d
        },
        ekb = function() {
            var a = h8(),
                b = i8();
            g.NA() && g.Eb(a, b);
            a = bkb(a);
            if (g.lb(a)) try {
                g.Cw("remote_sid")
            } catch (c) {} else try {
                g.Aw("remote_sid", a.join(","), -1)
            } catch (c) {}
        },
        fkb = function() {
            return g.LA("yt-remote-session-browser-channel")
        },
        gkb = function() {
            return g.LA("yt-remote-local-screens") || []
        },
        hkb = function() {
            g.KA("yt-remote-lounge-token-expiration", !0, 86400)
        },
        ikb = function(a) {
            5 < a.length && (a = a.slice(a.length - 5));
            var b = g.Fg(gkb(), function(d) {
                    return d.loungeToken
                }),
                c = g.Fg(a, function(d) {
                    return d.loungeToken
                });
            g.Lk(c, function(d) {
                return !g.kb(b, d)
            }) && hkb();
            g.KA("yt-remote-local-screens", a, 31536E3)
        },
        j8 = function(a) {
            a || (g.MA("yt-remote-session-screen-id"), g.MA("yt-remote-session-video-id"));
            ekb();
            a = h8();
            g.pb(a, i8());
            ckb(a)
        },
        jkb = function() {
            if (!k8) {
                var a = g.bp();
                a && (k8 = new g.Qo(a))
            }
        },
        kkb = function() {
            jkb();
            return k8 ? !!k8.get("yt-remote-use-staging-server") : !1
        },
        lkb = function() {
            var a = window.navigator.userAgent.match(/Chrome\/([0-9]+)/);
            return a ? parseInt(a[1], 10) : 0
        },
        mkb = function(a) {
            return !!document.currentScript && (-1 != document.currentScript.src.indexOf("?" + a) || -1 != document.currentScript.src.indexOf("&" + a))
        },
        nkb = function() {
            return "function" == typeof window.__onGCastApiAvailable ? window.__onGCastApiAvailable : null
        },
        l8 = function(a) {
            a.length ? okb(a.shift(), function() {
                l8(a)
            }) : pkb()
        },
        qkb = function(a) {
            return "chrome-extension://" + a + "/cast_sender.js"
        },
        okb = function(a, b, c) {
            var d = document.createElement("script");
            d.onerror = b;
            c && (d.onload = c);
            g.Xi(d, g.Ed(a));
            (document.head || document.documentElement).appendChild(d)
        },
        rkb = function() {
            var a = lkb(),
                b = [];
            if (1 < a) {
                var c = a - 1;
                b.push("//www.gstatic.com/eureka/clank/" + a + "/cast_sender.js");
                b.push("//www.gstatic.com/eureka/clank/" + c + "/cast_sender.js")
            }
            return b
        },
        pkb = function() {
            var a = nkb();
            a && a(!1, "No cast extension found")
        },
        tkb = function() {
            if (skb) {
                var a = 2,
                    b = nkb(),
                    c = function() {
                        a--;
                        0 == a && b && b(!0)
                    };
                window.__onGCastApiAvailable = c;
                okb("//www.gstatic.com/cast/sdk/libs/sender/1.0/cast_framework.js", pkb, c)
            }
        },
        ukb = function() {
            tkb();
            var a = rkb();
            a.push("//www.gstatic.com/eureka/clank/cast_sender.js");
            l8(a)
        },
        wkb = function() {
            tkb();
            var a = rkb();
            a.push.apply(a, g.u(vkb.map(qkb)));
            a.push("//www.gstatic.com/eureka/clank/cast_sender.js");
            l8(a)
        },
        xkb = function() {
            this.j = m8();
            this.j.Vn("/client_streamz/youtube/living_room/mdx/channel/opened", {
                ah: 3,
                Zg: "channel_type"
            })
        },
        ykb = function(a, b) {
            a.j.Ap("/client_streamz/youtube/living_room/mdx/channel/opened", b)
        },
        zkb = function() {
            this.j = m8();
            this.j.Vn("/client_streamz/youtube/living_room/mdx/channel/closed", {
                ah: 3,
                Zg: "channel_type"
            })
        },
        Akb = function(a, b) {
            a.j.Ap("/client_streamz/youtube/living_room/mdx/channel/closed", b)
        },
        Bkb = function() {
            this.j = m8();
            this.j.Vn("/client_streamz/youtube/living_room/mdx/channel/message_received", {
                ah: 3,
                Zg: "channel_type"
            })
        },
        Ckb = function(a, b) {
            a.j.Ap("/client_streamz/youtube/living_room/mdx/channel/message_received", b)
        },
        Dkb = function() {
            this.j = m8();
            this.j.Vn("/client_streamz/youtube/living_room/mdx/channel/error", {
                ah: 3,
                Zg: "channel_type"
            })
        },
        Ekb = function(a, b) {
            a.j.Ap("/client_streamz/youtube/living_room/mdx/channel/error", b)
        },
        Fkb = function() {
            this.j = m8();
            this.j.Vn("/client_streamz/youtube/living_room/mdx/browser_channel/pending_maps")
        },
        Gkb = function() {
            this.j = m8();
            this.j.Vn("/client_streamz/youtube/living_room/mdx/browser_channel/undelivered_maps")
        },
        n8 = function(a, b, c) {
            g.C.call(this);
            this.I = null != c ? (0, g.Oa)(a, c) : a;
            this.Di = b;
            this.D = (0, g.Oa)(this.TY, this);
            this.j = !1;
            this.u = 0;
            this.B = this.Dc = null;
            this.C = []
        },
        o8 = function(a, b, c) {
            g.C.call(this);
            this.C = null != c ? a.bind(c) : a;
            this.Di = b;
            this.B = null;
            this.j = !1;
            this.u = 0;
            this.Dc = null
        },
        Hkb = function(a) {
            a.Dc = g.rf(function() {
                a.Dc = null;
                a.j && !a.u && (a.j = !1, Hkb(a))
            }, a.Di);
            var b = a.B;
            a.B = null;
            a.C.apply(null, b)
        },
        p8 = function() {},
        Ikb = function() {
            g.db.call(this, "p")
        },
        Jkb = function() {
            g.db.call(this, "o")
        },
        Lkb = function() {
            return Kkb = Kkb || new g.pd
        },
        Mkb = function(a) {
            g.db.call(this, "serverreachability", a)
        },
        q8 = function(a) {
            var b = Lkb();
            b.dispatchEvent(new Mkb(b, a))
        },
        Nkb = function(a) {
            g.db.call(this, "statevent", a)
        },
        r8 = function(a) {
            var b = Lkb();
            b.dispatchEvent(new Nkb(b, a))
        },
        Okb = function(a, b, c, d) {
            g.db.call(this, "timingevent", a);
            this.size = b;
            this.Zy = d
        },
        s8 = function(a, b) {
            if ("function" !== typeof a) throw Error("Fn must not be null and must be a function");
            return g.Ea.setTimeout(function() {
                a()
            }, b)
        },
        Pkb = function() {},
        t8 = function(a, b, c, d) {
            this.D = a;
            this.C = b;
            this.Fc = c;
            this.Ac = d || 1;
            this.ib = new g.Gj(this);
            this.Cb = 45E3;
            a = g.cI ? 125 : void 0;
            this.kb = new g.qf(a);
            this.Ma = null;
            this.B = !1;
            this.T = this.Xa = this.J = this.Pa = this.ya = this.Tb = this.Z = null;
            this.oa = [];
            this.j = null;
            this.ea = 0;
            this.I = this.Aa = null;
            this.Rb = -1;
            this.Ia = !1;
            this.vb = 0;
            this.Ya = null;
            this.uc = this.Va = this.dc = this.Ba = !1;
            this.u = new Qkb
        },
        Qkb = function() {
            this.B = null;
            this.j = "";
            this.u = !1
        },
        Skb = function(a, b, c) {
            a.Pa = 1;
            a.J = Z7(b.clone());
            a.T = c;
            a.Ba = !0;
            Rkb(a, null)
        },
        Rkb = function(a, b) {
            a.ya = Date.now();
            u8(a);
            a.Xa = a.J.clone();
            $7(a.Xa, "t", a.Ac);
            a.ea = 0;
            var c = a.D.Pa;
            a.u = new Qkb;
            a.j = Tkb(a.D, c ? b : null, !a.T);
            0 < a.vb && (a.Ya = new o8((0, g.Oa)(a.LP, a, a.j), a.vb));
            a.ib.Ra(a.j, "readystatechange", a.WY);
            b = a.Ma ? g.Uc(a.Ma) : {};
            a.T ? (a.Aa || (a.Aa = "POST"), b["Content-Type"] = "application/x-www-form-urlencoded", a.j.send(a.Xa, a.Aa, a.T, b)) : (a.Aa = "GET", a.j.send(a.Xa, a.Aa, null, b));
            q8(1)
        },
        Ukb = function(a) {
            return a.j ? "GET" == a.Aa && 2 != a.Pa && a.D.ye : !1
        },
        Ykb = function(a, b, c) {
            for (var d = !0, e; !a.Ia && a.ea < c.length;)
                if (e = Vkb(a, c), e == v8) {
                    4 ==
                        b && (a.I = 4, r8(14), d = !1);
                    break
                } else if (e == Wkb) {
                a.I = 4;
                r8(15);
                d = !1;
                break
            } else Xkb(a, e);
            Ukb(a) && e != v8 && e != Wkb && (a.u.j = "", a.ea = 0);
            4 != b || 0 != c.length || a.u.u || (a.I = 1, r8(16), d = !1);
            a.B = a.B && d;
            d ? 0 < c.length && !a.uc && (a.uc = !0, a.D.BM(a)) : (w8(a), x8(a))
        },
        Vkb = function(a, b) {
            var c = a.ea,
                d = b.indexOf("\n", c);
            if (-1 == d) return v8;
            c = Number(b.substring(c, d));
            if (isNaN(c)) return Wkb;
            d += 1;
            if (d + c > b.length) return v8;
            b = b.slice(d, d + c);
            a.ea = d + c;
            return b
        },
        u8 = function(a) {
            a.Tb = Date.now() + a.Cb;
            Zkb(a, a.Cb)
        },
        Zkb = function(a, b) {
            if (null != a.Z) throw Error("WatchDog timer not null");
            a.Z = s8((0, g.Oa)(a.UY, a), b)
        },
        y8 = function(a) {
            a.Z && (g.Ea.clearTimeout(a.Z), a.Z = null)
        },
        x8 = function(a) {
            a.D.Og() || a.Ia || $kb(a.D, a)
        },
        w8 = function(a) {
            y8(a);
            g.Za(a.Ya);
            a.Ya = null;
            a.kb.stop();
            a.ib.Hg();
            if (a.j) {
                var b = a.j;
                a.j = null;
                b.abort();
                b.dispose()
            }
        },
        Xkb = function(a, b) {
            try {
                var c = a.D;
                if (0 != c.nh && (c.j == a || alb(c.u, a)))
                    if (!a.Va && alb(c.u, a) && 3 == c.nh) {
                        try {
                            var d = c.Cf.j.parse(b)
                        } catch (z) {
                            d = null
                        }
                        if (Array.isArray(d) && 3 == d.length) {
                            var e = d;
                            if (0 == e[0]) a: {
                                if (!c.T) {
                                    if (c.j)
                                        if (c.j.ya + 3E3 < a.ya) z8(c), A8(c);
                                        else break a;
                                    blb(c);
                                    r8(18)
                                }
                            }
                            else c.Qd = e[1], 0 < c.Qd - c.Va && 37500 > e[2] && c.kb && 0 == c.oa && !c.ea && (c.ea = s8((0, g.Oa)(c.XY, c), 6E3));
                            if (1 >= clb(c.u) && c.Vc) {
                                try {
                                    c.Vc()
                                } catch (z) {}
                                c.Vc = void 0
                            }
                        } else B8(c, 11)
                    } else if ((a.Va || c.j == a) && z8(c), !g.Lb(b))
                    for (e = c.Cf.j.parse(b), b = 0; b < e.length; b++) {
                        var f = e[b];
                        c.Va = f[0];
                        f = f[1];
                        if (2 == c.nh)
                            if ("c" == f[0]) {
                                c.C = f[1];
                                c.uc = f[2];
                                var h = f[3];
                                null != h && (c.MP = h);
                                var l = f[5];
                                null != l && "number" === typeof l && 0 < l && (c.Xa = 1.5 * l);
                                d = c;
                                var m = a.ZK();
                                if (m) {
                                    var n = g.li(m, "X-Client-Wire-Protocol");
                                    if (n) {
                                        var p = d.u;
                                        !p.j && (g.Ob(n, "spdy") || g.Ob(n, "quic") || g.Ob(n, "h2")) && (p.C = p.D, p.j = new Set, p.u && (dlb(p, p.u), p.u = null))
                                    }
                                    if (d.Ba) {
                                        var q = g.li(m, "X-HTTP-Session-Id");
                                        q && (d.je = q, g.Bj(d.Ma, d.Ba, q))
                                    }
                                }
                                c.nh = 3;
                                c.D && c.D.SP();
                                c.Uc && (c.Od = Date.now() - a.ya);
                                d = c;
                                var r = a;
                                d.Bd = elb(d, d.Pa ? d.uc : null, d.Ac);
                                if (r.Va) {
                                    flb(d.u,
                                        r);
                                    var v = r,
                                        x = d.Xa;
                                    x && v.setTimeout(x);
                                    v.Z && (y8(v), u8(v));
                                    d.j = r
                                } else glb(d);
                                0 < c.B.length && C8(c)
                            } else "stop" != f[0] && "close" != f[0] || B8(c, 7);
                        else 3 == c.nh && ("stop" == f[0] || "close" == f[0] ? "stop" == f[0] ? B8(c, 7) : c.disconnect() : "noop" != f[0] && c.D && c.D.RP(f), c.oa = 0)
                    }
                q8(4)
            } catch (z) {}
        },
        hlb = function(a, b) {
            this.j = a;
            this.map = b;
            this.context = null
        },
        ilb = function(a) {
            this.D = a || 10;
            g.Ea.PerformanceNavigationTiming ? (a = g.Ea.performance.getEntriesByType("navigation"), a = 0 < a.length && ("hq" == a[0].nextHopProtocol || "h2" == a[0].nextHopProtocol)) : a = !!(g.Ea.chrome && g.Ea.chrome.loadTimes && g.Ea.chrome.loadTimes() && g.Ea.chrome.loadTimes().wasFetchedViaSpdy);
            this.C = a ? this.D : 1;
            this.j = null;
            1 < this.C && (this.j = new Set);
            this.u = null;
            this.B = []
        },
        jlb = function(a) {
            return a.u ? !0 : a.j ? a.j.size >= a.C : !1
        },
        clb = function(a) {
            return a.u ? 1 : a.j ? a.j.size : 0
        },
        alb = function(a, b) {
            return a.u ? a.u == b : a.j ? a.j.has(b) : !1
        },
        dlb =
        function(a, b) {
            a.j ? a.j.add(b) : a.u = b
        },
        flb = function(a, b) {
            a.u && a.u == b ? a.u = null : a.j && a.j.has(b) && a.j.delete(b)
        },
        klb = function(a) {
            if (null != a.u) return a.B.concat(a.u.oa);
            if (null != a.j && 0 !== a.j.size) {
                var b = a.B;
                a = g.t(a.j.values());
                for (var c = a.next(); !c.done; c = a.next()) b = b.concat(c.value.oa);
                return b
            }
            return g.sb(a.B)
        },
        llb = function(a, b) {
            var c = new Pkb;
            if (g.Ea.Image) {
                var d = new Image;
                d.onload = g.Pa(D8, c, d, "TestLoadImage: loaded", !0, b);
                d.onerror = g.Pa(D8, c, d, "TestLoadImage: error", !1, b);
                d.onabort = g.Pa(D8, c, d, "TestLoadImage: abort", !1, b);
                d.ontimeout = g.Pa(D8, c, d, "TestLoadImage: timeout", !1, b);
                g.Ea.setTimeout(function() {
                    if (d.ontimeout) d.ontimeout()
                }, 1E4);
                d.src = a
            } else b(!1)
        },
        D8 = function(a, b, c, d, e) {
            try {
                b.onload = null, b.onerror = null, b.onabort = null, b.ontimeout = null, e(d)
            } catch (f) {}
        },
        mlb = function() {
            this.j = new p8
        },
        nlb = function(a, b, c) {
            var d = c || "";
            try {
                g.sj(a, function(e, f) {
                    var h = e;
                    g.Ja(e) && (h = g.Hh(e));
                    b.push(d + f + "=" + encodeURIComponent(h))
                })
            } catch (e) {
                throw b.push(d + "type=" + encodeURIComponent("_badmap")), e;
            }
        },
        E8 = function(a, b, c) {
            return c && c.M2 ? c.M2[a] || b : b
        },
        olb = function(a) {
            this.B = [];
            this.uc = this.Bd = this.Ma = this.Ac = this.j = this.je = this.Ba = this.Ia = this.J = this.Tb = this.Z = null;
            this.tf = this.Ya = 0;
            this.rf = E8("failFast", !1, a);
            this.kb = this.ea = this.T = this.I = this.D = null;
            this.Fc = !0;
            this.Qd = this.Va = -1;
            this.dc = this.oa = this.ya = 0;
            this.qf = E8("baseRetryDelayMs", 5E3, a);
            this.Df = E8("retryDelaySeedMs", 1E4, a);
            this.sf = E8("forwardChannelMaxRetries", 2, a);
            this.Jd = E8("forwardChannelRequestTimeoutMs", 2E4, a);
            this.Rd = a && a.Zeb || void 0;
            this.ye = a && a.Xeb || !1;
            this.Xa = void 0;
            this.Pa = a && a.L7 || !1;
            this.C = "";
            this.u = new ilb(a &&
                a.Lcb);
            this.Cf = new mlb;
            this.Cb = a && a.adb || !1;
            this.vb = a && a.Rcb || !1;
            this.Cb && this.vb && (this.vb = !1);
            this.Ff = a && a.Fcb || !1;
            a && a.cdb && (this.Fc = !1);
            this.Uc = !this.Cb && this.Fc && a && a.Pcb || !1;
            this.Vc = void 0;
            this.Od = 0;
            this.ib = !1;
            this.Rb = this.Aa = null
        },
        A8 = function(a) {
            a.j && (plb(a), a.j.cancel(), a.j = null)
        },
        qlb = function(a) {
            A8(a);
            a.T && (g.Ea.clearTimeout(a.T), a.T = null);
            z8(a);
            a.u.cancel();
            a.I && ("number" === typeof a.I && g.Ea.clearTimeout(a.I), a.I = null)
        },
        C8 = function(a) {
            jlb(a.u) || a.I || (a.I = !0, g.af(a.OP, a), a.ya = 0)
        },
        slb = function(a, b) {
            if (clb(a.u) >= a.u.C - (a.I ? 1 : 0)) return !1;
            if (a.I) return a.B = b.oa.concat(a.B), !0;
            if (1 == a.nh || 2 == a.nh || a.ya >= (a.rf ? 0 : a.sf)) return !1;
            a.I = s8((0, g.Oa)(a.OP, a, b), rlb(a, a.ya));
            a.ya++;
            return !0
        },
        ulb = function(a, b) {
            var c;
            b ? c = b.Fc : c = a.Ya++;
            var d = a.Ma.clone();
            g.Bj(d, "SID", a.C);
            g.Bj(d, "RID", c);
            g.Bj(d, "AID", a.Va);
            F8(a, d);
            a.J && a.Z && g.Fj(d, a.J, a.Z);
            c = new t8(a, a.C, c, a.ya + 1);
            null === a.J && (c.Ma = a.Z);
            b && (a.B = b.oa.concat(a.B));
            b = tlb(a, c, 1E3);
            c.setTimeout(Math.round(.5 * a.Jd) + Math.round(.5 * a.Jd * Math.random()));
            dlb(a.u, c);
            Skb(c, d, b)
        },
        F8 = function(a, b) {
            a.Ia && g.Bc(a.Ia, function(c, d) {
                g.Bj(b, d, c)
            });
            a.D && g.sj({}, function(c, d) {
                g.Bj(b, d, c)
            })
        },
        tlb = function(a, b, c) {
            c = Math.min(a.B.length, c);
            var d = a.D ? (0, g.Oa)(a.D.YY, a.D, a) : null;
            a: for (var e = a.B, f = -1;;) {
                var h = ["count=" + c]; - 1 == f ? 0 < c ? (f = e[0].j, h.push("ofs=" + f)) : f = 0 : h.push("ofs=" + f);
                for (var l = !0, m = 0; m < c; m++) {
                    var n = e[m].j,
                        p = e[m].map;
                    n -= f;
                    if (0 > n) f = Math.max(0, e[m].j - 100), l = !1;
                    else try {
                        nlb(p, h, "req" + n + "_")
                    } catch (q) {
                        d && d(p)
                    }
                }
                if (l) {
                    d = h.join("&");
                    break a
                }
            }
            a = a.B.splice(0, c);
            b.oa = a;
            return d
        },
        glb = function(a) {
            a.j || a.T || (a.dc = 1, g.af(a.NP, a), a.oa = 0)
        },
        blb = function(a) {
            if (a.j || a.T || 3 <= a.oa) return !1;
            a.dc++;
            a.T = s8((0, g.Oa)(a.NP, a), rlb(a, a.oa));
            a.oa++;
            return !0
        },
        plb = function(a) {
            null != a.Aa && (g.Ea.clearTimeout(a.Aa), a.Aa = null)
        },
        vlb = function(a) {
            a.j = new t8(a, a.C, "rpc", a.dc);
            null === a.J && (a.j.Ma = a.Z);
            a.j.vb = 0;
            var b = a.Bd.clone();
            g.Bj(b, "RID", "rpc");
            g.Bj(b, "SID", a.C);
            g.Bj(b, "CI", a.kb ? "0" : "1");
            g.Bj(b, "AID", a.Va);
            g.Bj(b, "TYPE", "xmlhttp");
            F8(a, b);
            a.J && a.Z && g.Fj(b, a.J, a.Z);
            a.Xa && a.j.setTimeout(a.Xa);
            var c = a.j;
            a = a.uc;
            c.Pa = 1;
            c.J = Z7(b.clone());
            c.T = null;
            c.Ba = !0;
            Rkb(c, a)
        },
        z8 = function(a) {
            null != a.ea && (g.Ea.clearTimeout(a.ea), a.ea = null)
        },
        $kb = function(a, b) {
            var c = null;
            if (a.j == b) {
                z8(a);
                plb(a);
                a.j = null;
                var d = 2
            } else if (alb(a.u, b)) c = b.oa, flb(a.u, b), d = 1;
            else return;
            if (0 != a.nh)
                if (b.B)
                    if (1 == d) {
                        c = b.T ? b.T.length : 0;
                        b = Date.now() - b.ya;
                        var e = a.ya;
                        d = Lkb();
                        d.dispatchEvent(new Okb(d, c, b, e));
                        C8(a)
                    } else glb(a);
            else {
                var f = b.Rb;
                e = b.getLastError();
                if (3 == e || 0 == e && 0 < f || !(1 == d && slb(a, b) || 2 == d && blb(a))) switch (c && 0 < c.length && (b = a.u, b.B = b.B.concat(c)), e) {
                    case 1:
                        B8(a, 5);
                        break;
                    case 4:
                        B8(a, 10);
                        break;
                    case 3:
                        B8(a, 6);
                        break;
                    default:
                        B8(a, 2)
                }
            }
        },
        rlb = function(a, b) {
            var c = a.qf + Math.floor(Math.random() *
                a.Df);
            a.isActive() || (c *= 2);
            return c * b
        },
        B8 = function(a, b) {
            if (2 == b) {
                var c = null;
                a.D && (c = null);
                var d = (0, g.Oa)(a.R7, a);
                c || (c = new g.tj("//www.google.com/images/cleardot.gif"), g.Ea.location && "http" == g.Ea.location.protocol || g.uj(c, "https"), Z7(c));
                llb(c.toString(), d)
            } else r8(2);
            a.nh = 0;
            a.D && a.D.QP(b);
            wlb(a);
            qlb(a)
        },
        wlb = function(a) {
            a.nh = 0;
            a.Rb = [];
            if (a.D) {
                var b = klb(a.u);
                if (0 != b.length || 0 != a.B.length) g.ub(a.Rb, b), g.ub(a.Rb, a.B), a.u.B.length = 0, g.sb(a.B), a.B.length = 0;
                a.D.PP()
            }
        },
        xlb = function(a) {
            if (0 == a.nh) return a.Rb;
            var b = [];
            g.ub(b, klb(a.u));
            g.ub(b, a.B);
            return b
        },
        elb = function(a, b, c) {
            var d = g.Cj(c);
            "" != d.j ? (b && g.vj(d, b + "." + d.j), g.wj(d, d.C)) : (d = g.Ea.location, d = Ojb(d.protocol, b ? b + "." + d.hostname : d.hostname, +d.port, c));
            b = a.Ba;
            c = a.je;
            b && c && g.Bj(d, b, c);
            g.Bj(d, "VER", a.MP);
            F8(a, d);
            return d
        },
        Tkb = function(a, b, c) {
            if (b && !a.Pa) throw Error("Can't create secondary domain capable XhrIo object.");
            b = c && a.ye && !a.Rd ? new g.ei(new g.oj({
                OW: !0
            })) : new g.ei(a.Rd);
            b.J = a.Pa;
            return b
        },
        ylb = function() {},
        zlb = function() {
            if (g.Ae && !g.wc(10)) throw Error("Environmental error: no available transport.");
        },
        H8 = function(a, b) {
            g.pd.call(this);
            this.j = new olb(b);
            this.I = a;
            this.u = b && b.y3 || null;
            a = b && b.x3 || null;
            b && b.Kcb && (a ? a["X-Client-Protocol"] = "webchannel" : a = {
                "X-Client-Protocol": "webchannel"
            });
            this.j.Z = a;
            a = b && b.Kdb || null;
            b && b.rU && (a ? a["X-WebChannel-Content-Type"] = b.rU : a = {
                "X-WebChannel-Content-Type": b.rU
            });
            b && b.SR && (a ? a["X-WebChannel-Client-Profile"] = b.SR : a = {
                "X-WebChannel-Client-Profile": b.SR
            });
            this.j.Tb = a;
            (a = b && b.Jdb) && !g.Lb(a) && (this.j.J = a);
            this.J = b && b.L7 || !1;
            this.D = b && b.Aeb || !1;
            (b = b && b.I2) && !g.Lb(b) && (this.j.Ba = b, g.Kc(this.u, b) && g.Qc(this.u,
                b));
            this.C = new G8(this)
        },
        Alb = function(a) {
            Ikb.call(this);
            a.__headers__ && (this.headers = a.__headers__, this.statusCode = a.__status__, delete a.__headers__, delete a.__status__);
            var b = a.__sm__;
            b ? this.data = (this.j = g.Fc(b)) ? g.Rc(b, this.j) : b : this.data = a
        },
        Blb = function(a) {
            Jkb.call(this);
            this.status = 1;
            this.errorCode = a
        },
        G8 = function(a) {
            this.j = a
        },
        Clb = function(a, b) {
            this.u = a;
            this.j = b
        },
        Dlb = function(a) {
            return xlb(a.j).map(function(b) {
                b = b.map;
                "__data__" in b && (b = b.__data__, b = a.u.D ? Njb(b) : b);
                return b
            })
        },
        I8 = function(a, b) {
            if ("function" !== typeof a) throw Error("Fn must not be null and must be a function");
            return g.Ea.setTimeout(function() {
                a()
            }, b)
        },
        K8 = function(a) {
            J8.dispatchEvent(new Elb(J8, a))
        },
        Elb = function(a) {
            g.db.call(this, "statevent", a)
        },
        L8 = function(a, b, c, d) {
            this.j = a;
            this.C = b;
            this.J = c;
            this.I = d || 1;
            this.u = 45E3;
            this.B = new g.Gj(this);
            this.D = new g.qf;
            this.D.setInterval(250)
        },
        Glb = function(a, b, c) {
            a.Gw = 1;
            a.Vq = Z7(b.clone());
            a.Nt = c;
            a.Ba = !0;
            Flb(a, null)
        },
        Hlb = function(a, b, c, d, e) {
            a.Gw = 1;
            a.Vq = Z7(b.clone());
            a.Nt = null;
            a.Ba = c;
            e && (a.tW = !1);
            Flb(a, d)
        },
        Flb = function(a, b) {
            a.Fw = Date.now();
            M8(a);
            a.Xq = a.Vq.clone();
            $7(a.Xq, "t", a.I);
            a.MD = 0;
            a.Pi = a.j.nI(a.j.Zz() ? b : null);
            0 < a.lI && (a.KD = new o8((0, g.Oa)(a.TP, a, a.Pi), a.lI));
            a.B.Ra(a.Pi, "readystatechange", a.aZ);
            b = a.Mt ? g.Uc(a.Mt) : {};
            a.Nt ? (a.LD = "POST", b["Content-Type"] = "application/x-www-form-urlencoded", a.Pi.send(a.Xq, a.LD, a.Nt, b)) : (a.LD = "GET", a.tW && !g.xc && (b.Connection = "close"), a.Pi.send(a.Xq, a.LD, null, b));
            a.j.Xm(1)
        },
        Klb = function(a, b) {
            var c = a.MD,
                d = b.indexOf("\n", c);
            if (-1 == d) return Ilb;
            c = Number(b.substring(c, d));
            if (isNaN(c)) return Jlb;
            d += 1;
            if (d + c > b.length) return Ilb;
            b = b.slice(d, d + c);
            a.MD = d + c;
            return b
        },
        Mlb = function(a, b) {
            a.Fw = Date.now();
            M8(a);
            var c = b ? window.location.hostname : "";
            a.Xq = a.Vq.clone();
            g.Bj(a.Xq, "DOMAIN", c);
            g.Bj(a.Xq, "t", a.I);
            try {
                a.Bn = new ActiveXObject("htmlfile")
            } catch (m) {
                N8(a);
                a.Wq = 7;
                K8(22);
                O8(a);
                return
            }
            var d = "<html><body>";
            if (b) {
                var e = "";
                for (b = 0; b < c.length; b++) {
                    var f = c.charAt(b);
                    if ("<" == f) f = e + "\\x3c";
                    else if (">" == f) f = e + "\\x3e";
                    else {
                        if (f in P8) f = P8[f];
                        else if (f in Llb) f = P8[f] = Llb[f];
                        else {
                            var h = f.charCodeAt(0);
                            if (31 < h && 127 > h) var l = f;
                            else {
                                if (256 > h) {
                                    if (l = "\\x", 16 > h || 256 < h) l += "0"
                                } else l = "\\u", 4096 > h && (l += "0");
                                l += h.toString(16).toUpperCase()
                            }
                            f =
                                P8[f] = l
                        }
                        f = e + f
                    }
                    e = f
                }
                d += '<script>document.domain="' + e + '"\x3c/script>'
            }
            d += "</body></html>";
            g.Bd("b/12014412");
            c = g.Rd(d);
            a.Bn.open();
            a.Bn.write(g.Qd(c));
            a.Bn.close();
            a.Bn.parentWindow.m = (0, g.Oa)(a.t6, a);
            a.Bn.parentWindow.d = (0, g.Oa)(a.uV, a, !0);
            a.Bn.parentWindow.rpcClose = (0, g.Oa)(a.uV, a, !1);
            c = a.Bn.createElement("DIV");
            a.Bn.parentWindow.document.body.appendChild(c);
            d = g.Id(a.Xq.toString());
            d = g.ne(g.Gd(d));
            g.Bd("b/12014412");
            d = g.Rd('<iframe src="' + d + '"></iframe>');
            g.Zba(c, d);
            a.j.Xm(1)
        },
        M8 = function(a) {
            a.mI =
                Date.now() + a.u;
            Nlb(a, a.u)
        },
        Nlb = function(a, b) {
            if (null != a.Hw) throw Error("WatchDog timer not null");
            a.Hw = I8((0, g.Oa)(a.ZY, a), b)
        },
        Olb = function(a) {
            a.Hw && (g.Ea.clearTimeout(a.Hw), a.Hw = null)
        },
        O8 = function(a) {
            a.j.Og() || a.Lt || a.j.ND(a)
        },
        N8 = function(a) {
            Olb(a);
            g.Za(a.KD);
            a.KD = null;
            a.D.stop();
            a.B.Hg();
            if (a.Pi) {
                var b = a.Pi;
                a.Pi = null;
                b.abort();
                b.dispose()
            }
            a.Bn && (a.Bn = null)
        },
        Plb = function(a, b) {
            try {
                a.j.UP(a, b), a.j.Xm(4)
            } catch (c) {}
        },
        Rlb = function(a, b, c, d, e) {
            if (0 == d) c(!1);
            else {
                var f = e || 0;
                d--;
                Qlb(a, b, function(h) {
                    h ? c(!0) : g.Ea.setTimeout(function() {
                        Rlb(a, b, c, d, f)
                    }, f)
                })
            }
        },
        Qlb = function(a, b, c) {
            var d = new Image;
            d.onload = function() {
                try {
                    Q8(d), c(!0)
                } catch (e) {}
            };
            d.onerror = function() {
                try {
                    Q8(d), c(!1)
                } catch (e) {}
            };
            d.onabort = function() {
                try {
                    Q8(d), c(!1)
                } catch (e) {}
            };
            d.ontimeout = function() {
                try {
                    Q8(d), c(!1)
                } catch (e) {}
            };
            g.Ea.setTimeout(function() {
                if (d.ontimeout) d.ontimeout()
            }, b);
            d.src = a
        },
        Q8 = function(a) {
            a.onload = null;
            a.onerror = null;
            a.onabort = null;
            a.ontimeout = null
        },
        Slb = function(a) {
            this.j = a;
            this.u = new p8
        },
        Tlb = function(a) {
            var b = R8(a.j, a.uA, "/mail/images/cleardot.gif");
            Z7(b);
            Rlb(b.toString(), 5E3, (0, g.Oa)(a.G0, a), 3, 2E3);
            a.Xm(1)
        },
        Ulb = function(a) {
            var b = a.j.Z;
            if (null != b) K8(5), b ? (K8(11), S8(a.j, a, !1)) : (K8(12), S8(a.j, a, !0));
            else if (a.tj = new L8(a), a.tj.Mt = a.oI, b = a.j, b = R8(b, b.Zz() ? a.Yz : null, a.pI), K8(5), !g.Ae || g.wc(10)) $7(b, "TYPE", "xmlhttp"), Hlb(a.tj, b, !1, a.Yz, !1);
            else {
                $7(b, "TYPE", "html");
                var c = a.tj;
                a = !!a.Yz;
                c.Gw = 3;
                c.Vq = Z7(b.clone());
                Mlb(c, a)
            }
        },
        Vlb = function(a, b, c) {
            this.j = 1;
            this.u = [];
            this.B = [];
            this.D = new p8;
            this.T = a || null;
            this.Z = null != b ? b : null;
            this.J = c || !1
        },
        Wlb = function(a, b) {
            this.j = a;
            this.map = b;
            this.context = null
        },
        Xlb = function(a, b, c, d) {
            g.db.call(this, "timingevent", a);
            this.size = b;
            this.Zy = d
        },
        Ylb = function(a) {
            g.db.call(this, "serverreachability", a)
        },
        $lb = function(a) {
            a.bZ(1, 0);
            a.OD = R8(a, null, a.qI);
            Zlb(a)
        },
        amb = function(a) {
            a.Ar && (a.Ar.abort(), a.Ar = null);
            a.yg && (a.yg.cancel(), a.yg = null);
            a.yp && (g.Ea.clearTimeout(a.yp), a.yp = null);
            T8(a);
            a.Cj && (a.Cj.cancel(), a.Cj = null);
            a.Yq && (g.Ea.clearTimeout(a.Yq), a.Yq = null)
        },
        bmb = function(a, b) {
            if (0 == a.j) throw Error("Invalid operation: sending map when state is closed");
            a.u.push(new Wlb(a.cZ++, b));
            2 != a.j && 3 != a.j || Zlb(a)
        },
        cmb = function(a) {
            var b = 0;
            a.yg && b++;
            a.Cj && b++;
            return b
        },
        Zlb = function(a) {
            a.Cj || a.Yq || (a.Yq = I8((0, g.Oa)(a.YP, a), 0), a.Jw = 0)
        },
        fmb = function(a, b) {
            if (1 == a.j) {
                if (!b) {
                    a.bA = Math.floor(1E5 * Math.random());
                    b = a.bA++;
                    var c = new L8(a, "", b);
                    c.Mt = a.Fn;
                    var d = dmb(a),
                        e = a.OD.clone();
                    g.Bj(e, "RID", b);
                    g.Bj(e, "CVER", "1");
                    U8(a, e);
                    Glb(c, e, d);
                    a.Cj = c;
                    a.j = 2
                }
            } else 3 == a.j && (b ? emb(a, b) : 0 == a.u.length || a.Cj || emb(a))
        },
        emb = function(a, b) {
            if (b)
                if (6 < a.Ot) {
                    a.u = a.B.concat(a.u);
                    a.B.length = 0;
                    var c = a.bA - 1;
                    b = dmb(a)
                } else c = b.J, b = b.Nt;
            else c = a.bA++, b = dmb(a);
            var d = a.OD.clone();
            g.Bj(d, "SID", a.C);
            g.Bj(d, "RID", c);
            g.Bj(d, "AID", a.Kw);
            U8(a, d);
            c = new L8(a, a.C, c, a.Jw + 1);
            c.Mt = a.Fn;
            c.setTimeout(1E4 + Math.round(1E4 * Math.random()));
            a.Cj = c;
            Glb(c, d, b)
        },
        U8 = function(a, b) {
            a.ji && (a = a.ji.cQ()) && g.Bc(a, function(c, d) {
                g.Bj(b, d, c)
            })
        },
        dmb = function(a) {
            var b = Math.min(a.u.length, 1E3),
                c = ["count=" + b];
            if (6 < a.Ot && 0 < b) {
                var d = a.u[0].j;
                c.push("ofs=" + d)
            } else d = 0;
            for (var e = {}, f = 0; f < b; e = {
                    nw: e.nw
                }, f++) {
                e.nw = a.u[f].j;
                var h = a.u[f].map;
                e.nw = 6 >= a.Ot ? f : e.nw - d;
                try {
                    g.Bc(h, function(l) {
                        return function(m, n) {
                            c.push("req" + l.nw + "_" + n + "=" + encodeURIComponent(m))
                        }
                    }(e))
                } catch (l) {
                    c.push("req" + e.nw + "_type=" + encodeURIComponent("_badmap"))
                }
            }
            a.B = a.B.concat(a.u.splice(0, b));
            return c.join("&")
        },
        gmb = function(a) {
            a.yg || a.yp || (a.I = 1, a.yp = I8((0, g.Oa)(a.XP, a), 0), a.Iw = 0)
        },
        imb = function(a) {
            if (a.yg || a.yp || 3 <= a.Iw) return !1;
            a.I++;
            a.yp = I8((0, g.Oa)(a.XP, a), hmb(a, a.Iw));
            a.Iw++;
            return !0
        },
        S8 = function(a, b, c) {
            a.EH = c;
            a.Gn = b.xp;
            a.J || $lb(a)
        },
        T8 = function(a) {
            null != a.Pt && (g.Ea.clearTimeout(a.Pt), a.Pt = null)
        },
        hmb = function(a, b) {
            var c = 5E3 + Math.floor(1E4 * Math.random());
            a.isActive() || (c *= 2);
            return c * b
        },
        V8 = function(a, b) {
            if (2 == b || 9 == b) {
                var c = null;
                a.ji && (c = null);
                var d = (0, g.Oa)(a.Q7, a);
                c || (c = new g.tj("//www.google.com/images/cleardot.gif"), Z7(c));
                Qlb(c.toString(), 1E4, d)
            } else K8(2);
            jmb(a, b)
        },
        jmb = function(a, b) {
            a.j = 0;
            a.ji && a.ji.ZP(b);
            kmb(a);
            amb(a)
        },
        kmb = function(a) {
            a.j = 0;
            a.Gn = -1;
            if (a.ji)
                if (0 == a.B.length && 0 == a.u.length) a.ji.rI();
                else {
                    var b = g.sb(a.B),
                        c = g.sb(a.u);
                    a.B.length = 0;
                    a.u.length = 0;
                    a.ji.rI(b, c)
                }
        },
        R8 = function(a, b, c) {
            var d = g.Cj(c);
            if ("" != d.j) b && g.vj(d, b + "." + d.j), g.wj(d, d.C);
            else {
                var e = window.location;
                d = Ojb(e.protocol, b ? b + "." + e.hostname : e.hostname, +e.port, c)
            }
            a.aA && g.Bc(a.aA, function(f, h) {
                g.Bj(d, h, f)
            });
            g.Bj(d, "VER", a.Ot);
            U8(a, d);
            return d
        },
        lmb = function() {},
        mmb = function() {
            this.j = [];
            this.u = []
        },
        nmb = function(a) {
            g.db.call(this, "channelMessage");
            this.message = a
        },
        omb = function(a) {
            g.db.call(this, "channelError");
            this.error = a
        },
        pmb = function(a, b) {
            this.action = a;
            this.params = b || {}
        },
        W8 = function(a, b) {
            g.C.call(this);
            this.j = new g.eo(this.l6, 0, this);
            g.D(this, this.j);
            this.Di = 5E3;
            this.u = 0;
            if ("function" === typeof a) b && (a = (0, g.Oa)(a, b));
            else if (a && "function" === typeof a.handleEvent) a = (0, g.Oa)(a.handleEvent, a);
            else throw Error("Invalid listener argument");
            this.B = a
        },
        qmb = function() {},
        m8 = function() {
            if (!X8) {
                X8 = new g.tf(new qmb);
                var a = g.Rv("client_streamz_web_flush_count", -1); - 1 !== a && (X8.C = a)
            }
            return X8
        },
        rmb = function(a, b, c, d, e) {
            c = void 0 === c ? !1 : c;
            d = void 0 === d ? function() {
                return ""
            } : d;
            e = void 0 === e ? !1 : e;
            this.ya = a;
            this.J = b;
            this.B = new g.Po;
            this.u = new W8(this.o7, this);
            this.j = null;
            this.ea = !1;
            this.I = null;
            this.Z = "";
            this.T = this.D = 0;
            this.C = [];
            this.Pa = c;
            this.oa = d;
            this.Va = e;
            this.Ma = new xkb;
            this.Aa = new zkb;
            this.Ia = new Bkb;
            this.Ba = new Dkb;
            this.Ya = new Fkb;
            this.Xa = new Gkb
        },
        smb = function(a) {
            if (a.j) {
                var b = a.oa(),
                    c = a.j.Fn || {};
                b ? c["x-youtube-lounge-xsrf-token"] = b : delete c["x-youtube-lounge-xsrf-token"];
                a.j.Fn = c
            }
        },
        Y8 = function(a) {
            this.port = this.domain = "";
            this.j = "/api/lounge";
            this.u = !0;
            a = a || document.location.href;
            var b = Number(g.Oh(4, a)) || "";
            b && (this.port = ":" + b);
            this.domain = g.Th(a) || "";
            a = g.Wb();
            0 <= a.search("MSIE") && (a = a.match(/MSIE ([\d.]+)/)[1], 0 > g.Ub(a, "10.0") && (this.u = !1))
        },
        Z8 = function(a, b) {
            var c = a.j;
            a.u && (c = "https://" + a.domain + a.port + a.j);
            return g.ai(c + b, {})
        },
        tmb = function(a, b, c, d, e) {
            a = {
                format: "JSON",
                method: "POST",
                context: a,
                timeout: 5E3,
                withCredentials: !1,
                onSuccess: g.Pa(a.C, d, !0),
                onError: g.Pa(a.B, e),
                onTimeout: g.Pa(a.D, e)
            };
            c && (a.postParams = c, a.headers = {
                "Content-Type": "application/x-www-form-urlencoded"
            });
            return g.pw(b, a)
        },
        umb = function(a, b) {
            g.pd.call(this);
            var c = this;
            this.rd = a();
            this.rd.subscribe("handlerOpened", this.gZ, this);
            this.rd.subscribe("handlerClosed", this.eZ, this);
            this.rd.subscribe("handlerError", function(d, e) {
                c.onError(e)
            });
            this.rd.subscribe("handlerMessage", this.fZ, this);
            this.j = b
        },
        vmb = function(a, b, c) {
            var d = this;
            c = void 0 === c ? function() {
                return ""
            } : c;
            var e = void 0 === e ? new zlb : e;
            var f = void 0 === f ? new g.Po : f;
            this.pathPrefix = a;
            this.j = b;
            this.ya = c;
            this.D = f;
            this.T = null;
            this.Z = this.J = 0;
            this.channel = null;
            this.I = 0;
            this.B = new W8(function() {
                d.B.isActive();
                var h;
                0 === (null == (h = d.channel) ? void 0 : clb((new Clb(h, h.j)).j.u)) && d.connect(d.T, d.J)
            });
            this.C = {};
            this.u = {};
            this.ea = !1;
            this.logger = null;
            this.oa = [];
            this.Dg = void 0;
            this.Ma = new xkb;
            this.Aa = new zkb;
            this.Ia = new Bkb;
            this.Ba = new Dkb
        },
        wmb = function(a) {
            g.ad(a.channel, "m", function() {
                a.I = 3;
                a.B.reset();
                a.T = null;
                a.J = 0;
                for (var b = g.t(a.oa), c = b.next(); !c.done; c = b.next()) c = c.value, a.channel && a.channel.send(c);
                a.oa = [];
                a.ma("webChannelOpened");
                ykb(a.Ma, "WEB_CHANNEL")
            });
            g.ad(a.channel, "n", function() {
                a.I = 0;
                a.B.isActive() || a.ma("webChannelClosed");
                var b, c = null == (b = a.channel) ? void 0 : Dlb(new Clb(b, b.j));
                c && (a.oa = [].concat(g.u(c)));
                Akb(a.Aa, "WEB_CHANNEL")
            });
            g.ad(a.channel, "p", function(b) {
                var c = b.data;
                "gracefulReconnect" === c[0] ? (a.B.start(), a.channel && a.channel.close()) : a.ma("webChannelMessage", new pmb(c[0], c[1]));
                a.Dg = b.statusCode;
                Ckb(a.Ia, "WEB_CHANNEL")
            });
            g.ad(a.channel, "o", function() {
                401 === a.Dg || a.B.start();
                a.ma("webChannelError");
                Ekb(a.Ba, "WEB_CHANNEL")
            })
        },
        xmb = function(a) {
            var b = a.ya();
            b ? a.C["x-youtube-lounge-xsrf-token"] = b : delete a.C["x-youtube-lounge-xsrf-token"]
        },
        ymb = function(a) {
            g.pd.call(this);
            this.j = a();
            this.j.subscribe("webChannelOpened", this.jZ, this);
            this.j.subscribe("webChannelClosed", this.hZ, this);
            this.j.subscribe("webChannelError", this.onError, this);
            this.j.subscribe("webChannelMessage", this.iZ, this)
        },
        zmb = function(a, b, c, d, e) {
            function f() {
                return new rmb(Z8(a, "/bc"), b, !1, c, d)
            }
            c = void 0 === c ? function() {
                return ""
            } : c;
            return g.Qv("enable_mdx_web_channel_desktop") ? new ymb(function() {
                return new vmb(Z8(a, "/wc"), b, c)
            }) : new umb(f, e)
        },
        Dmb = function() {
            var a = Amb;
            Bmb();
            $8.push(a);
            Cmb()
        },
        a9 = function(a, b) {
            Bmb();
            var c = Emb(a, String(b));
            g.lb($8) ? Fmb(c) : (Cmb(), g.Fb($8, function(d) {
                d(c)
            }))
        },
        b9 = function(a) {
            a9("CP", a)
        },
        Bmb = function() {
            $8 || ($8 = g.Ha("yt.mdx.remote.debug.handlers_") || [], g.Fa("yt.mdx.remote.debug.handlers_", $8))
        },
        Fmb = function(a) {
            var b = (c9 + 1) % 50;
            c9 = b;
            d9[b] = a;
            e9 || (e9 = 49 == b)
        },
        Cmb = function() {
            var a = $8;
            if (d9[0]) {
                var b = e9 ? c9 : -1;
                do {
                    b = (b + 1) % 50;
                    var c = d9[b];
                    g.Fb(a, function(d) {
                        d(c)
                    })
                } while (b != c9);
                d9 = Array(50);
                c9 = -1;
                e9 = !1
            }
        },
        Emb = function(a, b) {
            var c = (Date.now() - Gmb) / 1E3;
            c.toFixed && (c = c.toFixed(3));
            var d = [];
            d.push("[", c + "s", "] ");
            d.push("[", "yt.mdx.remote", "] ");
            d.push(a + ": " + b, "\n");
            return d.join("")
        },
        f9 = function(a) {
            g.LB.call(this);
            this.I = a;
            this.screens = []
        },
        Hmb = function(a, b) {
            var c = a.get(b.uuid) || a.get(b.id);
            if (c) return a = c.name, c.id = b.id || c.id, c.name = b.name, c.token = b.token, c.uuid = b.uuid || c.uuid, c.name != a;
            a.screens.push(b);
            return !0
        },
        Imb = function(a, b) {
            var c = a.screens.length != b.length;
            a.screens = g.wm(a.screens, function(f) {
                return !!$jb(b, f)
            });
            for (var d = 0, e = b.length; d < e; d++) c = Hmb(a, b[d]) || c;
            return c
        },
        Jmb = function(a, b) {
            var c = a.screens.length;
            a.screens = g.wm(a.screens, function(d) {
                return !(d || b ? !d != !b ? 0 : d.id == b.id : 1)
            });
            return a.screens.length < c
        },
        Kmb = function(a, b, c, d, e) {
            g.LB.call(this);
            this.B = a;
            this.J = b;
            this.C = c;
            this.I = d;
            this.D = e;
            this.u = 0;
            this.j = null;
            this.Dc = NaN
        },
        h9 = function(a) {
            f9.call(this, "LocalScreenService");
            this.u = a;
            this.j = NaN;
            g9(this);
            this.info("Initializing with " + Xjb(this.screens))
        },
        Lmb = function(a) {
            if (a.screens.length) {
                var b = g.Fg(a.screens, function(d) {
                        return d.id
                    }),
                    c = Z8(a.u, "/pairing/get_lounge_token_batch");
                tmb(a.u, c, {
                    screen_ids: b.join(",")
                }, (0, g.Oa)(a.e2, a), (0, g.Oa)(a.d2, a))
            }
        },
        g9 = function(a) {
            if (g.Qv("deprecate_pair_servlet_enabled")) return Imb(a, []);
            var b = Wjb(gkb());
            b = g.wm(b, function(c) {
                return !c.uuid
            });
            return Imb(a, b)
        },
        i9 = function(a, b) {
            ikb(g.Fg(a.screens, Ujb));
            b && hkb()
        },
        Nmb = function(a, b) {
            g.LB.call(this);
            this.I = b;
            b = (b = g.LA("yt-remote-online-screen-ids") || "") ? b.split(",") : [];
            for (var c = {}, d = this.I(), e = d.length, f = 0; f < e; ++f) {
                var h = d[f].id;
                c[h] = g.kb(b, h)
            }
            this.j = c;
            this.D = a;
            this.B = this.C = NaN;
            this.u = null;
            Mmb("Initialized with " + g.Hh(this.j))
        },
        Omb = function(a, b, c) {
            var d = Z8(a.D, "/pairing/get_screen_availability");
            tmb(a.D, d, {
                lounge_token: b.token
            }, (0, g.Oa)(function(e) {
                e = e.screens || [];
                for (var f = e.length, h = 0; h < f; ++h)
                    if (e[h].loungeToken == b.token) {
                        c("online" == e[h].status);
                        return
                    }
                c(!1)
            }, a), (0, g.Oa)(function() {
                c(!1)
            }, a))
        },
        Qmb = function(a, b) {
            a: if (Ljb(b) != Ljb(a.j)) var c = !1;
                else {
                    c = g.Hc(b);
                    for (var d = c.length, e = 0; e < d; ++e)
                        if (!a.j[c[e]]) {
                            c = !1;
                            break a
                        }
                    c = !0
                }c || (Mmb("Updated online screens: " + g.Hh(a.j)), a.j = b, a.ma("screenChange"));Pmb(a)
        },
        j9 = function(a) {
            isNaN(a.B) || g.mw(a.B);
            a.B = g.kw((0, g.Oa)(a.EN, a), 0 < a.C && a.C < g.Qa() ? 2E4 : 1E4)
        },
        Mmb = function(a) {
            a9("OnlineScreenService", a)
        },
        Rmb = function(a) {
            var b = {};
            g.Fb(a.I(), function(c) {
                c.token ? b[c.token] = c.id : this.Of("Requesting availability of screen w/o lounge token.")
            });
            return b
        },
        Pmb = function(a) {
            a = g.Hc(g.Cc(a.j, function(b) {
                return b
            }));
            g.Cb(a);
            a.length ? g.KA("yt-remote-online-screen-ids", a.join(","), 60) : g.MA("yt-remote-online-screen-ids")
        },
        k9 = function(a, b) {
            b = void 0 === b ? !1 : b;
            f9.call(this, "ScreenService");
            this.C = a;
            this.J = b;
            this.j = this.u = null;
            this.B = [];
            this.D = {};
            Smb(this)
        },
        Umb = function(a, b, c, d, e, f) {
            a.info("getAutomaticScreenByIds " + c + " / " + b);
            c || (c = a.D[b]);
            var h = a.rk(),
                l = c ? g8(h, c) : null;
            c && (a.J || l) || (l = g8(h, b));
            if (l) {
                l.uuid = b;
                var m = l9(a, l);
                Omb(a.j, m, function(n) {
                    e(n ? m : null)
                })
            } else c ? Tmb(a, c, (0, g.Oa)(function(n) {
                var p = l9(this, new d8({
                    name: d,
                    screenId: c,
                    loungeToken: n,
                    dialId: b || ""
                }));
                Omb(this.j, p, function(q) {
                    e(q ? p : null)
                })
            }, a), f) : e(null)
        },
        Vmb = function(a, b) {
            for (var c = a.screens.length, d = 0; d < c; ++d)
                if (a.screens[d].name == b) return a.screens[d];
            return null
        },
        Wmb = function(a, b, c) {
            Omb(a.j, b, c)
        },
        Tmb = function(a, b, c, d) {
            a.info("requestLoungeToken_ for " + b);
            var e = {
                postParams: {
                    screen_ids: b
                },
                method: "POST",
                context: a,
                onSuccess: function(f, h) {
                    f = h && h.screens || [];
                    f[0] && f[0].screenId == b ? c(f[0].loungeToken) : d(Error("Missing lounge token in token response"))
                },
                onError: function() {
                    d(Error("Request screen lounge token failed"))
                }
            };
            g.pw(Z8(a.C, "/pairing/get_lounge_token_batch"), e)
        },
        Xmb = function(a) {
            a.screens = a.u.rk();
            var b = a.D,
                c = {},
                d;
            for (d in b) c[b[d]] = d;
            b = a.screens.length;
            for (d = 0; d < b; ++d) {
                var e = a.screens[d];
                e.uuid = c[e.id] || ""
            }
            a.info("Updated manual screens: " + Xjb(a.screens))
        },
        Smb = function(a) {
            Ymb(a);
            a.u = new h9(a.C);
            a.u.subscribe("screenChange", (0, g.Oa)(a.q2, a));
            Xmb(a);
            a.J || (a.B = Wjb(g.LA("yt-remote-automatic-screen-cache") || []));
            Ymb(a);
            a.info("Initializing automatic screens: " + Xjb(a.B));
            a.j = new Nmb(a.C, (0, g.Oa)(a.rk, a, !0));
            a.j.subscribe("screenChange", (0, g.Oa)(function() {
                this.ma("onlineScreenChange")
            }, a))
        },
        l9 = function(a, b) {
            var c = a.get(b.id);
            c ? (c.uuid = b.uuid, b = c) : ((c = g8(a.B, b.uuid)) ? (c.id = b.id, c.token = b.token, b = c) : a.B.push(b), a.J || Zmb(a));
            Ymb(a);
            a.D[b.uuid] = b.id;
            g.KA("yt-remote-device-id-map", a.D, 31536E3);
            return b
        },
        Zmb = function(a) {
            a = g.wm(a.B, function(b) {
                return "shortLived" != b.idType
            });
            g.KA("yt-remote-automatic-screen-cache", g.Fg(a, Ujb))
        },
        Ymb = function(a) {
            a.D = g.LA("yt-remote-device-id-map") || {}
        },
        m9 = function(a, b, c) {
            g.LB.call(this);
            this.Ba = c;
            this.C = a;
            this.u = b;
            this.j = null
        },
        n9 = function(a, b) {
            a.j = b;
            a.ma("sessionScreen", a.j)
        },
        $mb = function(a, b) {
            a.j && (a.j.token = b, l9(a.C, a.j));
            a.ma("sessionScreen", a.j)
        },
        o9 = function(a, b) {
            a9(a.Ba, b)
        },
        p9 = function(a, b, c) {
            m9.call(this, a, b, "CastSession");
            var d = this;
            this.config_ = c;
            this.B = null;
            this.oa = (0, g.Oa)(this.oZ, this);
            this.Aa = (0, g.Oa)(this.D6, this);
            this.ea = g.kw(function() {
                anb(d, null)
            }, 12E4);
            this.J = this.D = this.I = this.T = 0;
            this.ya = !1;
            this.Z = "unknown"
        },
        cnb = function(a, b) {
            g.mw(a.J);
            a.J = 0;
            0 == b ? bnb(a) : a.J = g.kw(function() {
                bnb(a)
            }, b)
        },
        bnb = function(a) {
            dnb(a, "getLoungeToken");
            g.mw(a.D);
            a.D = g.kw(function() {
                enb(a, null)
            }, 3E4)
        },
        dnb = function(a, b) {
            a.info("sendYoutubeMessage_: " + b + " " + g.Hh());
            var c = {};
            c.type = b;
            a.B ? a.B.sendMessage("urn:x-cast:com.google.youtube.mdx", c, function() {}, (0, g.Oa)(function() {
                o9(this, "Failed to send message: " + b + ".")
            }, a)) : o9(a, "Sending yt message without session: " + g.Hh(c))
        },
        fnb = function(a, b) {
            b ? (a.info("onConnectedScreenId_: Received screenId: " + b), a.j && a.j.id == b || a.US(b, function(c) {
                n9(a, c)
            }, function() {
                return a.ej()
            }, 5)) : a.ej(Error("Waiting for session status timed out."))
        },
        hnb = function(a, b, c) {
            a.info("onConnectedScreenData_: Received screenData: " + JSON.stringify(b));
            var d = new d8(b);
            gnb(a, d, function(e) {
                e ? (a.ya = !0, l9(a.C, d), n9(a, d), a.Z = "unknown", cnb(a, c)) : (g.Vv(Error("CastSession, RemoteScreen from screenData: " + JSON.stringify(b) + " is not online.")), a.ej())
            }, 5)
        },
        anb = function(a, b) {
            g.mw(a.ea);
            a.ea = 0;
            b ? a.config_.enableCastLoungeToken && b.loungeToken ? b.deviceId ? a.j && a.j.uuid == b.deviceId || (b.loungeTokenRefreshIntervalMs ? hnb(a, {
                    name: a.u.friendlyName,
                    screenId: b.screenId,
                    loungeToken: b.loungeToken,
                    dialId: b.deviceId,
                    screenIdType: "shortLived"
                }, b.loungeTokenRefreshIntervalMs) : (g.Vv(Error("No loungeTokenRefreshIntervalMs presents in mdxSessionStatusData: " + JSON.stringify(b) + ".")), fnb(a, b.screenId))) : (g.Vv(Error("No device id presents in mdxSessionStatusData: " + JSON.stringify(b) + ".")), fnb(a, b.screenId)) :
                fnb(a, b.screenId) : a.ej(Error("Waiting for session status timed out."))
        },
        enb = function(a, b) {
            g.mw(a.D);
            a.D = 0;
            var c = null;
            if (b)
                if (b.loungeToken) {
                    var d;
                    (null == (d = a.j) ? void 0 : d.token) == b.loungeToken && (c = "staleLoungeToken")
                } else c = "missingLoungeToken";
            else c = "noLoungeTokenResponse";
            c ? (a.info("Did not receive a new lounge token in onLoungeToken_ with data: " + (JSON.stringify(b) + ", error: " + c)), a.Z = c, cnb(a, 3E4)) : ($mb(a, b.loungeToken), a.ya = !1, a.Z = "unknown", cnb(a, b.loungeTokenRefreshIntervalMs))
        },
        gnb = function(a, b, c, d) {
            g.mw(a.I);
            a.I = 0;
            Wmb(a.C, b, function(e) {
                e || 0 > d ? c(e) : a.I = g.kw(function() {
                    gnb(a, b, c, d - 1)
                }, 300)
            })
        },
        inb = function(a) {
            g.mw(a.T);
            a.T = 0;
            g.mw(a.I);
            a.I = 0;
            g.mw(a.ea);
            a.ea = 0;
            g.mw(a.D);
            a.D = 0;
            g.mw(a.J);
            a.J = 0
        },
        q9 = function(a, b, c, d) {
            m9.call(this, a, b, "DialSession");
            this.config_ = d;
            this.B = this.T = null;
            this.Aa = "";
            this.Pa = c;
            this.Ma = null;
            this.ea = function() {};
            this.Z = NaN;
            this.Ia = (0, g.Oa)(this.pZ, this);
            this.D = function() {};
            this.J = this.I = 0;
            this.oa = !1;
            this.ya = "unknown"
        },
        r9 = function(a) {
            var b;
            return !!(a.config_.enableDialLoungeToken && (null == (b = a.B) ? 0 : b.getDialAppInfo))
        },
        jnb = function(a) {
            a.D = a.C.eQ(a.Aa, a.u.label, a.u.friendlyName, r9(a), function(b, c) {
                a.D = function() {};
                a.oa = !0;
                n9(a, b);
                "shortLived" == b.idType && 0 < c && s9(a, c)
            }, function(b) {
                a.D = function() {};
                a.ej(b)
            })
        },
        knb = function(a) {
            var b = {};
            b.pairingCode = a.Aa;
            b.theme = a.Pa;
            kkb() && (b.env_useStageMdx = 1);
            return g.Zh(b)
        },
        lnb = function(a) {
            return new Promise(function(b) {
                a.Aa = Yjb();
                if (a.Ma) {
                    var c = new chrome.cast.DialLaunchResponse(!0, knb(a));
                    b(c);
                    jnb(a)
                } else a.ea = function() {
                    g.mw(a.Z);
                    a.ea = function() {};
                    a.Z = NaN;
                    var d = new chrome.cast.DialLaunchResponse(!0, knb(a));
                    b(d);
                    jnb(a)
                }, a.Z = g.kw(function() {
                    a.ea()
                }, 100)
            })
        },
        nnb = function(a, b, c) {
            a.info("initOnConnectedScreenDataPromise_: Received screenData: " + JSON.stringify(b));
            var d = new d8(b);
            return (new Promise(function(e) {
                mnb(a, d, function(f) {
                    f ? (a.oa = !0, l9(a.C, d), n9(a, d), s9(a, c)) : g.Vv(Error("DialSession, RemoteScreen from screenData: " + JSON.stringify(b) + " is not online."));
                    e(f)
                }, 5)
            })).then(function(e) {
                return e ? new chrome.cast.DialLaunchResponse(!1) : lnb(a)
            })
        },
        onb = function(a, b) {
            var c = a.T.receiver.label,
                d = a.u.friendlyName;
            return (new Promise(function(e) {
                Umb(a.C, c, b, d, function(f) {
                    f && f.token && n9(a, f);
                    e(f)
                }, function(f) {
                    o9(a, "Failed to get DIAL screen: " + f);
                    e(null)
                })
            })).then(function(e) {
                return e && e.token ? new chrome.cast.DialLaunchResponse(!1) : lnb(a)
            })
        },
        mnb = function(a, b, c, d) {
            g.mw(a.I);
            a.I = 0;
            Wmb(a.C, b, function(e) {
                e || 0 > d ? c(e) : a.I = g.kw(function() {
                    mnb(a, b, c, d - 1)
                }, 300)
            })
        },
        s9 = function(a, b) {
            a.info("getDialAppInfoWithTimeout_ " + b);
            r9(a) && (g.mw(a.J), a.J = 0, 0 == b ? pnb(a) : a.J = g.kw(function() {
                pnb(a)
            }, b))
        },
        pnb = function(a) {
            r9(a) && a.B.getDialAppInfo(function(b) {
                a.info("getDialAppInfo dialLaunchData: " + JSON.stringify(b));
                b = b.extraData || {};
                var c = null;
                if (b.loungeToken) {
                    var d;
                    (null == (d = a.j) ? void 0 : d.token) == b.loungeToken && (c = "staleLoungeToken")
                } else c = "missingLoungeToken";
                c ? (a.ya = c, s9(a, 3E4)) : (a.oa = !1, a.ya = "unknown", $mb(a, b.loungeToken), s9(a, b.loungeTokenRefreshIntervalMs))
            }, function(b) {
                a.info("getDialAppInfo error: " + b);
                a.ya = "noLoungeTokenResponse";
                s9(a, 3E4)
            })
        },
        qnb = function(a) {
            g.mw(a.I);
            a.I = 0;
            g.mw(a.J);
            a.J = 0;
            a.D();
            a.D = function() {};
            g.mw(a.Z)
        },
        t9 = function(a, b) {
            m9.call(this, a, b, "ManualSession");
            this.B = g.kw((0, g.Oa)(this.vy, this, null), 150)
        },
        u9 = function(a, b) {
            g.LB.call(this);
            this.config_ = b;
            this.u = a;
            this.T = b.appId || "233637DE";
            this.C = b.theme || "cl";
            this.Z = b.disableCastApi || !1;
            this.I = b.forceMirroring || !1;
            this.j = null;
            this.J = !1;
            this.B = [];
            this.D = (0, g.Oa)(this.z5, this)
        },
        rnb = function(a, b) {
            return b ? g.ib(a.B, function(c) {
                return e8(b, c.label)
            }, a) : null
        },
        v9 = function(a) {
            a9("Controller", a)
        },
        Amb = function(a) {
            window.chrome && chrome.cast && chrome.cast.logMessage && chrome.cast.logMessage(a)
        },
        w9 = function(a) {
            return a.J || !!a.B.length || !!a.j
        },
        x9 = function(a, b, c) {
            b != a.j && (g.Za(a.j), (a.j = b) ? (c ? a.ma("yt-remote-cast2-receiver-resumed",
                b.u) : a.ma("yt-remote-cast2-receiver-selected", b.u), b.subscribe("sessionScreen", (0, g.Oa)(a.sV, a, b)), b.subscribe("sessionFailed", function() {
                return snb(a, b)
            }), b.j ? a.ma("yt-remote-cast2-session-change", b.j) : c && a.j.vy(null)) : a.ma("yt-remote-cast2-session-change", null))
        },
        snb = function(a, b) {
            a.j == b && a.ma("yt-remote-cast2-session-failed")
        },
        tnb = function(a) {
            var b = a.u.dQ(),
                c = a.j && a.j.u;
            a = g.Fg(b, function(d) {
                c && e8(d, c.label) && (c = null);
                var e = d.uuid ? d.uuid : d.id,
                    f = rnb(this, d);
                f ? (f.label = e, f.friendlyName = d.name) : (f = new chrome.cast.Receiver(e, d.name), f.receiverType = chrome.cast.ReceiverType.CUSTOM);
                return f
            }, a);
            c && (c.receiverType != chrome.cast.ReceiverType.CUSTOM && (c = new chrome.cast.Receiver(c.label, c.friendlyName), c.receiverType = chrome.cast.ReceiverType.CUSTOM), a.push(c));
            return a
        },
        Anb = function(a, b, c, d) {
            d.disableCastApi ? y9("Cannot initialize because disabled by Mdx config.") : unb() ? vnb(b, d) && (wnb(!0), window.chrome && chrome.cast && chrome.cast.isAvailable ? xnb(a, c) : (window.__onGCastApiAvailable = function(e, f) {
                e ? xnb(a, c) : (z9("Failed to load cast API: " + f), ynb(!1), wnb(!1), g.MA("yt-remote-cast-available"), g.MA("yt-remote-cast-receiver"),
                    znb(), c(!1))
            }, d.loadCastApiSetupScript ? g.OA("https://www.gstatic.com/cv/js/sender/v1/cast_sender.js") : 0 <= window.navigator.userAgent.indexOf("Android") && 0 <= window.navigator.userAgent.indexOf("Chrome/") && window.navigator.presentation ? 60 <= lkb() && ukb() : !window.chrome || !window.navigator.presentation || 0 <= window.navigator.userAgent.indexOf("Edge") ? pkb() : 89 <= lkb() ? wkb() : (tkb(), l8(vkb.map(qkb))))) : y9("Cannot initialize because not running Chrome")
        },
        znb = function() {
            y9("dispose");
            var a = A9();
            a && a.dispose();
            g.Fa("yt.mdx.remote.cloudview.instance_", null);
            Bnb(!1);
            g.Lz(Cnb);
            Cnb.length = 0
        },
        B9 = function() {
            return !!g.LA("yt-remote-cast-installed")
        },
        Dnb = function() {
            var a = g.LA("yt-remote-cast-receiver");
            return a ? a.friendlyName : null
        },
        Enb = function() {
            y9("clearCurrentReceiver");
            g.MA("yt-remote-cast-receiver")
        },
        Fnb = function() {
            return B9() ? A9() ? A9().getCastSession() : (z9("getCastSelector: Cast is not initialized."), null) : (z9("getCastSelector: Cast API is not installed!"), null)
        },
        Gnb = function() {
            B9() ? A9() ? C9() ? (y9("Requesting cast selector."), A9().requestSession()) : (y9("Wait for cast API to be ready to request the session."), Cnb.push(g.Kz("yt-remote-cast2-api-ready", Gnb))) : z9("requestCastSelector: Cast is not initialized.") : z9("requestCastSelector: Cast API is not installed!")
        },
        D9 = function(a, b) {
            C9() ? A9().setConnectedScreenStatus(a, b) : z9("setConnectedScreenStatus called before ready.")
        },
        unb = function() {
            var a = 0 <= g.Wb().search(/ (CrMo|Chrome|CriOS)\//);
            return g.IF || a
        },
        Hnb = function(a, b) {
            A9().init(a, b)
        },
        vnb = function(a, b) {
            var c = !1;
            A9() || (a = new u9(a, b), a.subscribe("yt-remote-cast2-availability-change", function(d) {
                g.KA("yt-remote-cast-available", d);
                b8("yt-remote-cast2-availability-change", d)
            }), a.subscribe("yt-remote-cast2-receiver-selected", function(d) {
                y9("onReceiverSelected: " + d.friendlyName);
                g.KA("yt-remote-cast-receiver", d);
                b8("yt-remote-cast2-receiver-selected", d)
            }), a.subscribe("yt-remote-cast2-receiver-resumed", function(d) {
                y9("onReceiverResumed: " + d.friendlyName);
                g.KA("yt-remote-cast-receiver", d);
                b8("yt-remote-cast2-receiver-resumed", d)
            }), a.subscribe("yt-remote-cast2-session-change", function(d) {
                y9("onSessionChange: " + f8(d));
                d || g.MA("yt-remote-cast-receiver");
                b8("yt-remote-cast2-session-change", d)
            }), g.Fa("yt.mdx.remote.cloudview.instance_", a), c = !0);
            y9("cloudview.createSingleton_: " + c);
            return c
        },
        A9 = function() {
            return g.Ha("yt.mdx.remote.cloudview.instance_")
        },
        xnb = function(a, b) {
            ynb(!0);
            wnb(!1);
            Hnb(a, function(c) {
                c ? (Bnb(!0), g.Mz("yt-remote-cast2-api-ready")) : (z9("Failed to initialize cast API."), ynb(!1), g.MA("yt-remote-cast-available"), g.MA("yt-remote-cast-receiver"), znb());
                b(c)
            })
        },
        y9 = function(a) {
            a9("cloudview", a)
        },
        z9 = function(a) {
            a9("cloudview", a)
        },
        ynb = function(a) {
            y9("setCastInstalled_ " + a);
            g.KA("yt-remote-cast-installed", a)
        },
        C9 = function() {
            return !!g.Ha("yt.mdx.remote.cloudview.apiReady_")
        },
        Bnb = function(a) {
            y9("setApiReady_ " + a);
            g.Fa("yt.mdx.remote.cloudview.apiReady_", a)
        },
        wnb = function(a) {
            g.Fa("yt.mdx.remote.cloudview.initializing_", a)
        },
        E9 = function(a) {
            this.index = -1;
            this.videoId = this.listId = "";
            this.volume = this.playerState = -1;
            this.muted = !1;
            this.audioTrackId = null;
            this.I = this.J = 0;
            this.trackData = null;
            this.yk = this.Fo = !1;
            this.T = this.D = this.j = this.C = 0;
            this.B = NaN;
            this.u = !1;
            this.reset(a)
        },
        Inb = function(a) {
            a.audioTrackId = null;
            a.trackData = null;
            a.playerState = -1;
            a.Fo = !1;
            a.yk = !1;
            a.J = 0;
            a.I = g.Qa();
            a.C = 0;
            a.j = 0;
            a.D = 0;
            a.T = 0;
            a.B = NaN;
            a.u = !1
        },
        F9 = function(a) {
            return a.Zc() ? (g.Qa() - a.I) / 1E3 : 0
        },
        G9 = function(a, b) {
            a.J = b;
            a.I = g.Qa()
        },
        H9 = function(a) {
            switch (a.playerState) {
                case 1:
                case 1081:
                    return (g.Qa() - a.I) / 1E3 + a.J;
                case -1E3:
                    return 0
            }
            return a.J
        },
        I9 = function(a, b, c) {
            var d = a.videoId;
            a.videoId = b;
            a.index = c;
            b != d && Inb(a)
        },
        Jnb = function(a) {
            var b = {};
            b.index = a.index;
            b.listId = a.listId;
            b.videoId = a.videoId;
            b.playerState = a.playerState;
            b.volume = a.volume;
            b.muted = a.muted;
            b.audioTrackId = a.audioTrackId;
            b.trackData = g.Vc(a.trackData);
            b.hasPrevious = a.Fo;
            b.hasNext = a.yk;
            b.playerTime = a.J;
            b.playerTimeAt = a.I;
            b.seekableStart = a.C;
            b.seekableEnd = a.j;
            b.duration = a.D;
            b.loadedTime = a.T;
            b.liveIngestionTime = a.B;
            return b
        },
        K9 = function(a, b) {
            g.LB.call(this);
            this.B = 0;
            this.C = a;
            this.I = [];
            this.D = new mmb;
            this.u = this.j = null;
            this.Z = (0, g.Oa)(this.q4, this);
            this.J = (0, g.Oa)(this.lC, this);
            this.T = (0, g.Oa)(this.p4, this);
            this.ea = (0, g.Oa)(this.s4, this);
            var c = 0;
            a ? (c = a.getProxyState(), 3 != c && (a.subscribe("proxyStateChange", this.aO, this), Knb(this))) : c = 3;
            0 != c && (b ? this.aO(c) : g.kw((0, g.Oa)(function() {
                this.aO(c)
            }, this), 0));
            (a = Fnb()) && J9(this, a);
            this.subscribe("yt-remote-cast2-session-change", this.ea)
        },
        L9 = function(a) {
            return new E9(a.C.getPlayerContextData())
        },
        Knb = function(a) {
            g.Fb("nowAutoplaying autoplayDismissed remotePlayerChange remoteQueueChange autoplayModeChange autoplayUpNext previousNextChange multiStateLoopEnabled loopModeChange".split(" "), function(b) {
                this.I.push(this.C.subscribe(b, g.Pa(this.x5, b), this))
            }, a)
        },
        Lnb = function(a) {
            g.Fb(a.I, function(b) {
                this.C.unsubscribeByKey(b)
            }, a);
            a.I.length = 0
        },
        M9 = function(a) {
            return 1 == a.getState()
        },
        N9 = function(a, b) {
            var c = a.D;
            50 > c.j.length + c.u.length && a.D.u.push(b)
        },
        Mnb = function(a, b, c) {
            var d = L9(a);
            G9(d, c); - 1E3 != d.playerState && (d.playerState = b);
            O9(a, d)
        },
        P9 = function(a, b, c) {
            a.C.sendMessage(b, c)
        },
        O9 = function(a, b) {
            Lnb(a);
            a.C.setPlayerContextData(Jnb(b));
            Knb(a)
        },
        J9 = function(a, b) {
            a.u && (a.u.removeUpdateListener(a.Z), a.u.removeMediaListener(a.J), a.lC(null));
            a.u = b;
            a.u && (b9("Setting cast session: " + a.u.sessionId), a.u.addUpdateListener(a.Z), a.u.addMediaListener(a.J), a.u.media.length && a.lC(a.u.media[0]))
        },
        Nnb = function(a) {
            var b = a.j.media,
                c = a.j.customData;
            if (b && c) {
                var d = L9(a);
                b.contentId != d.videoId && b9("Cast changing video to: " + b.contentId);
                d.videoId = b.contentId;
                d.playerState = c.playerState;
                G9(d, a.j.getEstimatedTime());
                O9(a, d)
            } else b9("No cast media video. Ignoring state update.")
        },
        Q9 = function(a, b, c) {
            return (0, g.Oa)(function(d) {
                this.Of("Failed to " + b + " with cast v2 channel. Error code: " + d.code);
                d.code != chrome.cast.ErrorCode.TIMEOUT && (this.Of("Retrying " + b + " using MDx browser channel."), P9(this, b, c))
            }, a)
        },
        T9 = function(a, b, c, d) {
            d = void 0 === d ? !1 : d;
            g.LB.call(this);
            var e = this;
            this.I = NaN;
            this.Aa = !1;
            this.Z = this.T = this.oa = this.ya = NaN;
            this.ea = [];
            this.D = this.J = this.C = this.j = this.u = null;
            this.Ma = a;
            this.Ia = d;
            this.ea.push(g.qz(window, "beforeunload", function() {
                e.Hx(2)
            }));
            this.B = [];
            this.j = new E9;
            this.Pa = b.id;
            this.Ba = b.idType;
            this.u = zmb(this.Ma, c, this.iQ, "shortLived" == this.Ba, this.Pa);
            this.u.Ra("channelOpened", function() {
                Onb(e)
            });
            this.u.Ra("channelClosed", function() {
                R9("Channel closed");
                isNaN(e.I) ? j8(!0) : j8();
                e.dispose()
            });
            this.u.Ra("channelError", function(f) {
                j8();
                isNaN(e.oB()) ? (1 == f && "shortLived" == e.Ba && e.ma("browserChannelAuthError", f), R9("Channel error: " + f + " without reconnection"), e.dispose()) : (e.Aa = !0, R9("Channel error: " + f + " with reconnection in " + e.oB() + " ms"), S9(e, 2))
            });
            this.u.Ra("channelMessage", function(f) {
                Pnb(e, f)
            });
            this.u.Kq(b.token);
            this.subscribe("remoteQueueChange", function() {
                var f = e.j.videoId;
                g.NA() && g.KA("yt-remote-session-video-id", f)
            })
        },
        Qnb = function(a) {
            return g.ib(a.B, function(b) {
                return "LOUNGE_SCREEN" == b.type
            })
        },
        R9 = function(a) {
            a9("conn", a)
        },
        S9 = function(a, b) {
            a.ma("proxyStateChange", b)
        },
        Rnb = function(a) {
            a.I = g.kw(function() {
                R9("Connecting timeout");
                a.Hx(1)
            }, 2E4)
        },
        Snb = function(a) {
            g.mw(a.I);
            a.I = NaN
        },
        Tnb = function(a) {
            g.mw(a.ya);
            a.ya = NaN
        },
        Vnb = function(a) {
            Unb(a);
            a.oa = g.kw(function() {
                U9(a, "getNowPlaying")
            }, 2E4)
        },
        Unb = function(a) {
            g.mw(a.oa);
            a.oa = NaN
        },
        Onb = function(a) {
            R9("Channel opened");
            a.Aa && (a.Aa = !1, Tnb(a), a.ya = g.kw(function() {
                R9("Timing out waiting for a screen.");
                a.Hx(1)
            }, 15E3))
        },
        Xnb = function(a, b) {
            var c = null;
            if (b) {
                var d = Qnb(a);
                d && (c = {
                    clientName: d.clientName,
                    deviceMake: d.brand,
                    deviceModel: d.model,
                    osVersion: d.osVersion
                })
            }
            g.Fa("yt.mdx.remote.remoteClient_", c);
            b && (Snb(a), Tnb(a));
            c = a.u.ey() && isNaN(a.I);
            b == c ? b && (S9(a, 1), U9(a, "getSubtitlesTrack")) : b ? (a.RS() && a.j.reset(), S9(a, 1), U9(a, "getNowPlaying"), Wnb(a)) : a.Hx(1)
        },
        Ynb = function(a, b) {
            var c = b.params.videoId;
            delete b.params.videoId;
            c == a.j.videoId && (g.Pc(b.params) ? a.j.trackData = null : a.j.trackData = b.params, a.ma("remotePlayerChange"))
        },
        Znb = function(a, b, c) {
            var d = b.params.videoId || b.params.video_id,
                e = parseInt(b.params.currentIndex, 10);
            a.j.listId = b.params.listId || a.j.listId;
            I9(a.j, d, e);
            a.ma("remoteQueueChange", c)
        },
        aob = function(a, b) {
            b.params = b.params || {};
            Znb(a, b, "NOW_PLAYING_MAY_CHANGE");
            $nb(a, b);
            a.ma("autoplayDismissed")
        },
        $nb = function(a, b) {
            var c = parseInt(b.params.currentTime || b.params.current_time, 10);
            G9(a.j, isNaN(c) ? 0 : c);
            c = parseInt(b.params.state, 10);
            c = isNaN(c) ? -1 : c; - 1 == c && -1E3 == a.j.playerState && (c = -1E3);
            a.j.playerState = c;
            c = Number(b.params.loadedTime);
            a.j.T = isNaN(c) ? 0 : c;
            a.j.Mk(Number(b.params.duration));
            c = a.j;
            var d = Number(b.params.liveIngestionTime);
            c.B = d;
            c.u = isNaN(d) ? !1 : !0;
            c = a.j;
            d = Number(b.params.seekableStartTime);
            b = Number(b.params.seekableEndTime);
            c.C = isNaN(d) ? 0 : d;
            c.j = isNaN(b) ? 0 : b;
            1 == a.j.playerState ? Vnb(a) : Unb(a);
            a.ma("remotePlayerChange")
        },
        bob = function(a, b) {
            if (-1E3 != a.j.playerState) {
                var c =
                    1085;
                switch (parseInt(b.params.adState, 10)) {
                    case 1:
                        c = 1081;
                        break;
                    case 2:
                        c = 1084;
                        break;
                    case 0:
                        c = 1083
                }
                a.j.playerState = c;
                b = parseInt(b.params.currentTime, 10);
                G9(a.j, isNaN(b) ? 0 : b);
                a.ma("remotePlayerChange")
            }
        },
        cob = function(a, b) {
            var c = "true" == b.params.muted;
            a.j.volume = parseInt(b.params.volume, 10);
            a.j.muted = c;
            a.ma("remotePlayerChange")
        },
        dob = function(a, b) {
            a.J = b.params.videoId;
            a.ma("nowAutoplaying", parseInt(b.params.timeout, 10))
        },
        eob = function(a, b) {
            a.J = b.params.videoId || null;
            a.ma("autoplayUpNext", a.J)
        },
        fob = function(a, b) {
            a.D = b.params.autoplayMode;
            a.ma("autoplayModeChange", a.D);
            "DISABLED" == a.D && a.ma("autoplayDismissed")
        },
        gob = function(a, b) {
            var c = "true" == b.params.hasNext;
            a.j.Fo = "true" == b.params.hasPrevious;
            a.j.yk = c;
            a.ma("previousNextChange")
        },
        Pnb = function(a, b) {
            b = b.message;
            b.params ? R9("Received: action=" + b.action + ", params=" + g.Hh(b.params)) : R9("Received: action=" + b.action + " {}");
            switch (b.action) {
                case "loungeStatus":
                    b = a8(b.params.devices);
                    a.B = g.Fg(b, function(d) {
                        return new c8(d)
                    });
                    b = !!g.ib(a.B, function(d) {
                        return "LOUNGE_SCREEN" == d.type
                    });
                    Xnb(a, b);
                    b = a.KT("mlm");
                    a.ma("multiStateLoopEnabled", b);
                    break;
                case "loungeScreenDisconnected":
                    g.qb(a.B, function(d) {
                        return "LOUNGE_SCREEN" == d.type
                    });
                    Xnb(a, !1);
                    break;
                case "remoteConnected":
                    var c = new c8(a8(b.params.device));
                    g.ib(a.B, function(d) {
                        return d.equals(c)
                    }) || Kjb(a.B, c);
                    break;
                case "remoteDisconnected":
                    c = new c8(a8(b.params.device));
                    g.qb(a.B, function(d) {
                        return d.equals(c)
                    });
                    break;
                case "gracefulDisconnect":
                    break;
                case "playlistModified":
                    Znb(a, b, "QUEUE_MODIFIED");
                    break;
                case "nowPlaying":
                    aob(a, b);
                    break;
                case "onStateChange":
                    $nb(a, b);
                    break;
                case "onAdStateChange":
                    bob(a, b);
                    break;
                case "onVolumeChanged":
                    cob(a, b);
                    break;
                case "onSubtitlesTrackChanged":
                    Ynb(a, b);
                    break;
                case "nowAutoplaying":
                    dob(a, b);
                    break;
                case "autoplayDismissed":
                    a.ma("autoplayDismissed");
                    break;
                case "autoplayUpNext":
                    eob(a, b);
                    break;
                case "onAutoplayModeChanged":
                    fob(a, b);
                    break;
                case "onHasPreviousNextChanged":
                    gob(a, b);
                    break;
                case "requestAssistedSignIn":
                    a.ma("assistedSignInRequested", b.params.authCode);
                    break;
                case "onLoopModeChanged":
                    a.ma("loopModeChange", b.params.loopMode);
                    break;
                default:
                    R9("Unrecognized action: " + b.action)
            }
        },
        Wnb = function(a) {
            g.mw(a.Z);
            a.Z = g.kw(function() {
                a.Hx(1)
            }, 864E5)
        },
        U9 = function(a, b, c) {
            c ? R9("Sending: action=" + b + ", params=" + g.Hh(c)) : R9("Sending: action=" + b);
            a.u.sendMessage(b, c)
        },
        hob = function(a) {
            f9.call(this, "ScreenServiceProxy");
            this.Ng = a;
            this.j = [];
            this.j.push(this.Ng.$_s("screenChange", (0, g.Oa)(this.tZ, this)));
            this.j.push(this.Ng.$_s("onlineScreenChange", (0, g.Oa)(this.f5, this)))
        },
        mob = function(a, b) {
            jkb();
            if (!k8 || !k8.get("yt-remote-disable-remote-module-for-dev")) {
                b = g.L("MDX_CONFIG") || b;
                akb();
                ekb();
                V9 || (V9 = new Y8(b ? b.loungeApiHost : void 0), kkb() && (V9.j = "/api/loungedev"));
                W9 || (W9 = g.Ha("yt.mdx.remote.deferredProxies_") || [], g.Fa("yt.mdx.remote.deferredProxies_", W9));
                iob();
                var c = X9();
                if (!c) {
                    var d = new k9(V9, b ? b.disableAutomaticScreenCache || !1 : !1);
                    g.Fa("yt.mdx.remote.screenService_", d);
                    c = X9();
                    var e = {};
                    b && (e = {
                        appId: b.appId,
                        disableDial: b.disableDial,
                        theme: b.theme,
                        loadCastApiSetupScript: b.loadCastApiSetupScript,
                        disableCastApi: b.disableCastApi,
                        enableDialLoungeToken: b.enableDialLoungeToken,
                        enableCastLoungeToken: b.enableCastLoungeToken,
                        forceMirroring: b.forceMirroring
                    });
                    g.Fa("yt.mdx.remote.enableConnectWithInitialState_", b ? b.enableConnectWithInitialState || !1 : !1);
                    Anb(a, d, function(f) {
                        f ? Y9() && D9(Y9(), "YouTube TV") : d.subscribe("onlineScreenChange", function() {
                            b8("yt-remote-receiver-availability-change")
                        })
                    }, e)
                }
                b && !g.Ha("yt.mdx.remote.initialized_") && (g.Fa("yt.mdx.remote.initialized_", !0), Z9("Initializing: " + g.Hh(b)),
                    $9.push(g.Kz("yt-remote-cast2-api-ready", function() {
                        b8("yt-remote-api-ready")
                    })), $9.push(g.Kz("yt-remote-cast2-availability-change", function() {
                        b8("yt-remote-receiver-availability-change")
                    })), $9.push(g.Kz("yt-remote-cast2-receiver-selected", function() {
                        a$(null);
                        b8("yt-remote-auto-connect", "cast-selector-receiver")
                    })), $9.push(g.Kz("yt-remote-cast2-receiver-resumed", function() {
                        b8("yt-remote-receiver-resumed", "cast-selector-receiver")
                    })), $9.push(g.Kz("yt-remote-cast2-session-change", job)), $9.push(g.Kz("yt-remote-connection-change", function(f) {
                        f ? D9(Y9(), "YouTube TV") : b$() || (D9(null, null), Enb())
                    })), $9.push(g.Kz("yt-remote-cast2-session-failed", function() {
                        b8("yt-remote-connection-failed")
                    })), a = kob(), b.isAuto && (a.id += "#dial"), e = b.capabilities || [], g.Qv("desktop_enable_autoplay") &&
                    e.push("atp"), 0 < e.length && (a.capabilities = e), a.name = b.device, a.app = b.app, (b = b.theme) && (a.theme = b), Z9(" -- with channel params: " + g.Hh(a)), a ? (g.KA("yt-remote-session-app", a.app), g.KA("yt-remote-session-name", a.name)) : (g.MA("yt-remote-session-app"), g.MA("yt-remote-session-name")), g.Fa("yt.mdx.remote.channelParams_", a), c.start(), Y9() || lob())
            }
        },
        nob = function() {
            var a = X9().Ng.$_gos();
            var b = c$();
            b && d$() && ($jb(a, b) || a.push(b));
            return Zjb(a)
        },
        pob = function() {
            var a = oob();
            !a && B9() && Dnb() && (a = {
                key: "cast-selector-receiver",
                name: Dnb()
            });
            return a
        },
        oob = function() {
            var a = nob(),
                b = c$();
            b || (b = b$());
            return g.ib(a, function(c) {
                return b && e8(b, c.key) ? !0 : !1
            })
        },
        c$ = function() {
            var a = Y9();
            if (!a) return null;
            var b = X9().rk();
            return g8(b, a)
        },
        job = function(a) {
            Z9("remote.onCastSessionChange_: " + f8(a));
            if (a) {
                var b = c$();
                if (b && b.id == a.id) {
                    if (D9(b.id, "YouTube TV"), "shortLived" == a.idType && (a = a.token)) e$ && (e$.token = a), (b = d$()) && b.Kq(a)
                } else b && f$(), g$(a, 1)
            } else d$() && f$()
        },
        f$ = function() {
            C9() ? A9().stopSession() : z9("stopSession called before API ready.");
            var a = d$();
            a && (a.disconnect(1), qob(null))
        },
        rob = function() {
            var a = d$();
            return !!a && 3 != a.getProxyState()
        },
        Z9 = function(a) {
            a9("remote", a)
        },
        X9 = function() {
            if (!sob) {
                var a = g.Ha("yt.mdx.remote.screenService_");
                sob = a ? new hob(a) : null
            }
            return sob
        },
        Y9 = function() {
            return g.Ha("yt.mdx.remote.currentScreenId_")
        },
        tob = function(a) {
            g.Fa("yt.mdx.remote.currentScreenId_", a)
        },
        uob = function() {
            return g.Ha("yt.mdx.remote.connectData_")
        },
        a$ = function(a) {
            g.Fa("yt.mdx.remote.connectData_", a)
        },
        d$ = function() {
            return g.Ha("yt.mdx.remote.connection_")
        },
        qob = function(a) {
            var b = d$();
            a$(null);
            a || tob("");
            g.Fa("yt.mdx.remote.connection_", a);
            W9 && (g.Fb(W9, function(c) {
                c(a)
            }), W9.length = 0);
            b && !a ? b8("yt-remote-connection-change", !1) : !b && a && b8("yt-remote-connection-change", !0)
        },
        b$ = function() {
            var a = g.NA();
            if (!a) return null;
            var b = X9();
            if (!b) return null;
            b = b.rk();
            return g8(b, a)
        },
        g$ = function(a, b) {
            Y9();
            c$() && c$();
            if (h$) e$ = a;
            else {
                tob(a.id);
                var c = g.Ha("yt.mdx.remote.enableConnectWithInitialState_") || !1;
                a = new T9(V9, a, kob(), c);
                a.connect(b, uob());
                a.subscribe("beforeDisconnect", function(d) {
                    b8("yt-remote-before-disconnect", d)
                });
                a.subscribe("beforeDispose", function() {
                    d$() && (d$(), qob(null))
                });
                a.subscribe("browserChannelAuthError", function() {
                    var d = c$();
                    d && "shortLived" == d.idType && (C9() ? A9().handleBrowserChannelAuthError() : z9("refreshLoungeToken called before API ready."))
                });
                qob(a)
            }
        },
        lob = function() {
            var a = b$();
            a ? (Z9("Resume connection to: " + f8(a)), g$(a, 0)) : (j8(), Enb(), Z9("Skipping connecting because no session screen found."))
        },
        iob = function() {
            var a = kob();
            if (g.Pc(a)) {
                a = i8();
                var b = g.LA("yt-remote-session-name") || "",
                    c = g.LA("yt-remote-session-app") || "";
                a = {
                    device: "REMOTE_CONTROL",
                    id: a,
                    name: b,
                    app: c,
                    mdxVersion: 3
                };
                g.Fa("yt.mdx.remote.channelParams_", a)
            }
        },
        kob = function() {
            return g.Ha("yt.mdx.remote.channelParams_") || {}
        },
        xob = function(a, b, c) {
            g.C.call(this);
            var d = this;
            this.module = a;
            this.F = b;
            this.wc = c;
            this.events = new g.FF(this);
            this.Z = this.events.S(this.F, "onVolumeChange", function(e) {
                vob(d, e)
            });
            this.C = !1;
            this.D = new g.VL(64);
            this.j = new g.eo(this.KW, 500, this);
            this.u = new g.eo(this.LW, 1E3, this);
            this.J = new n8(this.l8, 0, this);
            this.B = {};
            this.T = new g.eo(this.zX, 1E3, this);
            this.I = new o8(this.seekTo, 1E3, this);
            g.D(this, this.events);
            this.events.S(b, "onCaptionsTrackListChanged", this.Q4);
            this.events.S(b, "captionschanged", this.n4);
            this.events.S(b, "captionssettingschanged", this.UW);
            this.events.S(b, "videoplayerreset", this.uG);
            this.events.S(b, "mdxautoplaycancel", function() {
                d.wc.hS()
            });
            b.N("enable_mdx_video_play_directly") && this.events.S(b, "videodatachange", function() {
                wob(d.module) || i$(d) || j$(d, 0)
            });
            a = this.wc;
            a.isDisposed();
            a.subscribe("proxyStateChange", this.pV, this);
            a.subscribe("remotePlayerChange", this.pC, this);
            a.subscribe("remoteQueueChange", this.uG, this);
            a.subscribe("previousNextChange", this.mV, this);
            a.subscribe("nowAutoplaying", this.gV, this);
            a.subscribe("autoplayDismissed", this.JU, this);
            g.D(this, this.j);
            g.D(this, this.u);
            g.D(this, this.J);
            g.D(this, this.T);
            g.D(this, this.I);
            this.UW();
            this.uG();
            this.pC()
        },
        vob = function(a, b) {
            if (i$(a)) {
                a.wc.unsubscribe("remotePlayerChange", a.pC, a);
                var c = Math.round(b.volume);
                b = !!b.muted;
                var d = L9(a.wc);
                if (c !== d.volume || b !== d.muted) a.wc.setVolume(c, b), a.T.start();
                a.wc.subscribe("remotePlayerChange", a.pC, a)
            }
        },
        yob = function(a) {
            a.qc(0);
            a.j.stop();
            a.kc(new g.VL(64))
        },
        zob = function(a, b) {
            if (i$(a) && !a.C) {
                var c = null;
                b && (c = {
                    style: a.F.getSubtitlesUserSettings()
                }, g.Wc(c, b));
                a.wc.hQ(a.F.getVideoData(1).videoId, c);
                a.B = L9(a.wc).trackData
            }
        },
        j$ = function(a, b) {
            var c = a.F.getPlaylist();
            if (null == c ? 0 : c.listId) {
                var d = c.index;
                var e = c.listId.toString()
            }
            c = a.F.getVideoData(1);
            a.wc.playVideo(c.videoId, b, d, e, c.playerParams, c.Aa, Jjb(c));
            a.kc(new g.VL(1))
        },
        Aob = function(a, b) {
            if (b) {
                var c = a.F.getOption("captions", "tracklist", {
                    BT: 1
                });
                c && c.length ? (a.F.setOption("captions", "track", b), a.C = !1) : (a.F.loadModule("captions"), a.C = !0)
            } else a.F.setOption("captions", "track", {})
        },
        i$ = function(a) {
            return L9(a.wc).videoId === a.F.getVideoData(1).videoId
        },
        k$ = function() {
            g.U.call(this, {
                G: "div",
                K: "ytp-mdx-popup-dialog",
                X: {
                    role: "dialog"
                },
                W: [{
                    G: "div",
                    K: "ytp-mdx-popup-dialog-inner-content",
                    W: [{
                        G: "div",
                        K: "ytp-mdx-popup-title",
                        qa: "You're signed out"
                    }, {
                        G: "div",
                        K: "ytp-mdx-popup-description",
                        qa: "Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer."
                    }, {
                        G: "div",
                        K: "ytp-mdx-privacy-popup-buttons",
                        W: [{
                            G: "button",
                            Ha: ["ytp-button", "ytp-mdx-privacy-popup-cancel"],
                            qa: "Cancel"
                        }, {
                            G: "button",
                            Ha: ["ytp-button",
                                "ytp-mdx-privacy-popup-confirm"
                            ],
                            qa: "Confirm"
                        }]
                    }]
                }]
            });
            this.j = new g.cO(this, 250);
            this.cancelButton = this.Da("ytp-mdx-privacy-popup-cancel");
            this.confirmButton = this.Da("ytp-mdx-privacy-popup-confirm");
            g.D(this, this.j);
            this.S(this.cancelButton, "click", this.u);
            this.S(this.confirmButton, "click", this.B)
        },
        l$ = function(a) {
            g.U.call(this, {
                G: "div",
                K: "ytp-remote",
                W: [{
                    G: "div",
                    K: "ytp-remote-display-status",
                    W: [{
                        G: "div",
                        K: "ytp-remote-display-status-icon",
                        W: [g.VEa()]
                    }, {
                        G: "div",
                        K: "ytp-remote-display-status-text",
                        qa: "{{statustext}}"
                    }]
                }]
            });
            this.api = a;
            this.j = new g.cO(this, 250);
            g.D(this, this.j);
            this.S(a, "presentingplayerstatechange", this.onStateChange);
            this.Cc(a.Gb())
        },
        m$ = function(a, b) {
            g.zU.call(this, "Play on", 1, a, b);
            this.F = a;
            this.Zs = {};
            this.S(a, "onMdxReceiversChange", this.C);
            this.S(a, "presentingplayerstatechange", this.C);
            this.C()
        },
        Bob = function(a) {
            g.iR.call(this, a);
            this.Po = {
                key: Yjb(),
                name: "This computer"
            };
            this.ul = null;
            this.subscriptions = [];
            this.mN = this.wc = null;
            this.Zs = [this.Po];
            this.Er = this.Po;
            this.Ud = new g.VL(64);
            this.aU = 0;
            this.yh = -1;
            this.BC = !1;
            this.zC = this.Uy = null;
            if (!g.IH(this.player.V()) && !g.JH(this.player.V())) {
                a = this.player;
                var b = g.hQ(a);
                b && (b = b.Gm()) && (b = new m$(a, b), g.D(this, b));
                b = new l$(a);
                g.D(this, b);
                g.zQ(a, b.element, 4);
                this.Uy = new k$;
                g.D(this, this.Uy);
                g.zQ(a, this.Uy.element, 4);
                this.BC = !!b$()
            }
        },
        n$ = function(a) {
            a.zC && (a.player.removeEventListener("presentingplayerstatechange",
                a.zC), a.zC = null)
        },
        Cob = function(a, b, c) {
            a.Ud = c;
            a.player.ma("presentingplayerstatechange", new g.nL(c, b))
        },
        o$ = function(a, b) {
            if (b.key !== a.Er.key)
                if (b.key === a.Po.key) f$();
                else if (wob(a) && Dob(a), a.Er = b, !a.player.V().N("disable_mdx_connection_in_mdx_module_for_music_web") || !g.JH(a.player.V())) {
                var c = a.player.getPlaylistId();
                var d = a.player.getVideoData(1);
                var e = d.videoId;
                if (!c && !e || (2 === a.player.getAppState() || 1 === a.player.getAppState()) && a.player.V().N("should_clear_video_data_on_player_cued_unstarted")) d = null;
                else {
                    var f = a.player.getPlaylist();
                    if (f) {
                        var h = [];
                        for (var l = 0; l < f.length; l++) h[l] = g.dR(f, l).videoId
                    } else h = [e];
                    f = a.player.getCurrentTime(1);
                    a = {
                        videoIds: h,
                        listId: c,
                        videoId: e,
                        playerParams: d.playerParams,
                        clickTrackingParams: d.Aa,
                        index: Math.max(a.player.getPlaylistIndex(), 0),
                        currentTime: 0 === f ? void 0 : f
                    };
                    (d = Jjb(d)) && (a.locationInfo = d);
                    d = a
                }
                Z9("Connecting to: " + g.Hh(b));
                "cast-selector-receiver" == b.key ? (a$(d || null), b = d || null, C9() ? A9().setLaunchParams(b) : z9("setLaunchParams called before ready.")) : !d && rob() && Y9() == b.key ? b8("yt-remote-connection-change", !0) : (f$(), a$(d || null), d = X9().rk(), (b = g8(d, b.key)) && g$(b, 1))
            }
        },
        wob = function(a) {
            var b;
            (b = !a.player.V().N("mdx_enable_privacy_disclosure_ui")) || (b = ((b = g.L("PLAYER_CONFIG")) && b.args && void 0 !== b.args.authuser ? !0 : !(!g.L("SESSION_INDEX") && !g.L("LOGGED_IN"))) || a.BC || !a.Uy);
            return b ? !1 : g.ZH(a.player.V()) || g.bI(a.player.V())
        },
        Dob = function(a) {
            a.player.Gb().Zc() ? a.player.pauseVideo() : (a.zC = function(b) {
                !a.BC && g.pL(b, 8) && (a.player.pauseVideo(), n$(a))
            }, a.player.addEventListener("presentingplayerstatechange", a.zC));
            a.Uy && a.Uy.Pc();
            d$() || (h$ = !0)
        };
    g.rr.prototype.Qr = g.ba(1, function() {
        return g.cg(this, 6)
    });
    g.Mg.prototype.RD = g.ba(0, function() {
        var a = g.Qg(this);
        return 4294967296 * g.Qg(this) + (a >>> 0)
    });
    var ujb, Eob = g.oh(function(a, b, c) {
            if (1 !== a.u) return !1;
            g.H(b, c, g.Rg(a.j));
            return !0
        }, g.ph),
        Fob = g.oh(function(a, b, c, d) {
            if (1 !== a.u) return !1;
            g.og(b, c, d, g.Rg(a.j));
            return !0
        }, g.ph),
        Gob = g.oh(function(a, b, c) {
            if (0 !== a.u) return !1;
            g.H(b, c, g.Og(a.j));
            return !0
        }, g.qh),
        Hob = g.oh(function(a, b, c, d) {
            if (0 !== a.u) return !1;
            g.og(b, c, d, g.Og(a.j));
            return !0
        }, g.qh),
        Iob = g.oh(function(a, b, c, d) {
            if (0 !== a.u) return !1;
            g.og(b, c, d, g.Pg(a.j));
            return !0
        }, g.rh),
        Job = g.oh(function(a, b, c) {
            if (1 !== a.u) return !1;
            g.H(b, c, a.j.RD());
            return !0
        }, function(a, b, c) {
            wjb(a, c, g.cg(b, c))
        }),
        Kob = g.oh(function(a, b, c) {
            if (1 !== a.u && 2 !== a.u) return !1;
            b = g.gg(b, c, 0, !1, g.Rf(b.df));
            if (2 == a.u) {
                c = g.Mg.prototype.RD;
                var d = g.Pg(a.j) >>> 0;
                for (d = a.j.j + d; a.j.j < d;) b.push(c.call(a.j))
            } else b.push(a.j.RD());
            return !0
        }, function(a, b, c) {
            b = g.jg(b, c, qjb);
            if (null != b)
                for (var d = 0; d < b.length; d++) wjb(a, c, b[d])
        }),
        Lob = g.oh(function(a, b, c) {
            if (0 !== a.u) return !1;
            g.H(b, c, g.Sg(a.j));
            return !0
        }, xjb),
        Mob = g.oh(function(a, b, c, d) {
            if (0 !== a.u) return !1;
            g.og(b, c, d, g.Sg(a.j));
            return !0
        }, xjb),
        Nob = g.oh(function(a, b, c) {
            if (2 !== a.u) return !1;
            a = g.Zg(a);
            g.mg(b, c, a);
            return !0
        }, function(a, b, c) {
            b = g.jg(b, c, rjb, !1);
            if (null != b)
                for (var d = 0; d < b.length; d++) {
                    var e = b[d];
                    null != e && g.eh(a, c, g.Sca(e))
                }
        }),
        Oob = g.oh(function(a, b, c, d) {
            if (2 !== a.u) return !1;
            g.og(b, c, d, g.Zg(a));
            return !0
        }, g.tea),
        Pob = g.oh(function(a, b, c, d, e) {
            if (2 !== a.u) return !1;
            g.Wg(a, sjb(b, d, c), e);
            return !0
        }, yjb),
        Qob = g.oh(function(a, b, c, d, e, f) {
            if (2 !== a.u) return !1;
            (f = g.ng(b, f)) && f !== c && g.H(b, f, void 0, !1);
            b = sjb(b, d, c);
            g.Wg(a, b, e);
            return !0
        }, yjb),
        Rob = [g.sh,
            1, Oob, g.Ah, 2, Iob, g.Ah, 3, Mob, g.Ah
        ];
    g.w(zjb, g.J);
    var Sob = [zjb, 1, Eob, 2, Gob],
        Ajb = [1];
    g.w(Bjb, g.J);
    var Tob = [Bjb, 1, g.G2, Sob],
        Uob = [g.th, 1, Hob, g.zh, 2, Fob, g.zh, 3, Qob, Tob, g.zh],
        Vob = [g.xh, 1, g.G2, Rob, 2, Pob, Uob];
    g.w(Cjb, g.J);
    var Wob = [Cjb, 1, g.F2, 2, g.F2, 3, Lob];
    g.w(Djb, g.J);
    var Xob = [Djb, 1, g.F2, 2, g.F2, 3, g.j5a, 4, Lob];
    g.w(Ejb, g.J);
    var Yob = [1, 2],
        Zob = [Ejb, 1, Qob, Wob, Yob, 2, Qob, Xob, Yob],
        $ob = [g.yh, 1, g.F2, 5, Job, 2, Pob, Zob, 3, Nob, 6, Kob, 4, g.G2, Vob],
        Llb = {
            "\x00": "\\0",
            "\b": "\\b",
            "\f": "\\f",
            "\n": "\\n",
            "\r": "\\r",
            "\t": "\\t",
            "\v": "\\x0B",
            '"': '\\"',
            "\\": "\\\\",
            "<": "\\u003C"
        },
        P8 = {
            "'": "\\'"
        },
        Sjb = {
            Zga: "atp",
            JZa: "ska",
            RVa: "que",
            KMa: "mus",
            IZa: "sus",
            Vya: "dsp",
            pXa: "seq",
            oLa: "mic",
            rra: "dpa",
            jia: "cds",
            zMa: "mlm",
            dra: "dsdtr",
            ONa: "ntb"
        },
        Tjb = {
            Z_: "u",
            CLASSIC: "cl",
            A_: "k",
            tY: "i",
            fY: "cr",
            I_: "m",
            pY: "g",
            dR: "up"
        };
    c8.prototype.equals = function(a) {
        return a ? this.id == a.id : !1
    };
    var k8, dkb = "",
        skb = mkb("loadCastFramework") || mkb("loadCastApplicationFramework"),
        vkb = ["pkedcjkdefgpdelpbcmbmeomcjbeemfm", "enhhojjnijigcajfphajepfemndkmdlo"];
    g.Ra(n8, g.C);
    g.k = n8.prototype;
    g.k.SY = function(a) {
        this.C = arguments;
        this.j = !1;
        this.Dc ? this.B = g.Qa() + this.Di : this.Dc = g.rf(this.D, this.Di)
    };
    g.k.stop = function() {
        this.Dc && (g.Ea.clearTimeout(this.Dc), this.Dc = null);
        this.B = null;
        this.j = !1;
        this.C = []
    };
    g.k.pause = function() {
        ++this.u
    };
    g.k.resume = function() {
        this.u && (--this.u, !this.u && this.j && (this.j = !1, this.I.apply(null, this.C)))
    };
    g.k.ra = function() {
        this.stop();
        n8.zf.ra.call(this)
    };
    g.k.TY = function() {
        this.Dc && (g.Ea.clearTimeout(this.Dc), this.Dc = null);
        this.B ? (this.Dc = g.rf(this.D, this.B - g.Qa()), this.B = null) : this.u ? this.j = !0 : (this.j = !1, this.I.apply(null, this.C))
    };
    g.w(o8, g.C);
    g.k = o8.prototype;
    g.k.kI = function(a) {
        this.B = arguments;
        this.Dc || this.u ? this.j = !0 : Hkb(this)
    };
    g.k.stop = function() {
        this.Dc && (g.Ea.clearTimeout(this.Dc), this.Dc = null, this.j = !1, this.B = null)
    };
    g.k.pause = function() {
        this.u++
    };
    g.k.resume = function() {
        this.u--;
        this.u || !this.j || this.Dc || (this.j = !1, Hkb(this))
    };
    g.k.ra = function() {
        g.C.prototype.ra.call(this);
        this.stop()
    };
    p8.prototype.stringify = function(a) {
        return g.Ea.JSON.stringify(a, void 0)
    };
    p8.prototype.parse = function(a) {
        return g.Ea.JSON.parse(a, void 0)
    };
    g.Ra(Ikb, g.db);
    g.Ra(Jkb, g.db);
    var Kkb = null;
    g.Ra(Mkb, g.db);
    g.Ra(Nkb, g.db);
    g.Ra(Okb, g.db);
    Pkb.prototype.info = function() {};
    Pkb.prototype.warning = function() {};
    var Wkb = {},
        v8 = {};
    g.k = t8.prototype;
    g.k.setTimeout = function(a) {
        this.Cb = a
    };
    g.k.WY = function(a) {
        a = a.target;
        var b = this.Ya;
        b && 3 == g.hi(a) ? b.kI() : this.LP(a)
    };
    g.k.LP = function(a) {
        try {
            if (a == this.j) a: {
                var b = g.hi(this.j),
                    c = this.j.u,
                    d = this.j.getStatus();
                if (!(3 > b) && (3 != b || g.cI || this.j && (this.u.u || g.ji(this.j) || g.ki(this.j)))) {
                    this.Ia || 4 != b || 7 == c || (8 == c || 0 >= d ? q8(3) : q8(2));
                    y8(this);
                    var e = this.j.getStatus();
                    this.Rb = e;
                    b: if (Ukb(this)) {
                        var f = g.ki(this.j);
                        a = "";
                        var h = f.length,
                            l = 4 == g.hi(this.j);
                        if (!this.u.B) {
                            if ("undefined" === typeof TextDecoder) {
                                w8(this);
                                x8(this);
                                var m = "";
                                break b
                            }
                            this.u.B = new g.Ea.TextDecoder
                        }
                        for (c = 0; c < h; c++) this.u.u = !0, a += this.u.B.decode(f[c], {
                            stream: l &&
                                c == h - 1
                        });
                        f.splice(0, h);
                        this.u.j += a;
                        this.ea = 0;
                        m = this.u.j
                    } else m = g.ji(this.j);
                    if (this.B = 200 == e) {
                        if (this.dc && !this.Va) {
                            b: {
                                if (this.j) {
                                    var n = g.li(this.j, "X-HTTP-Initial-Response");
                                    if (n && !g.Lb(n)) {
                                        var p = n;
                                        break b
                                    }
                                }
                                p = null
                            }
                            if (e = p) this.Va = !0,
                            Xkb(this, e);
                            else {
                                this.B = !1;
                                this.I = 3;
                                r8(12);
                                w8(this);
                                x8(this);
                                break a
                            }
                        }
                        this.Ba ? (Ykb(this, b, m), g.cI && this.B && 3 == b && (this.ib.Ra(this.kb, "tick", this.VY), this.kb.start())) : Xkb(this, m);
                        4 == b && w8(this);
                        this.B && !this.Ia && (4 == b ? $kb(this.D, this) : (this.B = !1, u8(this)))
                    } else g.hfa(this.j),
                        400 == e && 0 < m.indexOf("Unknown SID") ? (this.I = 3, r8(12)) : (this.I = 0, r8(13)), w8(this), x8(this)
                }
            }
        } catch (q) {} finally {}
    };
    g.k.VY = function() {
        if (this.j) {
            var a = g.hi(this.j),
                b = g.ji(this.j);
            this.ea < b.length && (y8(this), Ykb(this, a, b), this.B && 4 != a && u8(this))
        }
    };
    g.k.cancel = function() {
        this.Ia = !0;
        w8(this)
    };
    g.k.UY = function() {
        this.Z = null;
        var a = Date.now();
        0 <= a - this.Tb ? (2 != this.Pa && (q8(3), r8(17)), w8(this), this.I = 2, x8(this)) : Zkb(this, this.Tb - a)
    };
    g.k.getLastError = function() {
        return this.I
    };
    g.k.ZK = function() {
        return this.j
    };
    ilb.prototype.cancel = function() {
        this.B = klb(this);
        if (this.u) this.u.cancel(), this.u = null;
        else if (this.j && 0 !== this.j.size) {
            for (var a = g.t(this.j.values()), b = a.next(); !b.done; b = a.next()) b.value.cancel();
            this.j.clear()
        }
    };
    g.k = olb.prototype;
    g.k.MP = 8;
    g.k.nh = 1;
    g.k.connect = function(a, b, c, d) {
        r8(0);
        this.Ac = a;
        this.Ia = b || {};
        c && void 0 !== d && (this.Ia.OSID = c, this.Ia.OAID = d);
        this.kb = this.Fc;
        this.Ma = elb(this, null, this.Ac);
        C8(this)
    };
    g.k.disconnect = function() {
        qlb(this);
        if (3 == this.nh) {
            var a = this.Ya++,
                b = this.Ma.clone();
            g.Bj(b, "SID", this.C);
            g.Bj(b, "RID", a);
            g.Bj(b, "TYPE", "terminate");
            F8(this, b);
            a = new t8(this, this.C, a);
            a.Pa = 2;
            a.J = Z7(b.clone());
            b = !1;
            g.Ea.navigator && g.Ea.navigator.sendBeacon && (b = g.Ea.navigator.sendBeacon(a.J.toString(), ""));
            !b && g.Ea.Image && ((new Image).src = a.J, b = !0);
            b || (a.j = Tkb(a.D, null), a.j.send(a.J));
            a.ya = Date.now();
            u8(a)
        }
        wlb(this)
    };
    g.k.Og = function() {
        return 0 == this.nh
    };
    g.k.getState = function() {
        return this.nh
    };
    g.k.OP = function(a) {
        if (this.I)
            if (this.I = null, 1 == this.nh) {
                if (!a) {
                    this.Ya = Math.floor(1E5 * Math.random());
                    a = this.Ya++;
                    var b = new t8(this, "", a),
                        c = this.Z;
                    this.Tb && (c ? (c = g.Uc(c), g.Wc(c, this.Tb)) : c = this.Tb);
                    null !== this.J || this.vb || (b.Ma = c, c = null);
                    var d;
                    if (this.Cb) a: {
                        for (var e = d = 0; e < this.B.length; e++) {
                            b: {
                                var f = this.B[e];
                                if ("__data__" in f.map && (f = f.map.__data__, "string" === typeof f)) {
                                    f = f.length;
                                    break b
                                }
                                f = void 0
                            }
                            if (void 0 === f) break;d += f;
                            if (4096 < d) {
                                d = e;
                                break a
                            }
                            if (4096 === d || e === this.B.length - 1) {
                                d = e + 1;
                                break a
                            }
                        }
                        d =
                        1E3
                    }
                    else d = 1E3;
                    d = tlb(this, b, d);
                    e = this.Ma.clone();
                    g.Bj(e, "RID", a);
                    g.Bj(e, "CVER", 22);
                    this.Ba && g.Bj(e, "X-HTTP-Session-Id", this.Ba);
                    F8(this, e);
                    c && (this.vb ? d = "headers=" + g.le(g.Lga(c)) + "&" + d : this.J && g.Fj(e, this.J, c));
                    dlb(this.u, b);
                    this.Ff && g.Bj(e, "TYPE", "init");
                    this.Cb ? (g.Bj(e, "$req", d), g.Bj(e, "SID", "null"), b.dc = !0, Skb(b, e, null)) : Skb(b, e, d);
                    this.nh = 2
                }
            } else 3 == this.nh && (a ? ulb(this, a) : 0 == this.B.length || jlb(this.u) || ulb(this))
    };
    g.k.NP = function() {
        this.T = null;
        vlb(this);
        if (this.Uc && !(this.ib || null == this.j || 0 >= this.Od)) {
            var a = 2 * this.Od;
            this.Aa = s8((0, g.Oa)(this.m4, this), a)
        }
    };
    g.k.m4 = function() {
        this.Aa && (this.Aa = null, this.kb = !1, this.ib = !0, r8(10), A8(this), vlb(this))
    };
    g.k.BM = function(a) {
        this.j == a && this.Uc && !this.ib && (plb(this), this.ib = !0, r8(11))
    };
    g.k.XY = function() {
        null != this.ea && (this.ea = null, A8(this), blb(this), r8(19))
    };
    g.k.R7 = function(a) {
        a ? r8(2) : r8(1)
    };
    g.k.isActive = function() {
        return !!this.D && this.D.isActive(this)
    };
    g.k = ylb.prototype;
    g.k.SP = function() {};
    g.k.RP = function() {};
    g.k.QP = function() {};
    g.k.PP = function() {};
    g.k.isActive = function() {
        return !0
    };
    g.k.YY = function() {};
    g.Ra(H8, g.pd);
    H8.prototype.open = function() {
        this.j.D = this.C;
        this.J && (this.j.Pa = !0);
        this.j.connect(this.I, this.u || void 0)
    };
    H8.prototype.close = function() {
        this.j.disconnect()
    };
    H8.prototype.send = function(a) {
        var b = this.j;
        if ("string" === typeof a) {
            var c = {};
            c.__data__ = a;
            a = c
        } else this.D && (c = {}, c.__data__ = g.Hh(a), a = c);
        b.B.push(new hlb(b.tf++, a));
        3 == b.nh && C8(b)
    };
    H8.prototype.ra = function() {
        this.j.D = null;
        delete this.C;
        this.j.disconnect();
        delete this.j;
        H8.zf.ra.call(this)
    };
    g.Ra(Alb, Ikb);
    g.Ra(Blb, Jkb);
    g.Ra(G8, ylb);
    G8.prototype.SP = function() {
        this.j.dispatchEvent("m")
    };
    G8.prototype.RP = function(a) {
        this.j.dispatchEvent(new Alb(a))
    };
    G8.prototype.QP = function(a) {
        this.j.dispatchEvent(new Blb(a))
    };
    G8.prototype.PP = function() {
        this.j.dispatchEvent("n")
    };
    var J8 = new g.pd;
    g.w(Elb, g.db);
    g.k = L8.prototype;
    g.k.Mt = null;
    g.k.wp = !1;
    g.k.Hw = null;
    g.k.mI = null;
    g.k.Fw = null;
    g.k.Gw = null;
    g.k.Vq = null;
    g.k.Xq = null;
    g.k.Nt = null;
    g.k.Pi = null;
    g.k.MD = 0;
    g.k.Bn = null;
    g.k.LD = null;
    g.k.Wq = null;
    g.k.Xz = -1;
    g.k.tW = !0;
    g.k.Lt = !1;
    g.k.lI = 0;
    g.k.KD = null;
    var Jlb = {},
        Ilb = {};
    g.k = L8.prototype;
    g.k.setTimeout = function(a) {
        this.u = a
    };
    g.k.aZ = function(a) {
        a = a.target;
        var b = this.KD;
        b && 3 == g.hi(a) ? b.kI() : this.TP(a)
    };
    g.k.TP = function(a) {
        try {
            if (a == this.Pi) a: {
                var b = g.hi(this.Pi),
                    c = this.Pi.u,
                    d = this.Pi.getStatus();
                if (g.Ae && !g.wc(10) || g.xc && !g.vc("420+")) {
                    if (4 > b) break a
                } else if (3 > b || 3 == b && !g.ji(this.Pi)) break a;this.Lt || 4 != b || 7 == c || (8 == c || 0 >= d ? this.j.Xm(3) : this.j.Xm(2));Olb(this);
                var e = this.Pi.getStatus();this.Xz = e;
                var f = g.ji(this.Pi);
                if (this.wp = 200 == e) {
                    4 == b && N8(this);
                    if (this.Ba) {
                        for (a = !0; !this.Lt && this.MD < f.length;) {
                            var h = Klb(this, f);
                            if (h == Ilb) {
                                4 == b && (this.Wq = 4, K8(15), a = !1);
                                break
                            } else if (h == Jlb) {
                                this.Wq = 4;
                                K8(16);
                                a = !1;
                                break
                            } else Plb(this, h)
                        }
                        4 == b && 0 == f.length && (this.Wq = 1, K8(17), a = !1);
                        this.wp = this.wp && a;
                        a || (N8(this), O8(this))
                    } else Plb(this, f);
                    this.wp && !this.Lt && (4 == b ? this.j.ND(this) : (this.wp = !1, M8(this)))
                } else 400 == e && 0 < f.indexOf("Unknown SID") ? (this.Wq = 3, K8(13)) : (this.Wq = 0, K8(14)),
                N8(this),
                O8(this)
            }
        } catch (l) {} finally {}
    };
    g.k.t6 = function(a) {
        I8((0, g.Oa)(this.s6, this, a), 0)
    };
    g.k.s6 = function(a) {
        this.Lt || (Olb(this), Plb(this, a), M8(this))
    };
    g.k.uV = function(a) {
        I8((0, g.Oa)(this.r6, this, a), 0)
    };
    g.k.r6 = function(a) {
        this.Lt || (N8(this), this.wp = a, this.j.ND(this), this.j.Xm(4))
    };
    g.k.cancel = function() {
        this.Lt = !0;
        N8(this)
    };
    g.k.ZY = function() {
        this.Hw = null;
        var a = Date.now();
        0 <= a - this.mI ? (2 != this.Gw && this.j.Xm(3), N8(this), this.Wq = 2, K8(18), O8(this)) : Nlb(this, this.mI - a)
    };
    g.k.getLastError = function() {
        return this.Wq
    };
    g.k = Slb.prototype;
    g.k.oI = null;
    g.k.tj = null;
    g.k.SG = !1;
    g.k.MW = null;
    g.k.SE = null;
    g.k.SL = null;
    g.k.pI = null;
    g.k.ol = null;
    g.k.xp = -1;
    g.k.Yz = null;
    g.k.uA = null;
    g.k.connect = function(a) {
        this.pI = a;
        a = R8(this.j, null, this.pI);
        K8(3);
        this.MW = Date.now();
        var b = this.j.T;
        null != b ? (this.Yz = b[0], (this.uA = b[1]) ? (this.ol = 1, Tlb(this)) : (this.ol = 2, Ulb(this))) : ($7(a, "MODE", "init"), this.tj = new L8(this), this.tj.Mt = this.oI, Hlb(this.tj, a, !1, null, !0), this.ol = 0)
    };
    g.k.G0 = function(a) {
        if (a) this.ol = 2, Ulb(this);
        else {
            K8(4);
            var b = this.j;
            b.Gn = b.Ar.xp;
            V8(b, 9)
        }
        a && this.Xm(2)
    };
    g.k.nI = function(a) {
        return this.j.nI(a)
    };
    g.k.abort = function() {
        this.tj && (this.tj.cancel(), this.tj = null);
        this.xp = -1
    };
    g.k.Og = function() {
        return !1
    };
    g.k.UP = function(a, b) {
        this.xp = a.Xz;
        if (0 == this.ol)
            if (b) {
                try {
                    var c = this.u.parse(b)
                } catch (d) {
                    a = this.j;
                    a.Gn = this.xp;
                    V8(a, 2);
                    return
                }
                this.Yz = c[0];
                this.uA = c[1]
            } else a = this.j, a.Gn = this.xp, V8(a, 2);
        else if (2 == this.ol)
            if (this.SG) K8(7), this.SL = Date.now();
            else if ("11111" == b) {
            if (K8(6), this.SG = !0, this.SE = Date.now(), a = this.SE - this.MW, !g.Ae || g.wc(10) || 500 > a) this.xp = 200, this.tj.cancel(), K8(12), S8(this.j, this, !0)
        } else K8(8), this.SE = this.SL = Date.now(), this.SG = !1
    };
    g.k.ND = function() {
        this.xp = this.tj.Xz;
        if (this.tj.wp) 0 == this.ol ? this.uA ? (this.ol = 1, Tlb(this)) : (this.ol = 2, Ulb(this)) : 2 == this.ol && ((!g.Ae || g.wc(10) ? !this.SG : 200 > this.SL - this.SE) ? (K8(11), S8(this.j, this, !1)) : (K8(12), S8(this.j, this, !0)));
        else {
            0 == this.ol ? K8(9) : 2 == this.ol && K8(10);
            var a = this.j;
            this.tj.getLastError();
            a.Gn = this.xp;
            V8(a, 2)
        }
    };
    g.k.Zz = function() {
        return this.j.Zz()
    };
    g.k.isActive = function() {
        return this.j.isActive()
    };
    g.k.Xm = function(a) {
        this.j.Xm(a)
    };
    g.k = Vlb.prototype;
    g.k.Fn = null;
    g.k.aA = null;
    g.k.Cj = null;
    g.k.yg = null;
    g.k.qI = null;
    g.k.OD = null;
    g.k.VP = null;
    g.k.PD = null;
    g.k.bA = 0;
    g.k.cZ = 0;
    g.k.ji = null;
    g.k.Yq = null;
    g.k.yp = null;
    g.k.Pt = null;
    g.k.Ar = null;
    g.k.EH = null;
    g.k.Kw = -1;
    g.k.WP = -1;
    g.k.Gn = -1;
    g.k.Jw = 0;
    g.k.Iw = 0;
    g.k.Ot = 8;
    g.Ra(Xlb, g.db);
    g.Ra(Ylb, g.db);
    g.k = Vlb.prototype;
    g.k.connect = function(a, b, c, d, e) {
        K8(0);
        this.qI = b;
        this.aA = c || {};
        d && void 0 !== e && (this.aA.OSID = d, this.aA.OAID = e);
        this.J ? (I8((0, g.Oa)(this.UR, this, a), 100), $lb(this)) : this.UR(a)
    };
    g.k.disconnect = function() {
        amb(this);
        if (3 == this.j) {
            var a = this.bA++,
                b = this.OD.clone();
            g.Bj(b, "SID", this.C);
            g.Bj(b, "RID", a);
            g.Bj(b, "TYPE", "terminate");
            U8(this, b);
            a = new L8(this, this.C, a);
            a.Gw = 2;
            a.Vq = Z7(b.clone());
            (new Image).src = a.Vq.toString();
            a.Fw = Date.now();
            M8(a)
        }
        kmb(this)
    };
    g.k.UR = function(a) {
        this.Ar = new Slb(this);
        this.Ar.oI = this.Fn;
        this.Ar.u = this.D;
        this.Ar.connect(a)
    };
    g.k.Og = function() {
        return 0 == this.j
    };
    g.k.getState = function() {
        return this.j
    };
    g.k.YP = function(a) {
        this.Yq = null;
        fmb(this, a)
    };
    g.k.XP = function() {
        this.yp = null;
        this.yg = new L8(this, this.C, "rpc", this.I);
        this.yg.Mt = this.Fn;
        this.yg.lI = 0;
        var a = this.VP.clone();
        g.Bj(a, "RID", "rpc");
        g.Bj(a, "SID", this.C);
        g.Bj(a, "CI", this.EH ? "0" : "1");
        g.Bj(a, "AID", this.Kw);
        U8(this, a);
        if (!g.Ae || g.wc(10)) g.Bj(a, "TYPE", "xmlhttp"), Hlb(this.yg, a, !0, this.PD, !1);
        else {
            g.Bj(a, "TYPE", "html");
            var b = this.yg,
                c = !!this.PD;
            b.Gw = 3;
            b.Vq = Z7(a.clone());
            Mlb(b, c)
        }
    };
    g.k.UP = function(a, b) {
        if (0 != this.j && (this.yg == a || this.Cj == a))
            if (this.Gn = a.Xz, this.Cj == a && 3 == this.j)
                if (7 < this.Ot) {
                    try {
                        var c = this.D.parse(b)
                    } catch (d) {
                        c = null
                    }
                    if (Array.isArray(c) && 3 == c.length)
                        if (a = c, 0 == a[0]) a: {
                            if (!this.yp) {
                                if (this.yg)
                                    if (this.yg.Fw + 3E3 < this.Cj.Fw) T8(this), this.yg.cancel(), this.yg = null;
                                    else break a;
                                imb(this);
                                K8(19)
                            }
                        }
                    else this.WP = a[1], 0 < this.WP - this.Kw && 37500 > a[2] && this.EH && 0 == this.Iw && !this.Pt && (this.Pt = I8((0, g.Oa)(this.dZ, this), 6E3));
                    else V8(this, 11)
                } else null != b && V8(this, 11);
        else if (this.yg ==
            a && T8(this), !g.Lb(b))
            for (a = this.D.parse(b), b = 0; b < a.length; b++) c = a[b], this.Kw = c[0], c = c[1], 2 == this.j ? "c" == c[0] ? (this.C = c[1], this.PD = c[2], c = c[3], null != c ? this.Ot = c : this.Ot = 6, this.j = 3, this.ji && this.ji.bQ(), this.VP = R8(this, this.Zz() ? this.PD : null, this.qI), gmb(this)) : "stop" == c[0] && V8(this, 7) : 3 == this.j && ("stop" == c[0] ? V8(this, 7) : "noop" != c[0] && this.ji && this.ji.aQ(c), this.Iw = 0)
    };
    g.k.dZ = function() {
        null != this.Pt && (this.Pt = null, this.yg.cancel(), this.yg = null, imb(this), K8(20))
    };
    g.k.ND = function(a) {
        if (this.yg == a) {
            T8(this);
            this.yg = null;
            var b = 2
        } else if (this.Cj == a) this.Cj = null, b = 1;
        else return;
        this.Gn = a.Xz;
        if (0 != this.j)
            if (a.wp)
                if (1 == b) {
                    b = Date.now() - a.Fw;
                    var c = J8;
                    c.dispatchEvent(new Xlb(c, a.Nt ? a.Nt.length : 0, b, this.Jw));
                    Zlb(this);
                    this.B.length = 0
                } else gmb(this);
        else {
            c = a.getLastError();
            var d;
            if (!(d = 3 == c || 7 == c || 0 == c && 0 < this.Gn)) {
                if (d = 1 == b) this.Cj || this.Yq || 1 == this.j || 2 <= this.Jw ? d = !1 : (this.Yq = I8((0, g.Oa)(this.YP, this, a), hmb(this, this.Jw)), this.Jw++, d = !0);
                d = !(d || 2 == b && imb(this))
            }
            if (d) switch (c) {
                case 1:
                    V8(this,
                        5);
                    break;
                case 4:
                    V8(this, 10);
                    break;
                case 3:
                    V8(this, 6);
                    break;
                case 7:
                    V8(this, 12);
                    break;
                default:
                    V8(this, 2)
            }
        }
    };
    g.k.bZ = function(a) {
        if (!g.kb(arguments, this.j)) throw Error("Unexpected channel state: " + this.j);
    };
    g.k.Q7 = function(a) {
        a ? K8(2) : (K8(1), jmb(this, 8))
    };
    g.k.nI = function(a) {
        if (a) throw Error("Can't create secondary domain capable XhrIo object.");
        a = new g.ei;
        a.J = !1;
        return a
    };
    g.k.isActive = function() {
        return !!this.ji && this.ji.isActive(this)
    };
    g.k.Xm = function(a) {
        var b = J8;
        b.dispatchEvent(new Ylb(b, a))
    };
    g.k.Zz = function() {
        return !(!g.Ae || g.wc(10))
    };
    g.k = lmb.prototype;
    g.k.bQ = function() {};
    g.k.aQ = function() {};
    g.k.ZP = function() {};
    g.k.rI = function() {};
    g.k.cQ = function() {
        return {}
    };
    g.k.isActive = function() {
        return !0
    };
    g.k = mmb.prototype;
    g.k.Uf = function() {
        return 0 === this.j.length && 0 === this.u.length
    };
    g.k.clear = function() {
        this.j = [];
        this.u = []
    };
    g.k.contains = function(a) {
        return g.kb(this.j, a) || g.kb(this.u, a)
    };
    g.k.remove = function(a) {
        var b = this.j;
        var c = (0, g.O4a)(b, a);
        0 <= c ? (g.ob(b, c), b = !0) : b = !1;
        return b || g.pb(this.u, a)
    };
    g.k.El = function() {
        for (var a = [], b = this.j.length - 1; 0 <= b; --b) a.push(this.j[b]);
        var c = this.u.length;
        for (b = 0; b < c; ++b) a.push(this.u[b]);
        return a
    };
    g.w(nmb, g.db);
    g.w(omb, g.db);
    g.Ra(W8, g.C);
    g.k = W8.prototype;
    g.k.l6 = function() {
        this.Di = Math.min(3E5, 2 * this.Di);
        this.B();
        this.u && this.start()
    };
    g.k.start = function() {
        var a = this.Di + 15E3 * Math.random();
        g.fo(this.j, a);
        this.u = Date.now() + a
    };
    g.k.stop = function() {
        this.j.stop();
        this.u = 0
    };
    g.k.isActive = function() {
        return this.j.isActive()
    };
    g.k.reset = function() {
        this.j.stop();
        this.Di = 5E3
    };
    qmb.prototype.flush = function(a, b) {
        a = void 0 === a ? [] : a;
        b = void 0 === b ? !1 : b;
        if (g.Qv("enable_client_streamz_web")) {
            a = g.t(a);
            for (var c = a.next(); !c.done; c = a.next()) c = g.Bea(c.value), c = {
                serializedIncrementBatch: g.zf(g.lh(c, $ob))
            }, g.Bx("streamzIncremented", c, {
                sendIsolatedPayload: b
            })
        }
    };
    var X8;
    g.Ra(rmb, lmb);
    g.k = rmb.prototype;
    g.k.subscribe = function(a, b, c) {
        return this.B.subscribe(a, b, c)
    };
    g.k.unsubscribe = function(a, b, c) {
        return this.B.unsubscribe(a, b, c)
    };
    g.k.Gh = function(a) {
        return this.B.Gh(a)
    };
    g.k.ma = function(a, b) {
        return this.B.ma.apply(this.B, arguments)
    };
    g.k.dispose = function() {
        this.ea || (this.ea = !0, g.Za(this.B), this.disconnect(), g.Za(this.u), this.u = null, this.oa = function() {
            return ""
        })
    };
    g.k.isDisposed = function() {
        return this.ea
    };
    g.k.connect = function(a, b, c) {
        if (!this.j || 2 != this.j.getState()) {
            this.Z = "";
            this.u.stop();
            this.I = a || null;
            this.D = b || 0;
            a = this.ya + "/test";
            b = this.ya + "/bind";
            var d = new Vlb(c ? c.firstTestResults : null, c ? c.secondTestResults : null, this.Pa),
                e = this.j;
            e && (e.ji = null);
            d.ji = this;
            this.j = d;
            smb(this);
            if (this.j) {
                d = g.L("ID_TOKEN");
                var f = this.j.Fn || {};
                d ? f["x-youtube-identity-token"] = d : delete f["x-youtube-identity-token"];
                this.j.Fn = f
            }
            e ? (3 != e.getState() && 0 == cmb(e) || e.getState(), this.j.connect(a, b, this.J, e.C, e.Kw)) : c ? this.j.connect(a,
                b, this.J, c.sessionId, c.arrayId) : this.j.connect(a, b, this.J)
        }
    };
    g.k.disconnect = function(a) {
        this.T = a || 0;
        this.u.stop();
        smb(this);
        this.j && (3 == this.j.getState() && fmb(this.j), this.j.disconnect());
        this.T = 0
    };
    g.k.sendMessage = function(a, b) {
        a = {
            _sc: a
        };
        b && g.Wc(a, b);
        this.u.isActive() || 2 == (this.j ? this.j.getState() : 0) ? this.C.push(a) : this.ey() && (smb(this), bmb(this.j, a))
    };
    g.k.bQ = function() {
        this.u.reset();
        this.I = null;
        this.D = 0;
        if (this.C.length) {
            var a = this.C;
            this.C = [];
            for (var b = 0, c = a.length; b < c; ++b) bmb(this.j, a[b])
        }
        this.ma("handlerOpened");
        ykb(this.Ma, "BROWSER_CHANNEL")
    };
    g.k.ZP = function(a) {
        var b = 2 == a && 401 == this.j.Gn;
        4 == a || b || this.u.start();
        this.ma("handlerError", a, b);
        Ekb(this.Ba, "BROWSER_CHANNEL")
    };
    g.k.rI = function(a, b) {
        if (!this.u.isActive()) this.ma("handlerClosed");
        else if (b)
            for (var c = 0, d = b.length; c < d; ++c) {
                var e = b[c].map;
                e && this.C.push(e)
            }
        Akb(this.Aa, "BROWSER_CHANNEL");
        a && this.Ya.j.uI("/client_streamz/youtube/living_room/mdx/browser_channel/pending_maps", a.length);
        b && this.Xa.j.uI("/client_streamz/youtube/living_room/mdx/browser_channel/undelivered_maps", b.length)
    };
    g.k.cQ = function() {
        var a = {
            v: 2
        };
        this.Z && (a.gsessionid = this.Z);
        0 != this.D && (a.ui = "" + this.D);
        0 != this.T && (a.ui = "" + this.T);
        this.I && g.Wc(a, this.I);
        return a
    };
    g.k.aQ = function(a) {
        "S" == a[0] ? this.Z = a[1] : "gracefulReconnect" == a[0] ? (this.u.start(), this.j.disconnect()) : this.ma("handlerMessage", new pmb(a[0], a[1]));
        Ckb(this.Ia, "BROWSER_CHANNEL")
    };
    g.k.ey = function() {
        return !!this.j && 3 == this.j.getState()
    };
    g.k.Kq = function(a) {
        (this.J.loungeIdToken = a) || this.u.stop();
        if (this.Va && this.j) {
            var b = this.j.Fn || {};
            a ? b["X-YouTube-LoungeId-Token"] = a : delete b["X-YouTube-LoungeId-Token"];
            this.j.Fn = b
        }
    };
    g.k.Qr = function() {
        return this.J.id
    };
    g.k.gs = function() {
        return this.u.isActive() ? this.u.u - Date.now() : NaN
    };
    g.k.Mv = function() {
        var a = this.u;
        g.go(a.j);
        a.start()
    };
    g.k.o7 = function() {
        this.u.isActive();
        0 == cmb(this.j) && this.connect(this.I, this.D)
    };
    Y8.prototype.C = function(a, b, c, d) {
        b ? a(d) : a({
            text: c.responseText
        })
    };
    Y8.prototype.B = function(a, b) {
        a(Error("Request error: " + b.status))
    };
    Y8.prototype.D = function(a) {
        a(Error("request timed out"))
    };
    g.w(umb, g.pd);
    g.k = umb.prototype;
    g.k.connect = function(a, b, c) {
        this.rd.connect(a, b, c)
    };
    g.k.disconnect = function(a) {
        this.rd.disconnect(a)
    };
    g.k.Mv = function() {
        this.rd.Mv()
    };
    g.k.Qr = function() {
        return this.rd.Qr()
    };
    g.k.gs = function() {
        return this.rd.gs()
    };
    g.k.ey = function() {
        return this.rd.ey()
    };
    g.k.gZ = function() {
        this.dispatchEvent("channelOpened");
        var a = this.rd,
            b = this.j;
        g.KA("yt-remote-session-browser-channel", {
            firstTestResults: [""],
            secondTestResults: !a.j.EH,
            sessionId: a.j.C,
            arrayId: a.j.Kw
        });
        g.KA("yt-remote-session-screen-id", b);
        a = h8();
        b = i8();
        g.kb(a, b) || a.push(b);
        ckb(a);
        ekb()
    };
    g.k.eZ = function() {
        this.dispatchEvent("channelClosed")
    };
    g.k.fZ = function(a) {
        this.dispatchEvent(new nmb(a))
    };
    g.k.onError = function(a) {
        this.dispatchEvent(new omb(a ? 1 : 0))
    };
    g.k.sendMessage = function(a, b) {
        this.rd.sendMessage(a, b)
    };
    g.k.Kq = function(a) {
        this.rd.Kq(a)
    };
    g.k.dispose = function() {
        this.rd.dispose()
    };
    g.k = vmb.prototype;
    g.k.connect = function(a, b) {
        a = void 0 === a ? {} : a;
        b = void 0 === b ? 0 : b;
        2 !== this.I && (this.B.stop(), this.T = a, this.J = b, xmb(this), (a = g.L("ID_TOKEN")) ? this.C["x-youtube-identity-token"] = a : delete this.C["x-youtube-identity-token"], this.j && (this.u.device = this.j.device, this.u.name = this.j.name, this.u.app = this.j.app, this.u.id = this.j.id, this.j.t3 && (this.u.mdxVersion = "" + this.j.t3), this.j.theme && (this.u.theme = this.j.theme), this.j.capabilities && (this.u.capabilities = this.j.capabilities), this.j.W0 && (this.u.cst = this.j.W0)),
            0 !== this.J ? this.u.ui = "" + this.J : delete this.u.ui, Object.assign(this.u, this.T), this.channel = new H8(this.pathPrefix, {
                I2: "gsessionid",
                x3: this.C,
                y3: this.u
            }), this.channel.open(), this.I = 2, wmb(this))
    };
    g.k.disconnect = function(a) {
        this.Z = void 0 === a ? 0 : a;
        this.B.stop();
        xmb(this);
        this.channel && (0 !== this.Z ? this.u.ui = "" + this.Z : delete this.u.ui, this.channel.close());
        this.Z = 0
    };
    g.k.gs = function() {
        return this.B.isActive() ? this.B.u - Date.now() : NaN
    };
    g.k.Mv = function() {
        var a = this.B;
        g.go(a.j);
        a.start()
    };
    g.k.sendMessage = function(a, b) {
        this.channel && (xmb(this), a = Object.assign({}, {
            _sc: a
        }, b), this.channel.send(a))
    };
    g.k.Kq = function(a) {
        a || this.B.stop();
        a ? this.C["X-YouTube-LoungeId-Token"] = a : delete this.C["X-YouTube-LoungeId-Token"]
    };
    g.k.Qr = function() {
        return this.j ? this.j.id : ""
    };
    g.k.ma = function(a) {
        return this.D.ma.apply(this.D, [a].concat(g.u(g.xa.apply(1, arguments))))
    };
    g.k.subscribe = function(a, b, c) {
        return this.D.subscribe(a, b, c)
    };
    g.k.unsubscribe = function(a, b, c) {
        return this.D.unsubscribe(a, b, c)
    };
    g.k.Gh = function(a) {
        return this.D.Gh(a)
    };
    g.k.dispose = function() {
        this.ea || (this.ea = !0, g.Za(this.D), this.disconnect(), g.Za(this.B), this.ya = function() {
            return ""
        })
    };
    g.k.isDisposed = function() {
        return this.ea
    };
    g.w(ymb, g.pd);
    g.k = ymb.prototype;
    g.k.connect = function(a, b) {
        this.j.connect(a, b)
    };
    g.k.disconnect = function(a) {
        this.j.disconnect(a)
    };
    g.k.Mv = function() {
        this.j.Mv()
    };
    g.k.Qr = function() {
        return this.j.Qr()
    };
    g.k.gs = function() {
        return this.j.gs()
    };
    g.k.ey = function() {
        return 3 === this.j.I
    };
    g.k.jZ = function() {
        this.dispatchEvent("channelOpened")
    };
    g.k.hZ = function() {
        this.dispatchEvent("channelClosed")
    };
    g.k.iZ = function(a) {
        this.dispatchEvent(new nmb(a))
    };
    g.k.onError = function() {
        this.dispatchEvent(new omb(401 === this.j.Dg ? 1 : 0))
    };
    g.k.sendMessage = function(a, b) {
        this.j.sendMessage(a, b)
    };
    g.k.Kq = function(a) {
        this.j.Kq(a)
    };
    g.k.dispose = function() {
        this.j.dispose()
    };
    var Gmb = Date.now(),
        $8 = null,
        d9 = Array(50),
        c9 = -1,
        e9 = !1;
    g.Ra(f9, g.LB);
    f9.prototype.rk = function() {
        return this.screens
    };
    f9.prototype.contains = function(a) {
        return !!$jb(this.screens, a)
    };
    f9.prototype.get = function(a) {
        return a ? g8(this.screens, a) : null
    };
    f9.prototype.info = function(a) {
        a9(this.I, a)
    };
    g.w(Kmb, g.LB);
    g.k = Kmb.prototype;
    g.k.start = function() {
        !this.j && isNaN(this.Dc) && this.JV()
    };
    g.k.stop = function() {
        this.j && (this.j.abort(), this.j = null);
        isNaN(this.Dc) || (g.mw(this.Dc), this.Dc = NaN)
    };
    g.k.ra = function() {
        this.stop();
        g.LB.prototype.ra.call(this)
    };
    g.k.JV = function() {
        this.Dc = NaN;
        this.j = g.pw(Z8(this.B, "/pairing/get_screen"), {
            method: "POST",
            postParams: {
                pairing_code: this.J
            },
            timeout: 5E3,
            onSuccess: (0, g.Oa)(this.lZ, this),
            onError: (0, g.Oa)(this.kZ, this),
            onTimeout: (0, g.Oa)(this.mZ, this)
        })
    };
    g.k.lZ = function(a, b) {
        this.j = null;
        a = b.screen || {};
        a.dialId = this.C;
        a.name = this.I;
        b = -1;
        this.D && a.shortLivedLoungeToken && a.shortLivedLoungeToken.value && a.shortLivedLoungeToken.refreshIntervalMs && (a.screenIdType = "shortLived", a.loungeToken = a.shortLivedLoungeToken.value, b = a.shortLivedLoungeToken.refreshIntervalMs);
        this.ma("pairingComplete", new d8(a), b)
    };
    g.k.kZ = function(a) {
        this.j = null;
        a.status && 404 == a.status ? this.u >= apb.length ? this.ma("pairingFailed", Error("DIAL polling timed out")) : (a = apb[this.u], this.Dc = g.kw((0, g.Oa)(this.JV, this), a), this.u++) : this.ma("pairingFailed", Error("Server error " + a.status))
    };
    g.k.mZ = function() {
        this.j = null;
        this.ma("pairingFailed", Error("Server not responding"))
    };
    var apb = [2E3, 2E3, 1E3, 1E3, 1E3, 2E3, 2E3, 5E3, 5E3, 1E4];
    g.Ra(h9, f9);
    g.k = h9.prototype;
    g.k.start = function() {
        g9(this) && this.ma("screenChange");
        !g.LA("yt-remote-lounge-token-expiration") && Lmb(this);
        g.mw(this.j);
        this.j = g.kw((0, g.Oa)(this.start, this), 1E4)
    };
    g.k.add = function(a, b) {
        g9(this);
        Hmb(this, a);
        i9(this, !1);
        this.ma("screenChange");
        b(a);
        a.token || Lmb(this)
    };
    g.k.remove = function(a, b) {
        var c = g9(this);
        Jmb(this, a) && (i9(this, !1), c = !0);
        b(a);
        c && this.ma("screenChange")
    };
    g.k.DH = function(a, b, c, d) {
        var e = g9(this),
            f = this.get(a.id);
        f ? (f.name != b && (f.name = b, i9(this, !1), e = !0), c(a)) : d(Error("no such local screen."));
        e && this.ma("screenChange")
    };
    g.k.ra = function() {
        g.mw(this.j);
        h9.zf.ra.call(this)
    };
    g.k.e2 = function(a) {
        g9(this);
        var b = this.screens.length;
        a = a && a.screens || [];
        for (var c = 0, d = a.length; c < d; ++c) {
            var e = a[c],
                f = this.get(e.screenId);
            f && (f.token = e.loungeToken, --b)
        }
        i9(this, !b);
        b && a9(this.I, "Missed " + b + " lounge tokens.")
    };
    g.k.d2 = function(a) {
        a9(this.I, "Requesting lounge tokens failed: " + a)
    };
    g.w(Nmb, g.LB);
    g.k = Nmb.prototype;
    g.k.start = function() {
        var a = parseInt(g.LA("yt-remote-fast-check-period") || "0", 10);
        (this.C = g.Qa() - 144E5 < a ? 0 : a) ? j9(this): (this.C = g.Qa() + 3E5, g.KA("yt-remote-fast-check-period", this.C), this.EN())
    };
    g.k.Uf = function() {
        return g.Pc(this.j)
    };
    g.k.update = function() {
        Mmb("Updating availability on schedule.");
        var a = this.I(),
            b = g.Cc(this.j, function(c, d) {
                return c && !!g8(a, d)
            }, this);
        Qmb(this, b)
    };
    g.k.ra = function() {
        g.mw(this.B);
        this.B = NaN;
        this.u && (this.u.abort(), this.u = null);
        g.LB.prototype.ra.call(this)
    };
    g.k.EN = function() {
        g.mw(this.B);
        this.B = NaN;
        this.u && this.u.abort();
        var a = Rmb(this);
        if (Ljb(a)) {
            var b = Z8(this.D, "/pairing/get_screen_availability");
            this.u = tmb(this.D, b, {
                lounge_token: g.Hc(a).join(",")
            }, (0, g.Oa)(this.R5, this, a), (0, g.Oa)(this.Q5, this))
        } else Qmb(this, {}), j9(this)
    };
    g.k.R5 = function(a, b) {
        this.u = null;
        var c = g.Hc(Rmb(this));
        if (g.Db(c, g.Hc(a))) {
            b = b.screens || [];
            c = {};
            for (var d = b.length, e = 0; e < d; ++e) c[a[b[e].loungeToken]] = "online" == b[e].status;
            Qmb(this, c);
            j9(this)
        } else this.Of("Changing Screen set during request."), this.EN()
    };
    g.k.Q5 = function(a) {
        this.Of("Screen availability failed: " + a);
        this.u = null;
        j9(this)
    };
    g.k.Of = function(a) {
        a9("OnlineScreenService", a)
    };
    g.Ra(k9, f9);
    g.k = k9.prototype;
    g.k.start = function() {
        this.u.start();
        this.j.start();
        this.screens.length && (this.ma("screenChange"), this.j.Uf() || this.ma("onlineScreenChange"))
    };
    g.k.add = function(a, b, c) {
        this.u.add(a, b, c)
    };
    g.k.remove = function(a, b, c) {
        this.u.remove(a, b, c);
        this.j.update()
    };
    g.k.DH = function(a, b, c, d) {
        this.u.contains(a) ? this.u.DH(a, b, c, d) : (a = "Updating name of unknown screen: " + a.name, a9(this.I, a), d(Error(a)))
    };
    g.k.rk = function(a) {
        return a ? this.screens : g.rb(this.screens, g.wm(this.B, function(b) {
            return !this.contains(b)
        }, this))
    };
    g.k.dQ = function() {
        return g.wm(this.rk(!0), function(a) {
            return !!this.j.j[a.id]
        }, this)
    };
    g.k.eQ = function(a, b, c, d, e, f) {
        var h = this;
        this.info("getDialScreenByPairingCode " + a + " / " + b);
        var l = new Kmb(this.C, a, b, c, d);
        l.subscribe("pairingComplete", function(m, n) {
            g.Za(l);
            e(l9(h, m), n)
        });
        l.subscribe("pairingFailed", function(m) {
            g.Za(l);
            f(m)
        });
        l.start();
        return (0, g.Oa)(l.stop, l)
    };
    g.k.nZ = function(a, b, c, d) {
        g.pw(Z8(this.C, "/pairing/get_screen"), {
            method: "POST",
            postParams: {
                pairing_code: a
            },
            timeout: 5E3,
            onSuccess: (0, g.Oa)(function(e, f) {
                e = new d8(f.screen || {});
                if (!e.name || Vmb(this, e.name)) {
                    a: {
                        f = e.name;
                        for (var h = 2, l = b(f, h); Vmb(this, l);) {
                            h++;
                            if (20 < h) break a;
                            l = b(f, h)
                        }
                        f = l
                    }
                    e.name = f
                }
                c(l9(this, e))
            }, this),
            onError: (0, g.Oa)(function(e) {
                d(Error("pairing request failed: " + e.status))
            }, this),
            onTimeout: (0, g.Oa)(function() {
                d(Error("pairing request timed out."))
            }, this)
        })
    };
    g.k.ra = function() {
        g.Za(this.u);
        g.Za(this.j);
        k9.zf.ra.call(this)
    };
    g.k.q2 = function() {
        Xmb(this);
        this.ma("screenChange");
        this.j.update()
    };
    k9.prototype.dispose = k9.prototype.dispose;
    g.Ra(m9, g.LB);
    g.k = m9.prototype;
    g.k.ej = function(a) {
        this.isDisposed() || (a && (o9(this, "" + a), this.ma("sessionFailed")), this.j = null, this.ma("sessionScreen", null))
    };
    g.k.info = function(a) {
        a9(this.Ba, a)
    };
    g.k.fQ = function() {
        return null
    };
    g.k.YN = function(a) {
        var b = this.u;
        a ? (b.displayStatus = new chrome.cast.ReceiverDisplayStatus(a, []), b.displayStatus.showStop = !0) : b.displayStatus = null;
        chrome.cast.setReceiverDisplayStatus(b, (0, g.Oa)(function() {
            this.info("Updated receiver status for " + b.friendlyName + ": " + a)
        }, this), (0, g.Oa)(function() {
            o9(this, "Failed to update receiver status for: " + b.friendlyName)
        }, this))
    };
    g.k.ra = function() {
        this.YN("");
        m9.zf.ra.call(this)
    };
    g.w(p9, m9);
    g.k = p9.prototype;
    g.k.XN = function(a) {
        if (this.B) {
            if (this.B == a) return;
            o9(this, "Overriding cast session with new session object");
            inb(this);
            this.ya = !1;
            this.Z = "unknown";
            this.B.removeUpdateListener(this.oa);
            this.B.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.Aa)
        }
        this.B = a;
        this.B.addUpdateListener(this.oa);
        this.B.addMessageListener("urn:x-cast:com.google.youtube.mdx", this.Aa);
        dnb(this, "getMdxSessionStatus")
    };
    g.k.vy = function(a) {
        this.info("launchWithParams no-op for Cast: " + g.Hh(a))
    };
    g.k.stop = function() {
        this.B ? this.B.stop((0, g.Oa)(function() {
            this.ej()
        }, this), (0, g.Oa)(function() {
            this.ej(Error("Failed to stop receiver app."))
        }, this)) : this.ej(Error("Stopping cast device without session."))
    };
    g.k.YN = function() {};
    g.k.ra = function() {
        this.info("disposeInternal");
        inb(this);
        this.B && (this.B.removeUpdateListener(this.oa), this.B.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.Aa));
        this.B = null;
        m9.prototype.ra.call(this)
    };
    g.k.D6 = function(a, b) {
        if (!this.isDisposed())
            if (b)
                if (b = a8(b), g.Ja(b)) switch (a = "" + b.type, b = b.data || {}, this.info("onYoutubeMessage_: " + a + " " + g.Hh(b)), a) {
                    case "mdxSessionStatus":
                        anb(this, b);
                        break;
                    case "loungeToken":
                        enb(this, b);
                        break;
                    default:
                        o9(this, "Unknown youtube message: " + a)
                } else o9(this, "Unable to parse message.");
                else o9(this, "No data in message.")
    };
    g.k.US = function(a, b, c, d) {
        g.mw(this.T);
        this.T = 0;
        Umb(this.C, this.u.label, a, this.u.friendlyName, (0, g.Oa)(function(e) {
            e ? b(e) : 0 <= d ? (o9(this, "Screen " + a + " appears to be offline. " + d + " retries left."), this.T = g.kw((0, g.Oa)(this.US, this, a, b, c, d - 1), 300)) : c(Error("Unable to fetch screen."))
        }, this), c)
    };
    g.k.fQ = function() {
        return this.B
    };
    g.k.oZ = function(a) {
        this.isDisposed() || a || (o9(this, "Cast session died."), this.ej())
    };
    g.w(q9, m9);
    g.k = q9.prototype;
    g.k.XN = function(a) {
        this.B = a;
        this.B.addUpdateListener(this.Ia)
    };
    g.k.vy = function(a) {
        this.Ma = a;
        this.ea()
    };
    g.k.stop = function() {
        qnb(this);
        this.B ? this.B.stop((0, g.Oa)(this.ej, this, null), (0, g.Oa)(this.ej, this, "Failed to stop DIAL device.")) : this.ej()
    };
    g.k.ra = function() {
        qnb(this);
        this.B && this.B.removeUpdateListener(this.Ia);
        this.B = null;
        m9.prototype.ra.call(this)
    };
    g.k.pZ = function(a) {
        this.isDisposed() || a || (o9(this, "DIAL session died."), this.D(), this.D = function() {}, this.ej())
    };
    g.w(t9, m9);
    t9.prototype.stop = function() {
        this.ej()
    };
    t9.prototype.XN = function() {};
    t9.prototype.vy = function() {
        g.mw(this.B);
        this.B = NaN;
        var a = g8(this.C.rk(), this.u.label);
        a ? n9(this, a) : this.ej(Error("No such screen"))
    };
    t9.prototype.ra = function() {
        g.mw(this.B);
        this.B = NaN;
        m9.prototype.ra.call(this)
    };
    g.w(u9, g.LB);
    g.k = u9.prototype;
    g.k.init = function(a, b) {
        chrome.cast.timeout.requestSession = 3E4;
        var c = new chrome.cast.SessionRequest(this.T, [chrome.cast.Capability.AUDIO_OUT]);
        this.Z || (c.dialRequest = new chrome.cast.DialRequest("YouTube"));
        var d = chrome.cast.AutoJoinPolicy.TAB_AND_ORIGIN_SCOPED;
        a = a || this.I ? chrome.cast.DefaultActionPolicy.CAST_THIS_TAB : chrome.cast.DefaultActionPolicy.CREATE_SESSION;
        var e = (0, g.Oa)(this.C5, this);
        c = new chrome.cast.ApiConfig(c, (0, g.Oa)(this.qV, this), e, d, a);
        c.customDialLaunchCallback = (0, g.Oa)(this.A4, this);
        chrome.cast.initialize(c, (0, g.Oa)(function() {
            this.isDisposed() || (chrome.cast.addReceiverActionListener(this.D), Dmb(), this.u.subscribe("onlineScreenChange", (0, g.Oa)(this.gQ, this)), this.B = tnb(this), chrome.cast.setCustomReceivers(this.B, function() {}, (0, g.Oa)(function(f) {
                this.Of("Failed to set initial custom receivers: " + g.Hh(f))
            }, this)), this.ma("yt-remote-cast2-availability-change", w9(this)), b(!0))
        }, this), (0, g.Oa)(function(f) {
            this.Of("Failed to initialize API: " + g.Hh(f));
            b(!1)
        }, this))
    };
    g.k.t7 = function(a, b) {
        v9("Setting connected screen ID: " + a + " -> " + b);
        if (this.j) {
            var c = this.j.j;
            if (!a || c && c.id != a) v9("Unsetting old screen status: " + this.j.u.friendlyName), x9(this, null)
        }
        if (a && b) {
            if (!this.j) {
                c = g8(this.u.rk(), a);
                if (!c) {
                    v9("setConnectedScreenStatus: Unknown screen.");
                    return
                }
                if ("shortLived" == c.idType) {
                    v9("setConnectedScreenStatus: Screen with id type to be short lived.");
                    return
                }
                a = rnb(this, c);
                a || (v9("setConnectedScreenStatus: Connected receiver not custom..."), a = new chrome.cast.Receiver(c.uuid ?
                    c.uuid : c.id, c.name), a.receiverType = chrome.cast.ReceiverType.CUSTOM, this.B.push(a), chrome.cast.setCustomReceivers(this.B, function() {}, (0, g.Oa)(function(d) {
                    this.Of("Failed to set initial custom receivers: " + g.Hh(d))
                }, this)));
                v9("setConnectedScreenStatus: new active receiver: " + a.friendlyName);
                x9(this, new t9(this.u, a), !0)
            }
            this.j.YN(b)
        } else v9("setConnectedScreenStatus: no screen.")
    };
    g.k.u7 = function(a) {
        this.isDisposed() ? this.Of("Setting connection data on disposed cast v2") : this.j ? this.j.vy(a) : this.Of("Setting connection data without a session")
    };
    g.k.rZ = function() {
        this.isDisposed() ? this.Of("Stopping session on disposed cast v2") : this.j ? (this.j.stop(), x9(this, null)) : v9("Stopping non-existing session")
    };
    g.k.requestSession = function() {
        chrome.cast.requestSession((0, g.Oa)(this.qV, this), (0, g.Oa)(this.U5, this))
    };
    g.k.ra = function() {
        this.u.unsubscribe("onlineScreenChange", (0, g.Oa)(this.gQ, this));
        window.chrome && chrome.cast && chrome.cast.removeReceiverActionListener(this.D);
        var a = Amb,
            b = g.Ha("yt.mdx.remote.debug.handlers_");
        g.pb(b || [], a);
        g.Za(this.j);
        g.LB.prototype.ra.call(this)
    };
    g.k.Of = function(a) {
        a9("Controller", a)
    };
    g.k.sV = function(a, b) {
        this.j == a && (b || x9(this, null), this.ma("yt-remote-cast2-session-change", b))
    };
    g.k.z5 = function(a, b) {
        if (!this.isDisposed())
            if (a) switch (a.friendlyName = chrome.cast.unescape(a.friendlyName), v9("onReceiverAction_ " + a.label + " / " + a.friendlyName + "-- " + b), b) {
                case chrome.cast.ReceiverAction.CAST:
                    if (this.j)
                        if (this.j.u.label != a.label) v9("onReceiverAction_: Stopping active receiver: " + this.j.u.friendlyName), this.j.stop();
                        else {
                            v9("onReceiverAction_: Casting to active receiver.");
                            this.j.j && this.ma("yt-remote-cast2-session-change", this.j.j);
                            break
                        }
                    switch (a.receiverType) {
                        case chrome.cast.ReceiverType.CUSTOM:
                            x9(this,
                                new t9(this.u, a));
                            break;
                        case chrome.cast.ReceiverType.DIAL:
                            x9(this, new q9(this.u, a, this.C, this.config_));
                            break;
                        case chrome.cast.ReceiverType.CAST:
                            x9(this, new p9(this.u, a, this.config_));
                            break;
                        default:
                            this.Of("Unknown receiver type: " + a.receiverType)
                    }
                    break;
                case chrome.cast.ReceiverAction.STOP:
                    this.j && this.j.u.label == a.label ? this.j.stop() : this.Of("Stopping receiver w/o session: " + a.friendlyName)
            } else this.Of("onReceiverAction_ called without receiver.")
    };
    g.k.A4 = function(a) {
        if (this.isDisposed()) return Promise.reject(Error("disposed"));
        var b = a.receiver;
        b.receiverType != chrome.cast.ReceiverType.DIAL && (this.Of("Not DIAL receiver: " + b.friendlyName), b.receiverType = chrome.cast.ReceiverType.DIAL);
        var c = this.j ? this.j.u : null;
        if (!c || c.label != b.label) return this.Of("Receiving DIAL launch request for non-clicked DIAL receiver: " + b.friendlyName), Promise.reject(Error("illegal DIAL launch"));
        if (c && c.label == b.label && c.receiverType != chrome.cast.ReceiverType.DIAL) {
            if (this.j.j) return v9("Reselecting dial screen."),
                this.ma("yt-remote-cast2-session-change", this.j.j), Promise.resolve(new chrome.cast.DialLaunchResponse(!1));
            this.Of('Changing CAST intent from "' + c.receiverType + '" to "dial" for ' + b.friendlyName);
            x9(this, new q9(this.u, b, this.C, this.config_))
        }
        b = this.j;
        b.T = a;
        b.T.appState == chrome.cast.DialAppState.RUNNING ? (a = b.T.extraData || {}, c = a.screenId || null, r9(b) && a.loungeToken ? a.loungeTokenRefreshIntervalMs ? a = nnb(b, {
                name: b.u.friendlyName,
                screenId: a.screenId,
                loungeToken: a.loungeToken,
                dialId: b.T.receiver.label,
                screenIdType: "shortLived"
            },
            a.loungeTokenRefreshIntervalMs) : (g.Vv(Error("No loungeTokenRefreshIntervalMs presents in additionalData: " + JSON.stringify(a) + ".")), a = onb(b, c)) : a = onb(b, c)) : a = lnb(b);
        return a
    };
    g.k.qV = function(a) {
        var b = this;
        if (!this.isDisposed() && !this.I) {
            v9("New cast session ID: " + a.sessionId);
            var c = a.receiver;
            if (c.receiverType != chrome.cast.ReceiverType.CUSTOM) {
                if (!this.j)
                    if (c.receiverType == chrome.cast.ReceiverType.CAST) v9("Got resumed cast session before resumed mdx connection."), c.friendlyName = chrome.cast.unescape(c.friendlyName), x9(this, new p9(this.u, c, this.config_), !0);
                    else {
                        this.Of("Got non-cast session without previous mdx receiver event, or mdx resume.");
                        return
                    }
                var d = this.j.u,
                    e = g8(this.u.rk(),
                        d.label);
                e && e8(e, c.label) && d.receiverType != chrome.cast.ReceiverType.CAST && c.receiverType == chrome.cast.ReceiverType.CAST && (v9("onSessionEstablished_: manual to cast session change " + c.friendlyName), g.Za(this.j), this.j = new p9(this.u, c, this.config_), this.j.subscribe("sessionScreen", (0, g.Oa)(this.sV, this, this.j)), this.j.subscribe("sessionFailed", function() {
                    return snb(b, b.j)
                }), this.j.vy(null));
                this.j.XN(a)
            }
        }
    };
    g.k.qZ = function() {
        return this.j ? this.j.fQ() : null
    };
    g.k.U5 = function(a) {
        this.isDisposed() || (this.Of("Failed to estabilish a session: " + g.Hh(a)), a.code != chrome.cast.ErrorCode.CANCEL && x9(this, null), this.ma("yt-remote-cast2-session-failed"))
    };
    g.k.C5 = function(a) {
        v9("Receiver availability updated: " + a);
        if (!this.isDisposed()) {
            var b = w9(this);
            this.J = a == chrome.cast.ReceiverAvailability.AVAILABLE;
            w9(this) != b && this.ma("yt-remote-cast2-availability-change", w9(this))
        }
    };
    g.k.gQ = function() {
        this.isDisposed() || (this.B = tnb(this), v9("Updating custom receivers: " + g.Hh(this.B)), chrome.cast.setCustomReceivers(this.B, function() {}, (0, g.Oa)(function() {
            this.Of("Failed to set custom receivers.")
        }, this)), this.ma("yt-remote-cast2-availability-change", w9(this)))
    };
    u9.prototype.setLaunchParams = u9.prototype.u7;
    u9.prototype.setConnectedScreenStatus = u9.prototype.t7;
    u9.prototype.stopSession = u9.prototype.rZ;
    u9.prototype.getCastSession = u9.prototype.qZ;
    u9.prototype.requestSession = u9.prototype.requestSession;
    u9.prototype.init = u9.prototype.init;
    u9.prototype.dispose = u9.prototype.dispose;
    var Cnb = [];
    g.k = E9.prototype;
    g.k.reset = function(a) {
        this.listId = "";
        this.index = -1;
        this.videoId = "";
        Inb(this);
        this.volume = -1;
        this.muted = !1;
        a && (this.index = a.index, this.listId = a.listId, this.videoId = a.videoId, this.playerState = a.playerState, this.volume = a.volume, this.muted = a.muted, this.audioTrackId = a.audioTrackId, this.trackData = a.trackData, this.Fo = a.hasPrevious, this.yk = a.hasNext, this.J = a.playerTime, this.I = a.playerTimeAt, this.C = a.seekableStart, this.j = a.seekableEnd, this.D = a.duration, this.T = a.loadedTime, this.B = a.liveIngestionTime, this.u = !isNaN(this.B))
    };
    g.k.Zc = function() {
        return 1 == this.playerState
    };
    g.k.Mk = function(a) {
        this.D = isNaN(a) ? 0 : a
    };
    g.k.getDuration = function() {
        return this.u ? this.D + F9(this) : this.D
    };
    g.k.clone = function() {
        return new E9(Jnb(this))
    };
    g.w(K9, g.LB);
    g.k = K9.prototype;
    g.k.getState = function() {
        return this.B
    };
    g.k.gs = function() {
        return this.C.getReconnectTimeout()
    };
    g.k.Mv = function() {
        this.C.reconnect()
    };
    g.k.play = function() {
        M9(this) ? (this.j ? this.j.play(null, g.ud, Q9(this, "play")) : P9(this, "play"), Mnb(this, 1, H9(L9(this))), this.ma("remotePlayerChange")) : N9(this, this.play)
    };
    g.k.pause = function() {
        M9(this) ? (this.j ? this.j.pause(null, g.ud, Q9(this, "pause")) : P9(this, "pause"), Mnb(this, 2, H9(L9(this))), this.ma("remotePlayerChange")) : N9(this, this.pause)
    };
    g.k.seekTo = function(a) {
        if (M9(this)) {
            if (this.j) {
                var b = L9(this),
                    c = new chrome.cast.media.SeekRequest;
                c.currentTime = a;
                b.Zc() || 3 == b.playerState ? c.resumeState = chrome.cast.media.ResumeState.PLAYBACK_START : c.resumeState = chrome.cast.media.ResumeState.PLAYBACK_PAUSE;
                this.j.seek(c, g.ud, Q9(this, "seekTo", {
                    newTime: a
                }))
            } else P9(this, "seekTo", {
                newTime: a
            });
            Mnb(this, 3, a);
            this.ma("remotePlayerChange")
        } else N9(this, g.Pa(this.seekTo, a))
    };
    g.k.stop = function() {
        if (M9(this)) {
            this.j ? this.j.stop(null, g.ud, Q9(this, "stopVideo")) : P9(this, "stopVideo");
            var a = L9(this);
            a.index = -1;
            a.videoId = "";
            Inb(a);
            O9(this, a);
            this.ma("remotePlayerChange")
        } else N9(this, this.stop)
    };
    g.k.setVolume = function(a, b) {
        if (M9(this)) {
            var c = L9(this);
            if (this.u) {
                if (c.volume != a) {
                    var d = Math.round(a) / 100;
                    this.u.setReceiverVolumeLevel(d, (0, g.Oa)(function() {
                        b9("set receiver volume: " + d)
                    }, this), (0, g.Oa)(function() {
                        this.Of("failed to set receiver volume.")
                    }, this))
                }
                c.muted != b && this.u.setReceiverMuted(b, (0, g.Oa)(function() {
                    b9("set receiver muted: " + b)
                }, this), (0, g.Oa)(function() {
                    this.Of("failed to set receiver muted.")
                }, this))
            } else {
                var e = {
                    volume: a,
                    muted: b
                }; - 1 != c.volume && (e.delta = a - c.volume);
                P9(this, "setVolume", e)
            }
            c.muted = b;
            c.volume = a;
            O9(this, c)
        } else N9(this, g.Pa(this.setVolume, a, b))
    };
    g.k.hQ = function(a, b) {
        if (M9(this)) {
            var c = L9(this);
            a = {
                videoId: a
            };
            b && (c.trackData = {
                trackName: b.name,
                languageCode: b.languageCode,
                sourceLanguageCode: b.translationLanguage ? b.translationLanguage.languageCode : "",
                languageName: b.languageName,
                kind: b.kind
            }, a.style = g.Hh(b.style), g.Wc(a, c.trackData));
            P9(this, "setSubtitlesTrack", a);
            O9(this, c)
        } else N9(this, g.Pa(this.hQ, a, b))
    };
    g.k.setAudioTrack = function(a, b) {
        M9(this) ? (b = b.getLanguageInfo().getId(), P9(this, "setAudioTrack", {
            videoId: a,
            audioTrackId: b
        }), a = L9(this), a.audioTrackId = b, O9(this, a)) : N9(this, g.Pa(this.setAudioTrack, a, b))
    };
    g.k.playVideo = function(a, b, c, d, e, f, h) {
        d = void 0 === d ? null : d;
        e = void 0 === e ? null : e;
        f = void 0 === f ? null : f;
        h = void 0 === h ? null : h;
        var l = L9(this),
            m = {
                videoId: a
            };
        void 0 !== c && (m.currentIndex = c);
        I9(l, a, c || 0);
        void 0 !== b && (G9(l, b), m.currentTime = b);
        d && (m.listId = d);
        e && (m.playerParams = e);
        f && (m.clickTrackingParams = f);
        h && (m.locationInfo = g.Hh(h));
        P9(this, "setPlaylist", m);
        d || O9(this, l)
    };
    g.k.JG = function(a, b) {
        if (M9(this)) {
            if (a && b) {
                var c = L9(this);
                I9(c, a, b);
                O9(this, c)
            }
            P9(this, "previous")
        } else N9(this, g.Pa(this.JG, a, b))
    };
    g.k.nextVideo = function(a, b) {
        if (M9(this)) {
            if (a && b) {
                var c = L9(this);
                I9(c, a, b);
                O9(this, c)
            }
            P9(this, "next")
        } else N9(this, g.Pa(this.nextVideo, a, b))
    };
    g.k.sx = function() {
        if (M9(this)) {
            P9(this, "clearPlaylist");
            var a = L9(this);
            a.reset();
            O9(this, a);
            this.ma("remotePlayerChange")
        } else N9(this, this.sx)
    };
    g.k.hS = function() {
        M9(this) ? P9(this, "dismissAutoplay") : N9(this, this.hS)
    };
    g.k.dispose = function() {
        if (3 != this.B) {
            var a = this.B;
            this.B = 3;
            this.ma("proxyStateChange", a, this.B)
        }
        g.LB.prototype.dispose.call(this)
    };
    g.k.ra = function() {
        Lnb(this);
        this.C = null;
        this.D.clear();
        J9(this, null);
        g.LB.prototype.ra.call(this)
    };
    g.k.aO = function(a) {
        if ((a != this.B || 2 == a) && 3 != this.B && 0 != a) {
            var b = this.B;
            this.B = a;
            this.ma("proxyStateChange", b, a);
            if (1 == a)
                for (; !this.D.Uf();) b = a = this.D, 0 === b.j.length && (b.j = b.u, b.j.reverse(), b.u = []), a.j.pop().apply(this);
            else 3 == a && this.dispose()
        }
    };
    g.k.x5 = function(a, b) {
        this.ma(a, b)
    };
    g.k.q4 = function(a) {
        if (!a) this.lC(null), J9(this, null);
        else if (this.u.receiver.volume) {
            a = this.u.receiver.volume;
            var b = L9(this),
                c = Math.round(100 * a.level || 0);
            if (b.volume != c || b.muted != a.muted) b9("Cast volume update: " + a.level + (a.muted ? " muted" : "")), b.volume = c, b.muted = !!a.muted, O9(this, b)
        }
    };
    g.k.lC = function(a) {
        b9("Cast media: " + !!a);
        this.j && this.j.removeUpdateListener(this.T);
        if (this.j = a) this.j.addUpdateListener(this.T), Nnb(this), this.ma("remotePlayerChange")
    };
    g.k.p4 = function(a) {
        a ? (Nnb(this), this.ma("remotePlayerChange")) : this.lC(null)
    };
    g.k.CO = function() {
        P9(this, "sendDebugCommand", {
            debugCommand: "stats4nerds "
        })
    };
    g.k.s4 = function() {
        var a = Fnb();
        a && J9(this, a)
    };
    g.k.Of = function(a) {
        a9("CP", a)
    };
    g.w(T9, g.LB);
    g.k = T9.prototype;
    g.k.connect = function(a, b) {
        if (b) {
            var c = b.listId,
                d = b.videoId,
                e = b.videoIds,
                f = b.playerParams,
                h = b.clickTrackingParams,
                l = b.index,
                m = {
                    videoId: d
                },
                n = b.currentTime,
                p = b.locationInfo;
            b = b.loopMode;
            void 0 !== n && (m.currentTime = 5 >= n ? 0 : n);
            f && (m.playerParams = f);
            p && (m.locationInfo = p);
            h && (m.clickTrackingParams = h);
            c && (m.listId = c);
            e && 0 < e.length && (m.videoIds = e.join(","));
            void 0 !== l && (m.currentIndex = l);
            this.Ia && (m.loopMode = b || "LOOP_MODE_OFF");
            c && (this.j.listId = c);
            this.j.videoId = d;
            this.j.index = l || 0;
            this.j.state = 3;
            G9(this.j,
                n);
            this.D = "UNSUPPORTED";
            c = this.Ia ? "setInitialState" : "setPlaylist";
            R9("Connecting with " + c + " and params: " + g.Hh(m));
            this.u.connect({
                method: c,
                params: g.Hh(m)
            }, a, fkb())
        } else R9("Connecting without params"), this.u.connect({}, a, fkb());
        Rnb(this)
    };
    g.k.Kq = function(a) {
        this.u.Kq(a)
    };
    g.k.dispose = function() {
        this.isDisposed() || (g.Fa("yt.mdx.remote.remoteClient_", null), this.ma("beforeDispose"), S9(this, 3));
        g.LB.prototype.dispose.call(this)
    };
    g.k.ra = function() {
        Snb(this);
        Unb(this);
        Tnb(this);
        g.mw(this.T);
        this.T = NaN;
        g.mw(this.Z);
        this.Z = NaN;
        this.C = null;
        g.rz(this.ea);
        this.ea.length = 0;
        this.u.dispose();
        g.LB.prototype.ra.call(this);
        this.D = this.J = this.B = this.j = this.u = null
    };
    g.k.KT = function(a) {
        if (!this.B || 0 === this.B.length) return !1;
        for (var b = g.t(this.B), c = b.next(); !c.done; c = b.next())
            if (!c.value.capabilities.has(a)) return !1;
        return !0
    };
    g.k.R1 = function() {
        var a = 3;
        this.isDisposed() || (a = 0, isNaN(this.oB()) ? this.u.ey() && isNaN(this.I) && (a = 1) : a = 2);
        return a
    };
    g.k.Hx = function(a) {
        R9("Disconnecting with " + a);
        g.Fa("yt.mdx.remote.remoteClient_", null);
        Snb(this);
        this.ma("beforeDisconnect", a);
        1 == a && j8();
        this.u.disconnect(a);
        this.dispose()
    };
    g.k.P1 = function() {
        var a = this.j;
        this.C && (a = this.j.clone(), I9(a, this.C, a.index));
        return Jnb(a)
    };
    g.k.v7 = function(a) {
        var b = this,
            c = new E9(a);
        c.videoId && c.videoId != this.j.videoId && (this.C = c.videoId, g.mw(this.T), this.T = g.kw(function() {
            if (b.C) {
                var e = b.C;
                b.C = null;
                b.j.videoId != e && U9(b, "getNowPlaying")
            }
        }, 5E3));
        var d = [];
        this.j.listId == c.listId && this.j.videoId == c.videoId && this.j.index == c.index || d.push("remoteQueueChange");
        this.j.playerState == c.playerState && this.j.volume == c.volume && this.j.muted == c.muted && H9(this.j) == H9(c) && g.Hh(this.j.trackData) == g.Hh(c.trackData) || d.push("remotePlayerChange");
        this.j.reset(a);
        g.Fb(d, function(e) {
            this.ma(e)
        }, this)
    };
    g.k.RS = function() {
        var a = this.u.Qr(),
            b = g.ib(this.B, function(c) {
                return "REMOTE_CONTROL" == c.type && c.id != a
            });
        return b ? b.id : ""
    };
    g.k.oB = function() {
        return this.u.gs()
    };
    g.k.K1 = function() {
        return this.D || "UNSUPPORTED"
    };
    g.k.L1 = function() {
        return this.J || ""
    };
    g.k.sZ = function() {
        !isNaN(this.oB()) && this.u.Mv()
    };
    g.k.s7 = function(a, b) {
        U9(this, a, b);
        Wnb(this)
    };
    g.k.iQ = function() {
        var a = g.Bw("SID", "") || "",
            b = g.Bw("SAPISID", "") || "",
            c = g.Bw("__Secure-3PAPISID", "") || "";
        if (!a && !b && !c) return "";
        a = g.zf(g.yf(a), 2);
        b = g.zf(g.yf(b), 2);
        c = g.zf(g.yf(c), 2);
        return g.zf(g.yf(a + "," + b + "," + c), 2)
    };
    T9.prototype.subscribe = T9.prototype.subscribe;
    T9.prototype.unsubscribeByKey = T9.prototype.Gh;
    T9.prototype.getProxyState = T9.prototype.R1;
    T9.prototype.disconnect = T9.prototype.Hx;
    T9.prototype.getPlayerContextData = T9.prototype.P1;
    T9.prototype.setPlayerContextData = T9.prototype.v7;
    T9.prototype.getOtherConnectedRemoteId = T9.prototype.RS;
    T9.prototype.getReconnectTimeout = T9.prototype.oB;
    T9.prototype.getAutoplayMode = T9.prototype.K1;
    T9.prototype.getAutoplayVideoId = T9.prototype.L1;
    T9.prototype.reconnect = T9.prototype.sZ;
    T9.prototype.sendMessage = T9.prototype.s7;
    T9.prototype.getXsrfToken = T9.prototype.iQ;
    T9.prototype.isCapabilitySupportedOnConnectedDevices = T9.prototype.KT;
    g.w(hob, f9);
    g.k = hob.prototype;
    g.k.rk = function(a) {
        return this.Ng.$_gs(a)
    };
    g.k.contains = function(a) {
        return !!this.Ng.$_c(a)
    };
    g.k.get = function(a) {
        return this.Ng.$_g(a)
    };
    g.k.start = function() {
        this.Ng.$_st()
    };
    g.k.add = function(a, b, c) {
        this.Ng.$_a(a, b, c)
    };
    g.k.remove = function(a, b, c) {
        this.Ng.$_r(a, b, c)
    };
    g.k.DH = function(a, b, c, d) {
        this.Ng.$_un(a, b, c, d)
    };
    g.k.ra = function() {
        for (var a = 0, b = this.j.length; a < b; ++a) this.Ng.$_ubk(this.j[a]);
        this.j.length = 0;
        this.Ng = null;
        f9.prototype.ra.call(this)
    };
    g.k.tZ = function() {
        this.ma("screenChange")
    };
    g.k.f5 = function() {
        this.ma("onlineScreenChange")
    };
    k9.prototype.$_st = k9.prototype.start;
    k9.prototype.$_gspc = k9.prototype.nZ;
    k9.prototype.$_gsppc = k9.prototype.eQ;
    k9.prototype.$_c = k9.prototype.contains;
    k9.prototype.$_g = k9.prototype.get;
    k9.prototype.$_a = k9.prototype.add;
    k9.prototype.$_un = k9.prototype.DH;
    k9.prototype.$_r = k9.prototype.remove;
    k9.prototype.$_gs = k9.prototype.rk;
    k9.prototype.$_gos = k9.prototype.dQ;
    k9.prototype.$_s = k9.prototype.subscribe;
    k9.prototype.$_ubk = k9.prototype.Gh;
    var e$ = null,
        h$ = !1,
        V9 = null,
        W9 = null,
        sob = null,
        $9 = [];
    g.w(xob, g.C);
    g.k = xob.prototype;
    g.k.ra = function() {
        g.C.prototype.ra.call(this);
        this.j.stop();
        this.u.stop();
        this.J.stop();
        var a = this.wc;
        a.unsubscribe("proxyStateChange", this.pV, this);
        a.unsubscribe("remotePlayerChange", this.pC, this);
        a.unsubscribe("remoteQueueChange", this.uG, this);
        a.unsubscribe("previousNextChange", this.mV, this);
        a.unsubscribe("nowAutoplaying", this.gV, this);
        a.unsubscribe("autoplayDismissed", this.JU, this);
        this.wc = this.module = null
    };
    g.k.wk = function(a) {
        var b = g.xa.apply(1, arguments);
        if (2 != this.wc.B)
            if (i$(this)) {
                if (1081 != L9(this.wc).playerState || "control_seek" !== a) switch (a) {
                    case "control_toggle_play_pause":
                        L9(this.wc).Zc() ? this.wc.pause() : this.wc.play();
                        break;
                    case "control_play":
                        this.wc.play();
                        break;
                    case "control_pause":
                        this.wc.pause();
                        break;
                    case "control_seek":
                        this.I.kI(b[0], b[1]);
                        break;
                    case "control_subtitles_set_track":
                        zob(this, b[0]);
                        break;
                    case "control_set_audio_track":
                        this.setAudioTrack(b[0])
                }
            } else switch (a) {
                case "control_toggle_play_pause":
                case "control_play":
                case "control_pause":
                    b =
                        this.F.getCurrentTime();
                    j$(this, 0 === b ? void 0 : b);
                    break;
                case "control_seek":
                    j$(this, b[0]);
                    break;
                case "control_subtitles_set_track":
                    zob(this, b[0]);
                    break;
                case "control_set_audio_track":
                    this.setAudioTrack(b[0])
            }
    };
    g.k.n4 = function(a) {
        this.J.SY(a)
    };
    g.k.l8 = function(a) {
        this.wk("control_subtitles_set_track", g.Pc(a) ? null : a)
    };
    g.k.UW = function() {
        var a = this.F.getOption("captions", "track");
        g.Pc(a) || zob(this, a)
    };
    g.k.qc = function(a) {
        this.module.qc(a, this.F.getVideoData().lengthSeconds)
    };
    g.k.Q4 = function() {
        g.Pc(this.B) || Aob(this, this.B);
        this.C = !1
    };
    g.k.pV = function(a, b) {
        this.u.stop();
        2 === b && this.LW()
    };
    g.k.pC = function() {
        if (i$(this)) {
            this.j.stop();
            var a = L9(this.wc);
            switch (a.playerState) {
                case 1080:
                case 1081:
                case 1084:
                case 1085:
                    this.module.yh = 1;
                    break;
                case 1082:
                case 1083:
                    this.module.yh = 0;
                    break;
                default:
                    this.module.yh = -1
            }
            switch (a.playerState) {
                case 1081:
                case 1:
                    this.kc(new g.VL(8));
                    this.KW();
                    break;
                case 1085:
                case 3:
                    this.kc(new g.VL(9));
                    break;
                case 1083:
                case 0:
                    this.kc(new g.VL(2));
                    this.I.stop();
                    this.qc(this.F.getVideoData().lengthSeconds);
                    break;
                case 1084:
                    this.kc(new g.VL(4));
                    break;
                case 2:
                    this.kc(new g.VL(4));
                    this.qc(H9(a));
                    break;
                case -1:
                    this.kc(new g.VL(64));
                    break;
                case -1E3:
                    this.kc(new g.VL(128, {
                        errorCode: "mdx.remoteerror",
                        errorMessage: "This video is not available for remote playback.",
                        OE: 2
                    }))
            }
            a = L9(this.wc).trackData;
            var b = this.B;
            (a || b ? a && b && a.trackName == b.trackName && a.languageCode == b.languageCode && a.languageName == b.languageName && a.kind == b.kind : 1) || (this.B = a, Aob(this, a));
            a = L9(this.wc); - 1 === a.volume || Math.round(this.F.getVolume()) === a.volume && this.F.isMuted() === a.muted || this.T.isActive() || this.zX()
        } else yob(this)
    };
    g.k.mV = function() {
        this.F.ma("mdxpreviousnextchange")
    };
    g.k.uG = function() {
        i$(this) || yob(this)
    };
    g.k.gV = function(a) {
        isNaN(a) || this.F.ma("mdxnowautoplaying", a)
    };
    g.k.JU = function() {
        this.F.ma("mdxautoplaycanceled")
    };
    g.k.setAudioTrack = function(a) {
        i$(this) && this.wc.setAudioTrack(this.F.getVideoData(1).videoId, a)
    };
    g.k.seekTo = function(a, b) {
        -1 === L9(this.wc).playerState ? j$(this, a) : b && this.wc.seekTo(a)
    };
    g.k.zX = function() {
        var a = this;
        if (i$(this)) {
            var b = L9(this.wc);
            this.events.Ec(this.Z);
            b.muted ? this.F.mute() : this.F.unMute();
            this.F.setVolume(b.volume);
            this.Z = this.events.S(this.F, "onVolumeChange", function(c) {
                vob(a, c)
            })
        }
    };
    g.k.KW = function() {
        this.j.stop();
        if (!this.wc.isDisposed()) {
            var a = L9(this.wc);
            a.Zc() && this.kc(new g.VL(8));
            this.qc(H9(a));
            this.j.start()
        }
    };
    g.k.LW = function() {
        this.u.stop();
        this.j.stop();
        var a = this.wc.gs();
        2 == this.wc.B && !isNaN(a) && this.u.start()
    };
    g.k.kc = function(a) {
        this.u.stop();
        var b = this.D;
        if (!g.$L(b, a)) {
            var c = g.T(a, 2);
            c !== g.T(this.D, 2) && this.F.jz(c);
            this.D = a;
            Cob(this.module, b, a)
        }
    };
    g.w(k$, g.U);
    k$.prototype.Pc = function() {
        this.j.show()
    };
    k$.prototype.zb = function() {
        this.j.hide()
    };
    k$.prototype.u = function() {
        b8("mdx-privacy-popup-cancel");
        this.zb()
    };
    k$.prototype.B = function() {
        b8("mdx-privacy-popup-confirm");
        this.zb()
    };
    g.w(l$, g.U);
    l$.prototype.onStateChange = function(a) {
        this.Cc(a.state)
    };
    l$.prototype.Cc = function(a) {
        if (3 === this.api.getPresentingPlayerType()) {
            var b = {
                RECEIVER_NAME: this.api.getOption("remote", "currentReceiver").name
            };
            a = g.T(a, 128) ? g.DL("Error on $RECEIVER_NAME", b) : a.Zc() || g.aM(a) ? g.DL("Playing on $RECEIVER_NAME", b) : g.DL("Connected to $RECEIVER_NAME", b);
            this.updateValue("statustext", a);
            this.j.show()
        } else this.j.hide()
    };
    g.w(m$, g.zU);
    m$.prototype.C = function() {
        var a = this.F.getOption("remote", "receivers");
        a && 1 < a.length && !this.F.getOption("remote", "quickCast") ? (this.Zs = g.Gb(a, this.j, this), g.AU(this, g.Fg(a, this.j)), a = this.F.getOption("remote", "currentReceiver"), a = this.j(a), this.options[a] && this.uj(a), this.enable(!0)) : this.enable(!1)
    };
    m$.prototype.j = function(a) {
        return a.key
    };
    m$.prototype.rl = function(a) {
        return "cast-selector-receiver" === a ? "Cast..." : this.Zs[a].name
    };
    m$.prototype.Wg = function(a) {
        g.zU.prototype.Wg.call(this, a);
        this.F.setOption("remote", "currentReceiver", this.Zs[a]);
        this.qb.zb()
    };
    g.w(Bob, g.iR);
    g.k = Bob.prototype;
    g.k.create = function() {
        var a = this.player.V(),
            b = g.GH(a);
        a = {
            device: "Desktop",
            app: "youtube-desktop",
            loadCastApiSetupScript: a.N("mdx_load_cast_api_bootstrap_script"),
            enableDialLoungeToken: a.N("enable_dial_short_lived_lounge_token"),
            enableCastLoungeToken: a.N("enable_cast_short_lived_lounge_token")
        };
        mob(b, a);
        this.subscriptions.push(g.Kz("yt-remote-before-disconnect", this.l4, this));
        this.subscriptions.push(g.Kz("yt-remote-connection-change", this.D5, this));
        this.subscriptions.push(g.Kz("yt-remote-receiver-availability-change", this.oV,
            this));
        this.subscriptions.push(g.Kz("yt-remote-auto-connect", this.B5, this));
        this.subscriptions.push(g.Kz("yt-remote-receiver-resumed", this.A5, this));
        this.subscriptions.push(g.Kz("mdx-privacy-popup-confirm", this.T6, this));
        this.subscriptions.push(g.Kz("mdx-privacy-popup-cancel", this.S6, this));
        this.oV()
    };
    g.k.load = function() {
        this.player.cancelPlayback();
        g.iR.prototype.load.call(this);
        this.ul = new xob(this, this.player, this.wc);
        var a = (a = uob()) ? a.currentTime : 0;
        var b = rob() ? new K9(d$(), void 0) : null;
        0 == a && b && (a = H9(L9(b)));
        0 !== a && this.qc(a);
        Cob(this, this.Ud, this.Ud);
        this.player.Xo(6)
    };
    g.k.unload = function() {
        this.player.ma("mdxautoplaycanceled");
        this.Er = this.Po;
        g.$a(this.ul, this.wc);
        this.wc = this.ul = null;
        g.iR.prototype.unload.call(this);
        this.player.Xo(5);
        n$(this)
    };
    g.k.ra = function() {
        g.Lz(this.subscriptions);
        g.iR.prototype.ra.call(this)
    };
    g.k.Ro = function(a) {
        var b = g.xa.apply(1, arguments);
        this.loaded && this.ul.wk.apply(this.ul, [a].concat(g.u(b)))
    };
    g.k.getAdState = function() {
        return this.yh
    };
    g.k.Fo = function() {
        return this.wc ? L9(this.wc).Fo : !1
    };
    g.k.yk = function() {
        return this.wc ? L9(this.wc).yk : !1
    };
    g.k.qc = function(a, b) {
        this.aU = a || 0;
        this.player.ma("progresssync", a, b);
        this.player.Oa("onVideoProgress", a || 0)
    };
    g.k.getCurrentTime = function() {
        return this.aU
    };
    g.k.getProgressState = function() {
        var a = L9(this.wc),
            b = this.player.getVideoData();
        return {
            airingStart: 0,
            airingEnd: 0,
            allowSeeking: 1081 != a.playerState && this.player.wh(),
            clipEnd: b.clipEnd,
            clipStart: b.clipStart,
            current: this.getCurrentTime(),
            displayedStart: -1,
            duration: a.getDuration(),
            ingestionTime: a.u ? a.B + F9(a) : a.B,
            isAtLiveHead: 1 >= (a.u ? a.j + F9(a) : a.j) - this.getCurrentTime(),
            loaded: a.T,
            seekableEnd: a.u ? a.j + F9(a) : a.j,
            seekableStart: 0 < a.C ? a.C + F9(a) : a.C,
            offset: 0
        }
    };
    g.k.nextVideo = function() {
        this.wc && this.wc.nextVideo()
    };
    g.k.JG = function() {
        this.wc && this.wc.JG()
    };
    g.k.l4 = function(a) {
        1 === a && (this.mN = this.wc ? L9(this.wc) : null)
    };
    g.k.D5 = function() {
        var a = rob() ? new K9(d$(), void 0) : null;
        if (a) {
            var b = this.Er;
            this.loaded && this.unload();
            this.wc = a;
            this.mN = null;
            b.key !== this.Po.key && (this.Er = b, this.load())
        } else g.Za(this.wc), this.wc = null, this.loaded && (this.unload(), (a = this.mN) && a.videoId === this.player.getVideoData().videoId && this.player.cueVideoById(a.videoId, H9(a)));
        this.player.ma("videodatachange", "newdata", this.player.getVideoData(), 3)
    };
    g.k.oV = function() {
        var a = [this.Po],
            b = a.concat,
            c = nob();
        B9() && g.LA("yt-remote-cast-available") && c.push({
            key: "cast-selector-receiver",
            name: "Cast..."
        });
        this.Zs = b.call(a, c);
        a = pob() || this.Po;
        o$(this, a);
        this.player.Oa("onMdxReceiversChange")
    };
    g.k.B5 = function() {
        var a = pob();
        o$(this, a)
    };
    g.k.A5 = function() {
        this.Er = pob()
    };
    g.k.T6 = function() {
        this.BC = !0;
        n$(this);
        h$ = !1;
        e$ && g$(e$, 1);
        e$ = null
    };
    g.k.S6 = function() {
        this.BC = !1;
        n$(this);
        o$(this, this.Po);
        this.Er = this.Po;
        h$ = !1;
        e$ = null;
        this.player.playVideo()
    };
    g.k.ph = function(a, b) {
        switch (a) {
            case "casting":
                return this.loaded;
            case "receivers":
                return this.Zs;
            case "currentReceiver":
                return b && ("cast-selector-receiver" === b.key ? Gnb() : o$(this, b)), this.loaded ? this.Er : this.Po;
            case "quickCast":
                return 2 === this.Zs.length && "cast-selector-receiver" === this.Zs[1].key ? (b && Gnb(), !0) : !1
        }
    };
    g.k.CO = function() {
        this.wc.CO()
    };
    g.k.Ok = function() {
        return !1
    };
    g.k.getOptions = function() {
        return ["casting", "receivers", "currentReceiver", "quickCast"]
    };
    g.hR("remote", Bob);
})(_yt_player);